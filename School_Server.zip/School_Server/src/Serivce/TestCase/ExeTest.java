package Serivce.TestCase;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import jxl.read.biff.BiffException;
import jxl.write.WriteException;
import jxl.write.biff.RowsExceededException;

public class ExeTest {
	public static void main(String[] args) throws BiffException, IOException, RowsExceededException, WriteException {
		
		//读取
		//ExcelResult result = ExcelUtil.readExcel("C:\\Users\\xiezefan\\Desktop\\测试文件\\input.xls");
		
		//System.out.println(result.getColumnsName());
		
		//for (int i=0; i<result.getRows(); i++) {
		//	for (int j=0; j<result.getColumns(); j++) {
				
	//			ExcelCell cell = result.getDate(i, j);
		//		System.out.println("第 " + i + " 行，第 " + j + " 列,值=" + cell.getDate() + "列名=" + cell.getColumnName());
		//	}
	//	}

		
		
		//写入
		List<String> columnsName = new ArrayList<String>();
		columnsName.add("商品名");
		columnsName.add("商品编号");
		columnsName.add("所属地");
		
		List<List<String>> data = new ArrayList<List<String>>();
		for (int i=1; i<=3; i++) {
			List<String> row = new ArrayList<String>();
			for (int j=1; j<=4; j++) {
				row.add("第" + i + "行，第" + j + "列");
			}
			data.add(row);
		}
		ExcelUtil.writeExcel("e:\\output5.xls", columnsName, data);
		
		System.out.println("SUCCESS");
		
		
	}
}
