package Serivce.TestCase;

import java.util.List;

public class ExcelCell {
	private int row;
	private int column;
	private String date;
	private ExcelResult excelResult;
	
	public ExcelCell(ExcelResult rs) {
		this.excelResult = rs;
	}
	
	public String getColumnName() {
		List<String> columnNames = this.excelResult.getColumnsName();
		return columnNames.get(column);
	}
	
	public int getRow() {
		return row;
	}
	public void setRow(int row) {
		this.row = row;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}

	public int getColumn() {
		return column;
	}

	public void setColumn(int column) {
		this.column = column;
	}
}

