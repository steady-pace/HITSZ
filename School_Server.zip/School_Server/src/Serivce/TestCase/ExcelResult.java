package Serivce.TestCase;

import java.util.List;

public class ExcelResult {
	private int columns;
	private int rows;
	private List<String> columnsName;
	private ExcelCell[][] data;
	
	/**
	 * 获取数据
	 * @param row 行 从0开始
	 * @param column 列从0开始
	 * @return
	 */
	public ExcelCell getDate(int row, int column) {
		return data[row + 1][column];
	}
	
	
	
	public int getColumns() {
		return columns;
	}
	public void setColumns(int columns) {
		this.columns = columns;
	}
	public int getRows() {
		return rows;
	}
	public void setRows(int rows) {
		this.rows = rows;
	}
	public List<String> getColumnsName() {
		return columnsName;
	}
	public void setColumnsName(List<String> columnsName) {
		this.columnsName = columnsName;
	}
	public ExcelCell[][] getData() {
		return data;
	}
	public void setData(ExcelCell[][] data) {
		this.data = data;
	}
	
}
