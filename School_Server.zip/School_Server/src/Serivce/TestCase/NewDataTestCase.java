package Serivce.TestCase;

import java.util.Date;

import junit.framework.TestCase;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.YuanXu.Admin.Service.AdminService;

/*
 * 创建数据库后初始化一些数据
 */
public class NewDataTestCase extends TestCase {
	
	@SuppressWarnings("unused")
	private static AdminService adminService;
//	public static void setUpBeforeClass() throws Exception {
//		try {
//			ApplicationContext cxt = new ClassPathXmlApplicationContext(
//					"beans.xml");
//			adminSerivce = (AdminSerivce) cxt.getBean("adminService");
//			adminSerivce01 = (AdminSerivce) cxt.getBean("adminService");
//			adminSerivce02 = (AdminSerivce) cxt.getBean("adminService");
//		} catch (RuntimeException e) {
//			e.printStackTrace();
//		}
//	}

	public void addAdminTestCase(){
		try {
			ApplicationContext cxt = new ClassPathXmlApplicationContext("bean.xml");
			adminService = (AdminService) cxt.getBean("adminService");
		} catch (RuntimeException e) {
			e.printStackTrace();
		}
		try{
//			String adminName = "admin";
//			String adminPw = "123456";
//			String[] result = adminService.addAdmin(adminName, adminPw);
//			System.out.println(result[0] + ":" + result[1]);
		}catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
	}
	
	
	public static void main(String[] args) throws Exception {
		System.out.println(new Date().getTime());
		String a=System.getProperty("user.dir");
		System.out.println(a);
	}
}
