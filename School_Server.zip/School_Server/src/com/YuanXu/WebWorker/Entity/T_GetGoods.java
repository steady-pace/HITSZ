package com.YuanXu.WebWorker.Entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import com.YuanXu.Util.Parent.FormBeanParent;
import com.YuanXu.Util.Parent.MyEntityParent;
import com.YuanXu.Util.Parent.MyVoParent;
import com.YuanXu.WebWorker.Enum.EnumLosegoodsStatus;
/**
 * 招领表
 * @author Lyra_Phoenix
 *
 */
@SuppressWarnings("serial")
@Entity
@Table(name="tb_getgoods")
public class T_GetGoods extends MyEntityParent implements Serializable{
	@Id
	@Column(length=40)
	private String f_gId;  //Id
	@Column(length=100)
	private String f_gType; //拾物类型
	@Column(length=500)
	private String f_gDescribe; //拾物特征描述
	@Column(length=100)
	private String f_gNo; //拾物编号
	@Column(length=100)
	private String f_gPhone; //拾主的联系方式
	@Column(length=100)
	private String f_gmName; //发布该消息的管理员姓名
	@Column(length=100)
	private String f_gmNo; //发布该消息的管理员学号
	@Column(length=100)
	private String f_gmPhone; //发布该消息的管理员联系方式
	@Column(length=100)
	private EnumLosegoodsStatus f_gStatus; //状态
	
	public EnumLosegoodsStatus getF_gStatus() {
		return f_gStatus;
	}

	public void setF_gStatus(EnumLosegoodsStatus fGStatus) {
		f_gStatus = fGStatus;
	}

	public String getF_gId() {
		return f_gId;
	}

	public void setF_gId(String fGId) {
		f_gId = fGId;
	}

	public String getF_gType() {
		return f_gType;
	}

	public void setF_gType(String fGType) {
		f_gType = fGType;
	}

	public String getF_gDescribe() {
		return f_gDescribe;
	}

	public void setF_gDescribe(String fGDescribe) {
		f_gDescribe = fGDescribe;
	}

	public String getF_gNo() {
		return f_gNo;
	}

	public void setF_gNo(String fGNo) {
		f_gNo = fGNo;
	}

	public String getF_gPhone() {
		return f_gPhone;
	}

	public void setF_gPhone(String fGPhone) {
		f_gPhone = fGPhone;
	}

	public String getF_gmName() {
		return f_gmName;
	}

	public void setF_gmName(String fGmName) {
		f_gmName = fGmName;
	}

	public String getF_gmNo() {
		return f_gmNo;
	}

	public void setF_gmNo(String fGmNo) {
		f_gmNo = fGmNo;
	}

	public String getF_gmPhone() {
		return f_gmPhone;
	}

	public void setF_gmPhone(String fGmPhone) {
		f_gmPhone = fGmPhone;
	}

	@Override
	public MyVoParent isDoOpreate(FormBeanParent arg0, MyVoParent arg1) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public MyVoParent isNews(FormBeanParent arg0, MyVoParent arg1) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public MyVoParent isUpdate(FormBeanParent arg0, MyVoParent arg1) {
		// TODO Auto-generated method stub
		return null;
	}

}
