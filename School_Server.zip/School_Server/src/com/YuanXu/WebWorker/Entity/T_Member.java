package com.YuanXu.WebWorker.Entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import com.YuanXu.Util.DES.Des;
import com.YuanXu.Util.Parent.FormBeanParent;
import com.YuanXu.Util.Parent.MyEntityParent;
import com.YuanXu.Util.Parent.MyVoParent;
import com.YuanXu.WebWorker.Enum.EnumMemberStatus;

@SuppressWarnings("serial")
@Entity
@Table(name="tb_member")
public class T_Member extends MyEntityParent implements Serializable{
	@Id
	@Column(length=40)
	private String f_mId;  //Id
	@Column(length=100)
	private String f_mName; //登录名长度不能少于 3 个字符
	@Column(length=100)
	private String f_mEmail; //输入有效邮箱地址并成功激活，可用此邮箱做为登录账号及找回密码
	@Column(length=100)
	private String f_mPwd; //密码
	@Column(length=100)
	private Date f_mNewTime; //注册时间
	@Column(length=100)
	private String f_mNo; //学号
	@Column(length=100)
	private String f_mRealName; //真实姓名，经销商线下登记后系统输入
	@Column(length=100)
	private String f_mPhone; //手机号码，经销商线下登记后系统输入
	@Column(length=100)
	private EnumMemberStatus f_mStatus; //状态
	
	@Column(length=40)
	private String appKey;// 用户的appKey，用于移动手机端
	
	
	
	
	public String getAppKey() {
		return appKey;
	}

	public void setAppKey(String appKey) {
		this.appKey = appKey;
	}

	public String getF_mId() {
		return f_mId;
	}

	public void setF_mId(String fMId) {
		f_mId = fMId;
	}

	public String getF_mName() {
		return f_mName;
	}

	public void setF_mName(String fMName) {
		f_mName = fMName;
	}

	public String getF_mEmail() {
		return f_mEmail;
	}

	public void setF_mEmail(String fMEmail) {
		f_mEmail = fMEmail;
	}

	public String getF_mPwd() {
		try {
			return Des.decryptDES(f_mPwd);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return "";
	}

	public void setF_mPwd(String fMPwd) {
		try {
			f_mPwd = Des.encryptDES(fMPwd);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public Date getF_mNewTime() {
		return f_mNewTime;
	}

	public void setF_mNewTime(Date fMNewTime) {
		f_mNewTime = fMNewTime;
	}

	public String getF_mNo() {
		return f_mNo;
	}

	public void setF_mNo(String fMNo) {
		f_mNo = fMNo;
	}

	public String getF_mRealName() {
		return f_mRealName;
	}

	public void setF_mRealName(String fMRealName) {
		f_mRealName = fMRealName;
	}

	public String getF_mPhone() {
		return f_mPhone;
	}

	public void setF_mPhone(String fMPhone) {
		f_mPhone = fMPhone;
	}

	public EnumMemberStatus getF_mStatus() {
		return f_mStatus;
	}

	public void setF_mStatus(EnumMemberStatus fMStatus) {
		f_mStatus = fMStatus;
	}

	@Override
	public MyVoParent isDoOpreate(FormBeanParent arg0, MyVoParent arg1) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public MyVoParent isNews(FormBeanParent arg0, MyVoParent arg1) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public MyVoParent isUpdate(FormBeanParent arg0, MyVoParent arg1) {
		// TODO Auto-generated method stub
		return null;
	}

}
