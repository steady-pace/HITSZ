package com.YuanXu.WebWorker.Entity;

import java.io.Serializable;
import java.util.Date;
import java.util.UUID;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.YuanXu.Util.DES.Des;

/**
 * 管理员表
 * @author Lyra_Phoenix
 *
 */
@SuppressWarnings("serial")
@Entity
@Table(name="tb_webworker")
public class T_WebWorker implements Serializable {
	@Id
	@Column(length=40)
	private String f_wwId;// ID
	@Column(length=20)
	private String f_wwName;// 用户名，唯一
	@Column(length=120)
	private String f_wwPw;// 密码(加密)
	@Column(length=120)
	private String f_wwStudentNo;// 学号
	private Date f_wwLoginTime;// 最近登录日期
	@Column(length=200)
	private String f_wwContact;// 联系方式 手机号
	@ManyToOne(fetch=FetchType.LAZY)
	private T_WebRole t_webRole;// 角色
	@Column(length=20)
	private String f_newFrom;// admin:终极管理员other:其他
	
	public T_WebWorker(){
		super();
	}
	
	public T_WebWorker(String fWwName,String fWwPw,String fWwContact,T_WebRole tWebRole,String fNewFrom ,String fwwStudentNo){
		super();
		this.f_wwId = UUID.randomUUID().toString();
		this.f_wwName = fWwName;
		setF_wwPw(fWwPw);
		this.f_wwLoginTime = null;
		this.f_wwContact = fWwContact;
		this.t_webRole = tWebRole;
		this.f_newFrom = fNewFrom;
		this.f_wwStudentNo = fwwStudentNo ;
	}
	
	public String getF_wwId() {
		return f_wwId;
	}
	public void setF_wwId(String fWwId) {
		f_wwId = fWwId;
	}
	public String getF_wwName() {
		return f_wwName;
	}
	public void setF_wwName(String fWwName) {
		f_wwName = fWwName;
	}
	public String getF_wwPw() {
		try {
			return Des.decryptDES(f_wwPw);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return "";
		}
	}
	public void setF_wwPw(String fWwPw) {
		try {
			f_wwPw = Des.encryptDES(fWwPw);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public Date getF_wwLoginTime() {
		return f_wwLoginTime;
	}
	public void setF_wwLoginTime(Date fWwLoginTime) {
		f_wwLoginTime = fWwLoginTime;
	}

	public String getF_wwStudentNo() {
		return f_wwStudentNo;
	}

	public void setF_wwStudentNo(String fWwStudentNo) {
		f_wwStudentNo = fWwStudentNo;
	}

	public String getF_wwContact() {
		return f_wwContact;
	}
	public void setF_wwContact(String fWwContact) {
		f_wwContact = fWwContact;
	}
	public T_WebRole getT_webRole() {
		return t_webRole;
	}
	public void setT_webRole(T_WebRole tWebRole) {
		t_webRole = tWebRole;
	}

	public String getF_newFrom() {
		return f_newFrom;
	}
	public void setF_newFrom(String fNewFrom) {
		f_newFrom = fNewFrom;
	}
	
}
