package com.YuanXu.WebWorker.Entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.Table;

import com.YuanXu.Util.Parent.FormBeanParent;
import com.YuanXu.Util.Parent.MyEntityParent;
import com.YuanXu.Util.Parent.MyVoParent;

@SuppressWarnings("serial")
@Entity
@Table(name="tb_groupaction")
public class T_GroupAction extends MyEntityParent implements Serializable{
	@Id
	@Column(length=40)
	private String f_gaId;  //Id
	@Column(length=40)
	private String f_gaName;  //活动name
	@Lob
	private String f_gaInfo;  //活动介绍
	@Column(length=100)
	private String f_gcName;  //社团名称
	@Column(length=100)
	private String f_gaSponsors;  //活动赞助
	private Date f_gaBegin; // 活动开始时间
	private Date f_gaEnd; // 活动结束时间
	@Column(length=100)
	private String f_gaAddress;  //活动地点
	@Column(length=100)
	private String f_gaPublic;  //活动发布人
	private int f_gaZan ; 
	private int f_gaHit ;
	
	
	public String getF_gaId() {
		return f_gaId;
	}

	public void setF_gaId(String fGaId) {
		f_gaId = fGaId;
	}

	public String getF_gaName() {
		return f_gaName;
	}

	public void setF_gaName(String fGaName) {
		f_gaName = fGaName;
	}

	public String getF_gaInfo() {
		return f_gaInfo;
	}

	public void setF_gaInfo(String fGaInfo) {
		f_gaInfo = fGaInfo;
	}

	public String getF_gcName() {
		return f_gcName;
	}

	public void setF_gcName(String fGcName) {
		f_gcName = fGcName;
	}

	public String getF_gaSponsors() {
		return f_gaSponsors;
	}

	public void setF_gaSponsors(String fGaSponsors) {
		f_gaSponsors = fGaSponsors;
	}

	public Date getF_gaBegin() {
		return f_gaBegin;
	}

	public void setF_gaBegin(Date date) {
		f_gaBegin = date;
	}

	public Date getF_gaEnd() {
		return f_gaEnd;
	}

	public void setF_gaEnd(Date fGaEnd) {
		f_gaEnd = fGaEnd;
	}

	public String getF_gaAddress() {
		return f_gaAddress;
	}

	public void setF_gaAddress(String fGaAddress) {
		f_gaAddress = fGaAddress;
	}

	public String getF_gaPublic() {
		return f_gaPublic;
	}

	public void setF_gaPublic(String fGaPublic) {
		f_gaPublic = fGaPublic;
	}

	public int getF_gaZan() {
		return f_gaZan;
	}

	public void setF_gaZan(int fGaZan) {
		f_gaZan = fGaZan;
	}

	public int getF_gaHit() {
		return f_gaHit;
	}

	public void setF_gaHit(int fGaHit) {
		f_gaHit = fGaHit;
	}

	@Override
	public MyVoParent isDoOpreate(FormBeanParent arg0, MyVoParent arg1) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public MyVoParent isNews(FormBeanParent arg0, MyVoParent arg1) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public MyVoParent isUpdate(FormBeanParent arg0, MyVoParent arg1) {
		// TODO Auto-generated method stub
		return null;
	}

}
