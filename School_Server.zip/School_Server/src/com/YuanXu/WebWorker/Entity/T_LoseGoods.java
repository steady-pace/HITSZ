package com.YuanXu.WebWorker.Entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import com.YuanXu.Util.Parent.FormBeanParent;
import com.YuanXu.Util.Parent.MyEntityParent;
import com.YuanXu.Util.Parent.MyVoParent;
import com.YuanXu.WebWorker.Enum.EnumLosegoodsStatus;
/***
 * 失物表
 * @author Lyra_Phoenix
 *
 */
@SuppressWarnings("serial")
@Entity
@Table(name="tb_losegoods")
public class T_LoseGoods extends MyEntityParent implements Serializable{
	@Id
	@Column(length=40)
	private String f_lId;  //Id
	@Column(length=100)
	private String f_lType; //失物类型
	@Column(length=500)
	private String f_lDescribe; //失物特征描述
	@Column(length=100)
	private String f_lNo; //编号
	@Column(length=100)
	private String f_lPhone; //失主的联系方式
	@Column(length=100)
	private String f_lmName; //发布该消息的管理员姓名
	@Column(length=100)
	private String f_lmNo; //发布该消息的管理员学号
	@Column(length=100)
	private String f_lmPhone; //发布该消息的管理员联系方式
	@Column(length=100)
	private EnumLosegoodsStatus f_lStatus; //状态
	
	public String getF_lId() {
		return f_lId;
	}

	public void setF_lId(String fLId) {
		f_lId = fLId;
	}

	public String getF_lType() {
		return f_lType;
	}

	public void setF_lType(String fLType) {
		f_lType = fLType;
	}

	public String getF_lDescribe() {
		return f_lDescribe;
	}

	public void setF_lDescribe(String fLDescribe) {
		f_lDescribe = fLDescribe;
	}

	public String getF_lNo() {
		return f_lNo;
	}

	public void setF_lNo(String fLNo) {
		f_lNo = fLNo;
	}


	public String getF_lPhone() {
		return f_lPhone;
	}

	public void setF_lPhone(String fLPhone) {
		f_lPhone = fLPhone;
	}

	public String getF_lmName() {
		return f_lmName;
	}

	public void setF_lmName(String fLmName) {
		f_lmName = fLmName;
	}

	public String getF_lmNo() {
		return f_lmNo;
	}

	public void setF_lmNo(String fLmNo) {
		f_lmNo = fLmNo;
	}

	public String getF_lmPhone() {
		return f_lmPhone;
	}

	public void setF_lmPhone(String fLmPhone) {
		f_lmPhone = fLmPhone;
	}
	
	

	public EnumLosegoodsStatus getF_lStatus() {
		return f_lStatus;
	}

	public void setF_lStatus(EnumLosegoodsStatus fLStatus) {
		f_lStatus = fLStatus;
	}

	@Override
	public MyVoParent isDoOpreate(FormBeanParent arg0, MyVoParent arg1) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public MyVoParent isNews(FormBeanParent arg0, MyVoParent arg1) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public MyVoParent isUpdate(FormBeanParent arg0, MyVoParent arg1) {
		// TODO Auto-generated method stub
		return null;
	}

}
