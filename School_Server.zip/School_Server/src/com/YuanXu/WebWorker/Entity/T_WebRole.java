package com.YuanXu.WebWorker.Entity;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.Table;
import com.YuanXu.Util.Parent.FormBeanParent;
import com.YuanXu.Util.Parent.MyEntityParent;
import com.YuanXu.Util.Parent.MyVoParent;

/**
 * 管理员角色表
 * 注释：管理员拥有不同的权限 有着不同的角色 比如：不同社团 失物招领人员。。。
 * @author Lyra_Phoenix
 *
 */

@SuppressWarnings("serial")
@Entity
@Table(name="tb_webrole")
public class T_WebRole extends MyEntityParent implements Serializable {
	@Id
	@Column(length=40)
	private String f_wrId;// ID
	@Column(length=40)
	private String f_wrName;// 角色名
	@Column(length=300)
	private String f_wrDescribe;// 角色描述
	@Column(length=300)
	private String f_newFrom;// admin:终极管理员other:其他
	@Lob
	@Column(nullable=false)
	private String f_wrPower;// 角色权限
	public String getF_wrId() {
		return f_wrId;
	}
	public void setF_wrId(String fWrId) {
		f_wrId = fWrId;
	}
	public String getF_wrName() {
		return f_wrName;
	}
	public void setF_wrName(String fWrName) {
		f_wrName = fWrName;
	}
	public String getF_newFrom() {
		return f_newFrom;
	}
	public void setF_newFrom(String fNewFrom) {
		f_newFrom = fNewFrom;
	}
	public String getF_wrDescribe() {
		return f_wrDescribe;
	}
	public void setF_wrDescribe(String fWrDescribe) {
		f_wrDescribe = fWrDescribe;
	}
	public String getF_wrPower() {
		return f_wrPower;
	}
	public void setF_wrPower(String fWrPower) {
		f_wrPower = fWrPower;
	}
	@Override
	public MyVoParent isDoOpreate(FormBeanParent parent, MyVoParent result) {
		// TODO Auto-generated method stub
		return result;
	}
	@Override
	public MyVoParent isNews(FormBeanParent parent, MyVoParent result) {
		// TODO Auto-generated method stub
		return result;
	}
	@Override
	public MyVoParent isUpdate(FormBeanParent parent, MyVoParent result) {
		// TODO Auto-generated method stub
		return result;
	}
	
}
