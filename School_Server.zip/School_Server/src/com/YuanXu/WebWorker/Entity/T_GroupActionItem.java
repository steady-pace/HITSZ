package com.YuanXu.WebWorker.Entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import com.YuanXu.Util.Parent.FormBeanParent;
import com.YuanXu.Util.Parent.MyEntityParent;
import com.YuanXu.Util.Parent.MyVoParent;
/**
 * 这个用于点赞跟点批 每个学生每个活动只能点一次
 * 这个表作用就是记录学生对某个活动是否已经点过
 * @author Lyra_Phoenix
 *
 */
@SuppressWarnings("serial")
@Entity
@Table(name="tb_getgoodsitem")
public class T_GroupActionItem extends MyEntityParent implements Serializable{
	@Id
	@Column(length=40)
	private String f_stuId; //学生ID
	@Column(length=100)
	private String f_actId; //活动Id
	@Column(length=100)
	private String f_actzan; //点赞
	@Column(length=100)
	private String f_acthit; //点批

	public String getF_stuId() {
		return f_stuId;
	}

	public void setF_stuId(String fStuId) {
		f_stuId = fStuId;
	}

	public String getF_actId() {
		return f_actId;
	}

	public void setF_actId(String fActId) {
		f_actId = fActId;
	}

	public String getF_actzan() {
		return f_actzan;
	}

	public void setF_actzan(String fActzan) {
		f_actzan = fActzan;
	}

	public String getF_acthit() {
		return f_acthit;
	}

	public void setF_acthit(String fActhit) {
		f_acthit = fActhit;
	}

	@Override
	public MyVoParent isDoOpreate(FormBeanParent arg0, MyVoParent arg1) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public MyVoParent isNews(FormBeanParent arg0, MyVoParent arg1) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public MyVoParent isUpdate(FormBeanParent arg0, MyVoParent arg1) {
		// TODO Auto-generated method stub
		return null;
	}

}
