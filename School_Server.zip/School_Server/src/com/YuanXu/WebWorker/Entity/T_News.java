package com.YuanXu.WebWorker.Entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.Table;

import com.YuanXu.Util.Parent.FormBeanParent;
import com.YuanXu.Util.Parent.MyEntityParent;
import com.YuanXu.Util.Parent.MyVoParent;

@SuppressWarnings("serial")
@Entity
@Table(name="tb_news")
public class T_News extends MyEntityParent implements Serializable{
	@Id
	@Column(length=40)
	private String f_nId;  //Id
	@Column(length=200)
	private String f_nTitle; //新闻标题
	@Column(length=250)
	private String f_nSubtitle; //副标题
	private Date f_nDate; //时间
	@Lob
	private String f_nContent; //内容
	@Column(length=50)
	private String f_nAuthor; //作者
	private long f_nPaiWei;//排位，逆序排序，手动上移、下移
	@Column(length=250)
	private String f_nUrl; //url
	
	
	public String getF_nUrl() {
		return f_nUrl;
	}

	public void setF_nUrl(String fNUrl) {
		f_nUrl = fNUrl;
	}

	@Override
	public MyVoParent isDoOpreate(FormBeanParent arg0, MyVoParent arg1) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public MyVoParent isNews(FormBeanParent arg0, MyVoParent arg1) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public MyVoParent isUpdate(FormBeanParent arg0, MyVoParent arg1) {
		// TODO Auto-generated method stub
		return null;
	}

	public String getF_nId() {
		return f_nId;
	}

	public void setF_nId(String fNId) {
		f_nId = fNId;
	}

	public String getF_nTitle() {
		return f_nTitle;
	}

	public void setF_nTitle(String fNTitle) {
		f_nTitle = fNTitle;
	}

	public String getF_nSubtitle() {
		return f_nSubtitle;
	}

	public void setF_nSubtitle(String fNSubtitle) {
		f_nSubtitle = fNSubtitle;
	}

	public Date getF_nDate() {
		return f_nDate;
	}

	public void setF_nDate(Date fNDate) {
		f_nDate = fNDate;
	}

	public String getF_nContent() {
		return f_nContent;
	}

	public void setF_nContent(String fNContent) {
		f_nContent = fNContent;
	}

	public String getF_nAuthor() {
		return f_nAuthor;
	}

	public void setF_nAuthor(String fNAuthor) {
		f_nAuthor = fNAuthor;
	}

	public long getF_nPaiWei() {
		return f_nPaiWei;
	}

	public void setF_nPaiWei(long fNPaiWei) {
		f_nPaiWei = fNPaiWei;
	}
}
