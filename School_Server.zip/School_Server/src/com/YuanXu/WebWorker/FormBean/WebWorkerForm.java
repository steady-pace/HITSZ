package com.YuanXu.WebWorker.FormBean;

import java.util.Date;

import com.YuanXu.Util.Parent.FormBeanParent;

/**
 * 网络部工作人员Form
 * @author 罗培彬
 *
 */
public class WebWorkerForm extends FormBeanParent{
	//修改密码
	private String oldPw;
	private String newPw;
	
	private String f_wwId;// ID
	private String f_wwName;// 用户名，唯一
	private String f_wwPw;// 密码(加密)
	private String f_wwStudentNo ;//学号
	private Date f_wwLoginTime;// 最近登录日期
	private String f_wwContact;// 联系方式，自己输入例如：email:251590940@qq.com phone:13750067437
	private String t_webRole;// 角色
	private String f_newFrom;// admin:终极管理员other:其他
	private String f_wSystem;// 用户登录的系统
	private String f_wBrowser;// 用户所用的浏览器
	private String random;
	
	
	public String getRandom() {
		return random;
	}
	public void setRandom(String random) {
		this.random = random;
	}
	public String getF_wSystem() {
		return f_wSystem;
	}
	public void setF_wSystem(String fWSystem) {
		f_wSystem = fWSystem;
	}
	public String getF_wBrowser() {
		return f_wBrowser;
	}
	public void setF_wBrowser(String fWBrowser) {
		f_wBrowser = fWBrowser;
	}
	public String getOldPw() {
		return oldPw;
	}
	public void setOldPw(String oldPw) {
		this.oldPw = oldPw;
	}
	public String getNewPw() {
		return newPw;
	}
	public void setNewPw(String newPw) {
		this.newPw = newPw;
	}
	public String getF_wwId() {
		return f_wwId;
	}
	public void setF_wwId(String fWwId) {
		f_wwId = fWwId;
	}
	public String getF_wwName() {
		return f_wwName;
	}
	public void setF_wwName(String fWwName) {
		f_wwName = fWwName;
	}
	public String getF_wwPw() {
		return f_wwPw;
	}
	public void setF_wwPw(String fWwPw) {
		f_wwPw = fWwPw;
	}
	public Date getF_wwLoginTime() {
		return f_wwLoginTime;
	}
	public void setF_wwLoginTime(Date fWwLoginTime) {
		f_wwLoginTime = fWwLoginTime;
	}

	public String getF_wwContact() {
		return f_wwContact;
	}
	public void setF_wwContact(String fWwContact) {
		f_wwContact = fWwContact;
	}
	
	public String getT_webRole() {
		return t_webRole;
	}
	public void setT_webRole(String tWebRole) {
		t_webRole = tWebRole;
	}
	public String getF_newFrom() {
		return f_newFrom;
	}
	public void setF_newFrom(String fNewFrom) {
		f_newFrom = fNewFrom;
	}
	public String getF_wwStudentNo() {
		return f_wwStudentNo;
	}
	public void setF_wwStudentNo(String fWwStudentNo) {
		f_wwStudentNo = fWwStudentNo;
	}
	
}
