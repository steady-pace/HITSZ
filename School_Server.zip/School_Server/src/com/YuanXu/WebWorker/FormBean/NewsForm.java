package com.YuanXu.WebWorker.FormBean;

import java.util.Date;



import com.YuanXu.Util.Parent.FormBeanParent;


public class NewsForm extends FormBeanParent{
	private String f_nId;  //Id
	private String f_nTitle; //新闻标题
	private String f_nSubtitle; //副标题
	private Date f_nDate; //时间
	private String f_nContent; //内容
	private String f_nAuthor; //作者
	private String f_tFatherId; //新闻类型
	private String f_nShow;
	private long f_nPaiWei;//排位，逆序排序，手动上移、下移
	private String f_nUrl; //url
	
	
	public String getF_nUrl() {
		return f_nUrl;
	}
	public void setF_nUrl(String fNUrl) {
		f_nUrl = fNUrl;
	}
	public String getF_nId() {
		return f_nId;
	}
	public void setF_nId(String fNId) {
		f_nId = fNId;
	}
	public String getF_nTitle() {
		return f_nTitle;
	}
	public void setF_nTitle(String fNTitle) {
		f_nTitle = fNTitle;
	}
	public String getF_nSubtitle() {
		return f_nSubtitle;
	}
	public void setF_nSubtitle(String fNSubtitle) {
		f_nSubtitle = fNSubtitle;
	}
	public Date getF_nDate() {
		return f_nDate;
	}
	public void setF_nDate(Date fNDate) {
		f_nDate = fNDate;
	}
	public String getF_nContent() {
		return f_nContent;
	}
	public void setF_nContent(String fNContent) {
		f_nContent = fNContent;
	}
	public String getF_nAuthor() {
		return f_nAuthor;
	}
	public void setF_nAuthor(String fNAuthor) {
		f_nAuthor = fNAuthor;
	}
	
	public String getF_tFatherId() {
		return f_tFatherId;
	}
	public void setF_tFatherId(String fTFatherId) {
		f_tFatherId = fTFatherId;
	}
	public long getF_nPaiWei() {
		return f_nPaiWei;
	}
	public void setF_nPaiWei(long fNPaiWei) {
		f_nPaiWei = fNPaiWei;
	}
	public String getF_nShow() {
		return f_nShow;
	}
	public void setF_nShow(String fNShow) {
		f_nShow = fNShow;
	}
	
}
