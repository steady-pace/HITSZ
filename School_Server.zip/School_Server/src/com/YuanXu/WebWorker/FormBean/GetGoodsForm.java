package com.YuanXu.WebWorker.FormBean;

import java.util.ArrayList;
import java.util.List;

import com.YuanXu.Util.Parent.FormBeanParent;
import com.YuanXu.WebWorker.Enum.EnumLosegoodsStatus;

public class GetGoodsForm extends FormBeanParent{
	//修改密码
	private String oldPw;// 原密码 
	private String newPw;// 新密码
	private String f_gId;  //Id
	private String f_gType; //失物类型
	private String f_gDescribe; //失物特征描述
	private String f_gNo; //编号
	private String f_gPhone; //失主的联系方式
	private String f_gmName; //发布该消息的管理员姓名
	private String f_gmNo; //发布该消息的管理员学号
	private String f_gmPhone; //发布该消息的管理员联系方式
	private EnumLosegoodsStatus f_gStatus; //状态
	private List<String> paramStr = new ArrayList<String>();
	public String getOldPw() {
		return oldPw;
	}
	public void setOldPw(String oldPw) {
		this.oldPw = oldPw;
	}
	public String getNewPw() {
		return newPw;
	}
	public void setNewPw(String newPw) {
		this.newPw = newPw;
	}
	public String getF_gId() {
		return f_gId;
	}
	public void setF_gId(String fGId) {
		f_gId = fGId;
	}
	public String getF_gType() {
		return f_gType;
	}
	public void setF_gType(String fGType) {
		f_gType = fGType;
	}
	public String getF_gDescribe() {
		return f_gDescribe;
	}
	public void setF_gDescribe(String fGDescribe) {
		f_gDescribe = fGDescribe;
	}
	public String getF_gNo() {
		return f_gNo;
	}
	public void setF_gNo(String fGNo) {
		f_gNo = fGNo;
	}
	public String getF_gPhone() {
		return f_gPhone;
	}
	public void setF_gPhone(String fGPhone) {
		f_gPhone = fGPhone;
	}
	public String getF_gmName() {
		return f_gmName;
	}
	public void setF_gmName(String fGmName) {
		f_gmName = fGmName;
	}
	public String getF_gmNo() {
		return f_gmNo;
	}
	public void setF_gmNo(String fGmNo) {
		f_gmNo = fGmNo;
	}

	public String getF_gmPhone() {
		return f_gmPhone;
	}
	public void setF_gmPhone(String fGmPhone) {
		f_gmPhone = fGmPhone;
	}
	public EnumLosegoodsStatus getF_gStatus() {
		return f_gStatus;
	}
	public void setF_gStatus(EnumLosegoodsStatus fGStatus) {
		f_gStatus = fGStatus;
	}
	public List<String> getParamStr() {
		return paramStr;
	}
	public void setParamStr(List<String> paramStr) {
		this.paramStr = paramStr;
	}

}
