package com.YuanXu.WebWorker.FormBean;

import com.YuanXu.Util.Parent.FormBeanParent;

/**
 * 网络部角色Form
 * @author 罗培彬
 *
 */
public class WebRoleForm extends FormBeanParent{
	private String f_wrId;// ID
	private String f_wrName;// 角色名
	private String f_wrDescribe;// 角色描述
	private String f_wrPower;// 角色权限
	private String f_wrPowers[];// 用于接收角色权限列表
	public String[] getF_wrPowers() {
		return f_wrPowers;
	}
	public void setF_wrPowers(String[] fWrPowers) {
		f_wrPowers = fWrPowers;
	}
	public String getF_wrId() {
		return f_wrId;
	}
	public void setF_wrId(String fWrId) {
		f_wrId = fWrId;
	}
	public String getF_wrName() {
		return f_wrName;
	}
	public void setF_wrName(String fWrName) {
		f_wrName = fWrName;
	}
	public String getF_wrDescribe() {
		return f_wrDescribe;
	}
	public void setF_wrDescribe(String fWrDescribe) {
		f_wrDescribe = fWrDescribe;
	}
	public String getF_wrPower() {
		return f_wrPower;
	}
	public void setF_wrPower(String fWrPower) {
		f_wrPower = fWrPower;
	}
	
}
