package com.YuanXu.WebWorker.FormBean;

import com.YuanXu.Util.Parent.FormBeanParent;

public class NewsTypeForm extends FormBeanParent{
	private String f_ntId; //Id
	private String f_ntType; //类型
	private String f_tFatherId;//父级
	private String f_vie_ntType; //类型越
	public String getF_ntId() {
		return f_ntId;
	}
	public void setF_ntId(String fNtId) {
		f_ntId = fNtId;
	}
	public String getF_ntType() {
		return f_ntType;
	}
	public void setF_ntType(String fNtType) {
		f_ntType = fNtType;
	}
	public String getF_tFatherId() {
		return f_tFatherId;
	}
	public void setF_tFatherId(String fTFatherId) {
		f_tFatherId = fTFatherId;
	}
	public String getF_vie_ntType() {
		return f_vie_ntType;
	}
	public void setF_vie_ntType(String fVieNtType) {
		f_vie_ntType = fVieNtType;
	}
}
