package com.YuanXu.WebWorker.FormBean;


import java.util.ArrayList;
import java.util.List;

import com.YuanXu.Util.Parent.FormBeanParent;

public class MemberForm extends FormBeanParent{
	private String f_mId;  //Id
	private String f_mName; //登录名长度不能少于 3 个字符
	private String f_mEmail; //输入有效邮箱地址并成功激活，可用此邮箱做为登录账号及找回密码
	private String f_mPwd; //密码
	private String f_mNo; //会员编号，经销商线下登记后系统按规则生成的编号
	private String f_mPhone; //手机号码，经销商线下登记后系统输入
	private String f_newtime;
	private String param;
	private List<String> paramStr = new ArrayList<String>();
	
	public String getF_newtime() {
		return f_newtime;
	}
	public void setF_newtime(String fNewtime) {
		f_newtime = fNewtime;
	}
	public String getF_mId() {
		return f_mId;
	}
	public void setF_mId(String fMId) {
		f_mId = fMId;
	}
	public String getF_mName() {
		return f_mName;
	}
	public void setF_mName(String fMName) {
		f_mName = fMName;
	}
	public String getF_mEmail() {
		return f_mEmail;
	}
	public void setF_mEmail(String fMEmail) {
		f_mEmail = fMEmail;
	}
	public String getF_mPwd() {
		return f_mPwd;
	}
	public void setF_mPwd(String fMPwd) {
		f_mPwd = fMPwd;
	}
	public String getF_mNo() {
		return f_mNo;
	}
	public void setF_mNo(String fMNo) {
		f_mNo = fMNo;
	}
	public String getF_mPhone() {
		return f_mPhone;
	}
	public void setF_mPhone(String fMPhone) {
		f_mPhone = fMPhone;
	}
	public String getParam() {
		return param;
	}
	public void setParam(String param) {
		this.param = param;
	}
	public List<String> getParamStr() {
		return paramStr;
	}
	public void setParamStr(List<String> paramStr) {
		this.paramStr = paramStr;
	}
	
}
