package com.YuanXu.WebWorker.FormBean;

import com.YuanXu.Util.Parent.FormBeanParent;
/**
 * 网络部工作人员日志Form
 * @author 罗培彬
 *
 */
public class WebWorkerLogForm extends FormBeanParent{
}
