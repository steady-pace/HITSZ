package com.YuanXu.WebWorker.Vo;

import com.YuanXu.Util.Parent.MyVoParent;
import com.YuanXu.Util.Util.DateUtil;
import com.YuanXu.WebWorker.Entity.T_WebWorker;

/**
 * 
 * @author Lyra_Phoenix
 *
 */
public class VoWebWorker extends MyVoParent{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String f_wwId;// ID
	private String f_wwName;// 用户名，唯一
	private String f_wwPw;// 密码(加密)
	private String f_wwLoginTime;// 最近登录日期
	private String f_wwContact;// 联系方式，自己输入例如：email:251590940@qq.com phone:13750067437
	private String t_webRole;// 角色
	private String f_newFrom;// admin:终极管理员other:其他
	private String t_webRoleId;// 角色Id传回前台
	private String f_wwStudentNo; // 学号
	
	

	public VoWebWorker(T_WebWorker t){
		super();
		this.f_wwId = t.getF_wwId();
		this.f_wwName = t.getF_wwName();
		this.f_wwPw = t.getF_wwPw();
		if(t.getF_wwLoginTime()==null){
			this.f_wwLoginTime = "";
		}else{
			this.f_wwLoginTime = DateUtil.dateToString(t.getF_wwLoginTime());
		}
		this.f_wwContact = t.getF_wwContact();
		this.t_webRole = t.getT_webRole().getF_wrName();
		this.f_newFrom = t.getF_newFrom();
		this.t_webRoleId = t.getT_webRole().getF_wrId();
		this.f_wwStudentNo = t.getF_wwStudentNo() ;
	}
	
	public String getT_webRoleId() {
		return t_webRoleId;
	}

	public void setT_webRoleId(String tWebRoleId) {
		t_webRoleId = tWebRoleId;
	}
	
	public String getF_wwId() {
		return f_wwId;
	}
	public void setF_wwId(String fWwId) {
		f_wwId = fWwId;
	}
	public String getF_wwName() {
		return f_wwName;
	}
	public void setF_wwName(String fWwName) {
		f_wwName = fWwName;
	}
	public String getF_wwPw() {
		return f_wwPw;
	}
	public void setF_wwPw(String fWwPw) {
		f_wwPw = fWwPw;
	}
	public String getF_wwLoginTime() {
		return f_wwLoginTime;
	}

	public void setF_wwLoginTime(String fWwLoginTime) {
		f_wwLoginTime = fWwLoginTime;
	}

	public String getF_wwContact() {
		return f_wwContact;
	}
	public void setF_wwContact(String fWwContact) {
		f_wwContact = fWwContact;
	}
	public String getT_webRole() {
		return t_webRole;
	}
	public void setT_webRole(String tWebRole) {
		t_webRole = tWebRole;
	}
	
	public String getF_wwStudentNo() {
		return f_wwStudentNo;
	}

	public void setF_wwStudentNo(String fWwStudentNo) {
		f_wwStudentNo = fWwStudentNo;
	}

	public String getF_newFrom() {
		return f_newFrom;
	}
	public void setF_newFrom(String fNewFrom) {
		f_newFrom = fNewFrom;
	}
	
}
