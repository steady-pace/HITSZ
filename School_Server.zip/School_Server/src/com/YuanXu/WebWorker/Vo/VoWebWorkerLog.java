package com.YuanXu.WebWorker.Vo;

import com.YuanXu.Util.Parent.MyVoParent;
import com.YuanXu.Util.Util.DateUtil;
import com.YuanXu.WebWorker.Entity.T_WebWorkerLog;
/**
 * 网络部工作人员日志Vo
 * @author 罗培彬
 *
 */
public class VoWebWorkerLog extends MyVoParent{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String f_wLogId;// ID
	private String f_wLogTime;// 记录操作日期
	private String f_wLogDoIp;// 用户IP
	private String f_wLogDoUser;// 操作者
	private String f_wLogUserId;// 操作者ID
	private String f_wLogDoStr;// 操作内容
	private String f_wLogDoResult;// 操作结果
	private String f_wSystem;// 用户登录的系统
	private String f_wBrowser;// 用户所用的浏览器
	public VoWebWorkerLog(){
		super();
	}
	public VoWebWorkerLog(T_WebWorkerLog t){
		super();
		this.f_wLogId = t.getF_wLogId();
		this.f_wLogTime = DateUtil.dateToString(t.getF_wLogTime());
		this.f_wLogDoIp = t.getF_wLogDoIp();
		this.f_wLogDoUser = t.getF_wLogDoUser();
		this.f_wLogUserId = t.getF_wLogUserId();
		this.f_wLogDoStr = t.getF_wLogDoStr();
		this.f_wLogDoResult = t.getF_wLogDoResult();
		this.f_wSystem = t.getF_wSystem();
		this.f_wBrowser = t.getF_wBrowser();
		
	}
	
	public String getF_wSystem() {
		return f_wSystem;
	}
	public void setF_wSystem(String fWSystem) {
		f_wSystem = fWSystem;
	}
	public String getF_wBrowser() {
		return f_wBrowser;
	}
	public void setF_wBrowser(String fWBrowser) {
		f_wBrowser = fWBrowser;
	}
	public String getF_wLogId() {
		return f_wLogId;
	}
	public void setF_wLogId(String fWLogId) {
		f_wLogId = fWLogId;
	}
	public String getF_wLogTime() {
		return f_wLogTime;
	}
	public void setF_wLogTime(String fWLogTime) {
		f_wLogTime = fWLogTime;
	}
	public String getF_wLogDoIp() {
		return f_wLogDoIp;
	}
	public void setF_wLogDoIp(String fWLogDoIp) {
		f_wLogDoIp = fWLogDoIp;
	}
	public String getF_wLogDoUser() {
		return f_wLogDoUser;
	}
	public void setF_wLogDoUser(String fWLogDoUser) {
		f_wLogDoUser = fWLogDoUser;
	}
	public String getF_wLogUserId() {
		return f_wLogUserId;
	}
	public void setF_wLogUserId(String fWLogUserId) {
		f_wLogUserId = fWLogUserId;
	}
	public String getF_wLogDoStr() {
		return f_wLogDoStr;
	}
	public void setF_wLogDoStr(String fWLogDoStr) {
		f_wLogDoStr = fWLogDoStr;
	}
	public String getF_wLogDoResult() {
		return f_wLogDoResult;
	}
	public void setF_wLogDoResult(String fWLogDoResult) {
		f_wLogDoResult = fWLogDoResult;
	}
	
	
}
