package com.YuanXu.WebWorker.Vo;

import com.YuanXu.Util.Parent.MyEntityParent;
import com.YuanXu.Util.Parent.MyVoParent;
import com.YuanXu.WebWorker.Entity.T_Member;
import com.YuanXu.WebWorker.Enum.EnumMemberStatus;

@SuppressWarnings("serial")
public class VoMember extends MyVoParent{
	private String f_mId;  //Id
	private String f_mName; //登录名长度不能少于 3 个字符
	private String f_mEmail; //输入有效邮箱地址并成功激活，可用此邮箱做为登录账号及找回密码
	private String f_mPwd; //密码
	private String f_mNo; //学号
	private String f_mRealName; //真实姓名，经销商线下登记后系统输入
	private String f_mPhone; //手机号码，经销商线下登记后系统输入
	private String f_mStatus; //状态
	private String[] f_memStr;
	private String[] f_Name;
	
	private String _parentId;  //没有父类 这留空
	private String iconCls = "icon-ok"; //图标
	
	public VoMember(){
		super();
	}
	
	public void voInit(MyEntityParent data,T_Member m){
		T_Member member = (T_Member)data;
		this.f_mId = member.getF_mId();
		this.f_mName = member.getF_mName();
		this.f_mEmail = member.getF_mEmail();
		this.f_mPwd = member.getF_mPwd();
		this.f_mNo = member.getF_mNo();
		this.f_mRealName = member.getF_mRealName();
		this.f_mPhone = member.getF_mPhone();
		if(member.getF_mStatus()==EnumMemberStatus.MANAGE_OK){
			this.f_mStatus = "正常";
		}else{
			this.f_mStatus = "关闭";
		}
	}
	public VoMember(T_Member m){
		super();
		this.f_mId = m.getF_mId();
		this.f_mName = m.getF_mName();
		this.f_mEmail = m.getF_mEmail();
		this.f_mPwd = m.getF_mPwd();
		this.f_mNo = m.getF_mNo();
		this.f_mRealName = m.getF_mRealName();
		this.f_mPhone = m.getF_mPhone();
		if(m.getF_mStatus()==EnumMemberStatus.MANAGE_OK){
			this.f_mStatus = "正常";
		}else{
			this.f_mStatus = "关闭";
		}
	}

	public String getF_mId() {
		return f_mId;
	}
	public void setF_mId(String fMId) {
		f_mId = fMId;
	}
	public String getF_mName() {
		return f_mName;
	}
	public void setF_mName(String fMName) {
		f_mName = fMName;
	}
	public String getF_mEmail() {
		return f_mEmail;
	}
	public void setF_mEmail(String fMEmail) {
		f_mEmail = fMEmail;
	}
	public String getF_mPwd() {
		return f_mPwd;
	}
	public void setF_mPwd(String fMPwd) {
		f_mPwd = fMPwd;
	}
	public String getF_mNo() {
		return f_mNo;
	}
	public void setF_mNo(String fMNo) {
		f_mNo = fMNo;
	}
	public String getF_mRealName() {
		return f_mRealName;
	}
	public void setF_mRealName(String fMRealName) {
		f_mRealName = fMRealName;
	}
	public String getF_mPhone() {
		return f_mPhone;
	}
	public void setF_mPhone(String fMPhone) {
		f_mPhone = fMPhone;
	}
	public String getF_mStatus() {
		return f_mStatus;
	}
	public void setF_mStatus(String fMStatus) {
		f_mStatus = fMStatus;
	}

	public String get_parentId() {
		return _parentId;
	}

	public void set_parentId(String parentId) {
		_parentId = parentId;
	}

	public String getIconCls() {
		return iconCls;
	}

	public void setIconCls(String iconCls) {
		this.iconCls = iconCls;
	}

	public String[] getF_memStr() {
		return f_memStr;
	}

	public void setF_memStr(String[] fMemStr) {
		f_memStr = fMemStr;
	}

	public String[] getF_Name() {
		return f_Name;
	}

	public void setF_Name(String[] fName) {
		f_Name = fName;
	}

	
	
}
