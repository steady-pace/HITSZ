package com.YuanXu.WebWorker.Vo;

import com.YuanXu.Util.Parent.MyEntityParent;
import com.YuanXu.Util.Parent.MyVoInterface;
import com.YuanXu.Util.Parent.MyVoParent;
import com.YuanXu.WebWorker.Entity.T_WebRole;
import com.YuanXu.WebWorker.Enum.EnumWebRolePower;

/**
 * 网络部角色Vo
 * @author 罗培彬
 *
 */
public class VoWebRole extends MyVoParent implements MyVoInterface{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String f_wrId;// ID
	private String f_wrName;// 角色名
	private String f_wrDescribe;// 角色描述
	private String f_wrPower;// 角色权限
	private String f_wrPowers;// 角色权限列表，用于返回前台
	private String f_newFrom;
	
	
	public VoWebRole(){
		super();
	}
	public VoWebRole(T_WebRole t){
		super();
		this.f_wrId = t.getF_wrId();
		this.f_wrName = t.getF_wrName();
	}
	public void vo_easyui(MyEntityParent data) {
		T_WebRole t = (T_WebRole)data;
		this.f_wrId = t.getF_wrId();
		this.f_wrName = t.getF_wrName();
		this.f_wrDescribe = t.getF_wrDescribe();
		this.f_wrPowers = t.getF_wrPower();
		this.f_newFrom = t.getF_newFrom();
		String power[] = t.getF_wrPower().split(";");
		String str = "";
		for(String p : power){
			str = str + EnumWebRolePower.getName(p) + ";";
		}
		if(str != null){
			this.f_wrPower = str;
		}else{
			this.f_wrPower = "";
		}
			
	}
	public String getF_newFrom() {
		return f_newFrom;
	}
	public void setF_newFrom(String fNewFrom) {
		f_newFrom = fNewFrom;
	}
	public String getF_wrId() {
		return f_wrId;
	}
	public void setF_wrId(String fWrId) {
		f_wrId = fWrId;
	}
	public String getF_wrName() {
		return f_wrName;
	}
	public void setF_wrName(String fWrName) {
		f_wrName = fWrName;
	}
	public String getF_wrDescribe() {
		return f_wrDescribe;
	}
	public void setF_wrDescribe(String fWrDescribe) {
		f_wrDescribe = fWrDescribe;
	}
	public String getF_wrPower() {
		return f_wrPower;
	}
	public void setF_wrPower(String fWrPower) {
		f_wrPower = fWrPower;
	}
	public String getF_wrPowers() {
		return f_wrPowers;
	}
	public void setF_wrPowers(String fWrPowers) {
		f_wrPowers = fWrPowers;
	}
	
}
