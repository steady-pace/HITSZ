package com.YuanXu.WebWorker.Service;

import com.YuanXu.Util.Parent.MyServiceInterface;

public interface GroupActionService extends MyServiceInterface{
}
