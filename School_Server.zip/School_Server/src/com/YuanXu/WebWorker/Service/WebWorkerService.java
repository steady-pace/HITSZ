package com.YuanXu.WebWorker.Service;

import com.YuanXu.Util.Parent.FormBeanParent;
import com.YuanXu.Util.Parent.MyServiceInterface;
import com.YuanXu.Util.Parent.MyVoParent;
import com.YuanXu.WebWorker.FormBean.WebWorkerForm;

/**
 * 
 * @author Lyra_Phoenix
 *
 */
public interface WebWorkerService extends MyServiceInterface{
	
	public String[] dologin(WebWorkerForm dataForm);
	
	public String[] updateName(WebWorkerForm dataForm);
	
	public String[] updatePw(WebWorkerForm dataForm);
	
	// 终极管理员调用方法
	public MyVoParent add_admin(FormBeanParent dataParentForm);
	public MyVoParent update_admin(FormBeanParent dataParentForm);
	public MyVoParent delete_admin(FormBeanParent dataParentForm);
}
