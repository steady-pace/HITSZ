package com.YuanXu.WebWorker.Service;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

import com.YuanXu.Util.Filter.HTTPSessionUtil;
import com.YuanXu.Util.Parent.FormBeanParent;
import com.YuanXu.Util.Parent.MyServiceParent;
import com.YuanXu.Util.Parent.MyVoParent;
import com.YuanXu.Util.Util.JsonEasyUI;
import com.YuanXu.Util.Util.QueryResult;
import com.YuanXu.WebWorker.Entity.T_LoseGoods;
import com.YuanXu.WebWorker.Entity.T_Member;
import com.YuanXu.WebWorker.Entity.T_WebWorker;
import com.YuanXu.WebWorker.Enum.EnumLosegoodsStatus;
import com.YuanXu.WebWorker.FormBean.LoseGoodsForm;
import com.YuanXu.WebWorker.Vo.VoLoseGoods;


/**
 * 失物的方法实现类
 * @author Lyra_Phoenix
 *
 */
@Service("loseGoodsService")
@Scope("prototype")
public class LoseGoodsServiceImpl extends MyServiceParent implements LoseGoodsService{
	
	@Override
	public MyVoParent add(FormBeanParent dataParentForm)
			throws FileNotFoundException, IOException {
		LoseGoodsForm data = (LoseGoodsForm)dataParentForm;
		T_LoseGoods entity = new T_LoseGoods();
		List<Object> pa = new ArrayList<Object>();
		
		entity.setF_lId(UUID.randomUUID().toString());
		entity.setF_lDescribe(data.getF_lDescribe());
		pa.add(EnumLosegoodsStatus.GOODS_GET);
		long pageSize = super.findCount_all("select count(*) from T_LoseGoods where f_lStatus=?", pa);
		pa.clear();
		pa.add(EnumLosegoodsStatus.GOODS_LOSE);
		long pageSize1 = super.findCount_all("select count(*) from T_LoseGoods where f_lStatus=?", pa);
		String NO_lose = pageSize+ pageSize1 + 1 + "";
		entity.setF_lNo(NO_lose);
		entity.setF_lPhone(data.getF_lPhone());
		entity.setF_lType(data.getF_lType());
		entity.setF_lStatus(EnumLosegoodsStatus.GOODS_LOSE);
		
		String adminId = (String)HTTPSessionUtil.getObject(HTTPSessionUtil.WebWorkerPower.webWorker_adminId.getKey());
		String SqlFind = " from T_WebWorker where f_wwId=? " ;
		List<Object> listHQL = new ArrayList<Object>();
		listHQL.add(adminId);
		T_WebWorker pwd = (T_WebWorker)super.find(SqlFind, listHQL);
		if(pwd != null){
			entity.setF_lmName(pwd.getF_wwName());
			entity.setF_lmNo(pwd.getF_wwStudentNo());
			entity.setF_lmPhone(pwd.getF_wwContact());
		}
		super.save(entity);
		return result;
	}
	
	@Override
	public MyVoParent getData(FormBeanParent dataParentForm) {
		LoseGoodsForm data = (LoseGoodsForm)dataParentForm;
		JsonEasyUI<VoLoseGoods> js = new JsonEasyUI<VoLoseGoods>();
		QueryResult<T_LoseGoods> qr = super.getData("T_LoseGoods", null, null, data);
		for(T_LoseGoods entity:qr.getResultList()){
			VoLoseGoods vo = new VoLoseGoods(entity);
			js.getRows().add(vo);
		}
		js.setTotal(qr.getTotalrecord());
		return js;
	}
		
	
	@Override
	public MyVoParent delete(FormBeanParent dataParentForm) {
		return null;
	}
	
	
	@Override
	public MyVoParent doOpreate(FormBeanParent dataParentForm) {
		LoseGoodsForm data = (LoseGoodsForm)dataParentForm;
		T_LoseGoods entity = (T_LoseGoods) super.find(T_LoseGoods.class, data.getF_lId());
		if(entity.getF_lStatus()==EnumLosegoodsStatus.GOODS_LOSE){
			entity.setF_lStatus(EnumLosegoodsStatus.GOODS_GET);
		}else{
		}
		return result;
	}

	@Override
	public void initClassName() {
		super.setGetDateWhere(null, null);
		super.setTableClass(T_Member.class);
		super.setVoClass(T_Member.class);
		super.setIdName("f_mId");
	}
	

}
