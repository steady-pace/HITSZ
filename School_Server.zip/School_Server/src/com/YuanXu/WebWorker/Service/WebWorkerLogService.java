package com.YuanXu.WebWorker.Service;

import com.YuanXu.Util.Util.JsonEasyUI;
import com.YuanXu.WebWorker.FormBean.WebWorkerLogForm;
import com.YuanXu.WebWorker.Vo.VoWebWorkerLog;

/**
 * 网络部工作人员日志接口类
 * @author 罗培彬
 *
 */
public interface WebWorkerLogService {
	public void makeLog(String fWLogDoUser,String fWLogUserId,String fWLogDoStr,String fWLogDoResult,String fWSystem,String fWBrowser);
	public JsonEasyUI<VoWebWorkerLog> getData(WebWorkerLogForm dataForm);
	public JsonEasyUI<VoWebWorkerLog> queryOneData(WebWorkerLogForm dataForm);
	public JsonEasyUI<VoWebWorkerLog> queryOneOperateData(WebWorkerLogForm dataForm);
}
