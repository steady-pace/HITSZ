package com.YuanXu.WebWorker.Service;

import java.util.List;

import com.YuanXu.Util.Parent.MyServiceInterface;
import com.YuanXu.WebWorker.Entity.T_Member;

public interface MemberService extends MyServiceInterface{
	public List<T_Member> getAll();
}
