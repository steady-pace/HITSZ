package com.YuanXu.WebWorker.Service;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.URLDecoder;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.annotation.Resource;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

import com.YuanXu.Util.Filter.HTTPSessionUtil;
import com.YuanXu.Util.Parent.FormBeanParent;
import com.YuanXu.Util.Parent.MyServiceParent;
import com.YuanXu.Util.Parent.MyVoParent;
import com.YuanXu.Util.RSA.BytesUtil;
import com.YuanXu.Util.RSA.RSAUtil;
import com.YuanXu.Util.Util.DateUtil;
import com.YuanXu.Util.Util.FileUtil;
import com.YuanXu.Util.Util.JsonEasyUI;
import com.YuanXu.Util.Util.QueryResult;
import com.YuanXu.WebWorker.Entity.T_WebRole;
import com.YuanXu.WebWorker.Entity.T_WebWorker;
import com.YuanXu.WebWorker.FormBean.WebWorkerForm;
import com.YuanXu.WebWorker.Vo.VoWebWorker;

/**
 * 
 * @author Lyra_Phoenix
 *
 */
@Service("webWorkerService")
@Scope("prototype")
public class WebWorkerServiceImpl extends MyServiceParent implements WebWorkerService{

	private String tableName = "T_WebWorker";
	private String hql = "from " + tableName;
	@Resource
	private WebWorkerLogService webWorkerLogService;
	
	private String webWorkerName = (String) HTTPSessionUtil.getObject(HTTPSessionUtil.WebWorkerPower.webWorker_adminName.getKey());
	private String webWorkerId = (String) HTTPSessionUtil.getObject(HTTPSessionUtil.WebWorkerPower.webWorker_adminId.getKey());
	
	public String[] dologin(WebWorkerForm dataForm) {
		// TODO Auto-generated method stub
		//判断验证码
		if(dataForm.getRandom() == null || dataForm.getRandom().length() == 0){
			webWorkerLogService.makeLog("未知", null, "请求后台登录", "验证码为NULL！",dataForm.getF_wSystem(),dataForm.getF_wBrowser());
			return new String[]{"error","验证码错误！"};
		}
		if(!dataForm.getRandom().toLowerCase().equals(HTTPSessionUtil.getObject(HTTPSessionUtil.RANDOM))){
			webWorkerLogService.makeLog("未知", null, "请求后台登录", "验证码为NULL！",dataForm.getF_wSystem(),dataForm.getF_wBrowser());
			return new String[]{"error","验证码错误！"};
		}
		byte[] en_result = BytesUtil.hexStringToBytes(dataForm.getF_wwPw());
		byte[] en_name = BytesUtil.hexStringToBytes(dataForm.getF_wwName());
		byte[] de_result;
		byte[] de_name;
		String adminName = "";
		try {
			de_result = RSAUtil.decrypt(RSAUtil.getKeyPair(FileUtil.getKeyPairFilePath()).getPrivate(), en_result);
			StringBuffer sb = new StringBuffer();
			sb.append(new String(de_result));
			String adminPw = sb.reverse().toString();
			adminPw = URLDecoder.decode(adminPw, "UTF-8");
			de_name = RSAUtil.decrypt(RSAUtil.getKeyPair(FileUtil.getKeyPairFilePath()).getPrivate(), en_name);
			StringBuffer sbname = new StringBuffer();
			sbname.append(new String(de_name));
			adminName = sbname.reverse().toString();
			adminName = URLDecoder.decode(adminName, "UTF-8");
			T_WebWorker admin = null;
			String hql = this.hql + " where f_wwName=?";
			List<Object> wp = new ArrayList<Object>();
			wp.add(adminName);
			admin = (T_WebWorker) this.find(hql,wp);
			if(admin == null || !admin.getF_wwPw().equals(adminPw)){
				webWorkerLogService.makeLog(adminName, null, "请求后台登录", "账号或密码错误！",dataForm.getF_wSystem(),dataForm.getF_wBrowser());
				return new String[]{"error","账号或密码错误！"};
			}
			
			String loginTime = null;
			if(admin.getF_wwLoginTime() != null){
				loginTime = DateUtil.dateToString(admin.getF_wwLoginTime());
			}else{
				loginTime = "第一次登录";
			}
			HTTPSessionUtil.putWebWorker(adminName, admin.getF_wwId(), loginTime, admin.getT_webRole().getF_wrPower());
			admin.setF_wwLoginTime(new Date());
			webWorkerLogService.makeLog(adminName, admin.getF_wwId(), "请求后台登录", "成功登录！",dataForm.getF_wSystem(),dataForm.getF_wBrowser());
			return new String[]{"success","成功"};
		} catch (Exception e) {
			e.printStackTrace();
			webWorkerLogService.makeLog(adminName, null, "请求后台登录", "登录异常！",dataForm.getF_wSystem(),dataForm.getF_wBrowser());
			return new String[]{"error","登录异常"};
		}
	}

	public String[] updateName(WebWorkerForm dataForm) {
		// TODO Auto-generated method stub
		return null;
	}

	public String[] updatePw(WebWorkerForm dataForm) {
		// TODO Auto-generated method stub
		String oldAdminName = (String) HTTPSessionUtil.getObject(HTTPSessionUtil.WebWorkerPower.webWorker_adminName.getKey());
		String hql = this.hql + " where f_wwName=?";
		List<Object> wp = new ArrayList<Object>();
		wp.add(oldAdminName);
		T_WebWorker admin = (T_WebWorker) this.find(hql,wp);
		if(!admin.getF_wwPw().equals(dataForm.getOldPw())){
			webWorkerLogService.makeLog(oldAdminName, admin.getF_wwId(), "请求修改密码", "密码错误！",dataForm.getF_wSystem(),dataForm.getF_wBrowser());
			return new String[]{"error","密码错误！"};
		}
		admin.setF_wwPw(dataForm.getNewPw());
		HTTPSessionUtil.exitWebWorker();
		webWorkerLogService.makeLog(oldAdminName, admin.getF_wwId(), "请求修改密码", "修改成功！",dataForm.getF_wSystem(),dataForm.getF_wBrowser());
		return new String[]{"success","成功修改登录密码！请重新登录！"};
	}

	public MyVoParent add(FormBeanParent dataParentForm)
			throws FileNotFoundException, IOException {
		// TODO Auto-generated method stub
		WebWorkerForm dataForm = (WebWorkerForm) dataParentForm;
		List<Object> w = new ArrayList<Object>();
		String wStr = hql + " where f_wwName=?";
		w.add(dataForm.getF_wwName());
		T_WebWorker admin = (T_WebWorker) super.find(wStr, w);
		if(admin != null){
			result.isError("该账号已经存在!");
			webWorkerLogService.makeLog(webWorkerName, webWorkerId, "添加网络部人员！", "添加失败,账号已经存在！",dataForm.getF_wSystem(),dataForm.getF_wBrowser());
			return result;
		}
		
		T_WebRole role = (T_WebRole) super.find(T_WebRole.class, dataForm.getT_webRole());
		if(role == null){
			result.isError("您选择的角色不存在!");
			webWorkerLogService.makeLog(webWorkerName, webWorkerId, "添加网络部人员！", "添加失败,选择的角色不存在！",dataForm.getF_wSystem(),dataForm.getF_wBrowser());
			return result;
		}
		
		admin = new T_WebWorker(dataForm.getF_wwName(),dataForm.getF_wwPw(),dataForm.getF_wwContact(),role,"other" , dataForm.getF_wwStudentNo());
		webWorkerLogService.makeLog(webWorkerName, webWorkerId, "添加网络部人员！", "添加成功！",dataForm.getF_wSystem(),dataForm.getF_wBrowser());
		super.save(admin);
		return result;
	}

	public MyVoParent delete(FormBeanParent dataParentForm) {
		// TODO Auto-generated method stub
		WebWorkerForm dataForm = (WebWorkerForm) dataParentForm;
		String ids[] = dataForm.getDeleDataJson().split("\\[")[1].split("\\]")[0].split(",");
		// 错误拼接字符串
		String error = null;
		for(String id : ids){
			String idw[] = id.split("\"")[1].split("\"");
			T_WebWorker admin = (T_WebWorker) super.find(T_WebWorker.class, idw[0]);
			// 判断是否有权限更新用户资料
			if(admin.getF_newFrom().equals("admin")){
				error += admin.getF_wwName()+";";
			}else{
				dataForm.setDeleDataJson("[\""+idw[0]+"\"]");
				super.dele(dataForm, tableName, "f_wwId");
			}
		}
		if(error!=null){
			result.isError("账号"+error+"是由终极管理员创建的，您无权对其进行操作!");
			webWorkerLogService.makeLog(webWorkerName, webWorkerId, "删除网络部人员！", "删除失败,账号"+error+"是由终极管理员创建的，无权对其进行操作！",dataForm.getF_wSystem(),dataForm.getF_wBrowser());
			return result;
		}
		super.dele(dataForm, tableName, "f_wwId");
		webWorkerLogService.makeLog(webWorkerName, webWorkerId, "删除网络部人员！", "删除成功",dataForm.getF_wSystem(),dataForm.getF_wBrowser());
		return result;
	}

	public MyVoParent doOpreate(FormBeanParent dataParentForm) {
		// TODO Auto-generated method stub
		
		return null;
	}

	public MyVoParent getData(FormBeanParent dataParentForm) {
		WebWorkerForm dataForm = (WebWorkerForm) dataParentForm;
		JsonEasyUI<VoWebWorker> jsonEasyUI = new JsonEasyUI<VoWebWorker>();
		QueryResult<T_WebWorker> qr = super.getData(tableName, null,null,dataForm);
		for(T_WebWorker t : qr.getResultList()){
			VoWebWorker vo = new VoWebWorker(t);
			jsonEasyUI.getRows().add(vo);
		}
		jsonEasyUI.setTotal(qr.getTotalrecord());
		return jsonEasyUI;
	}

	public MyVoParent update(FormBeanParent dataParentForm)
			throws FileNotFoundException, IOException {
		// TODO Auto-generated method stub
		WebWorkerForm dataForm = (WebWorkerForm) dataParentForm;
		List<Object> w = new ArrayList<Object>();
		String wStr = hql + " where f_wwName=?";
		w.add(dataForm.getF_wwName());
		T_WebWorker admin = (T_WebWorker) super.find(wStr, w);
		// 需要判断找到的账号ID与传进来的ID是否相等，如果是相等的，那么说明没有修改账号，只是修改了信息
		if(admin != null && !admin.getF_wwId().equals(dataForm.getF_wwId())){
			result.isError("该账号已经存在!");
			webWorkerLogService.makeLog(webWorkerName, webWorkerId, "更改网络部人员信息！", "更改失败,账号已经存在！",dataForm.getF_wSystem(),dataForm.getF_wBrowser());
			return result;
		}
		List<Object> w1 = new ArrayList<Object>();
		String wStr1 = "from T_WebRole where f_wrId=?";
		w1.add(dataForm.getT_webRole());
		T_WebRole role = (T_WebRole) super.find(wStr1, w1);
		if(role == null){
			result.isError("您选择的角色不存在!");
			webWorkerLogService.makeLog(webWorkerName, webWorkerId, "更改网络部人员信息！", "更改失败,选择的角色不存在！",dataForm.getF_wSystem(),dataForm.getF_wBrowser());
			return result;
		}
		
		wStr = hql + " where f_wwId=?";
		admin = (T_WebWorker) super.find(wStr, w);
		// 判断是否有权限更新用户资料
		if(admin.getF_newFrom().contains("admin")){
			result.isError("账号"+admin.getF_wwName()+"是由终极管理员创建的，您没有权限对其进行操作!");
			webWorkerLogService.makeLog(webWorkerName, webWorkerId, "更改网络部人员信息！", "更改失败,账号"+admin.getF_wwName()+"是由终极管理员创建的，没有权限对其进行操作！",dataForm.getF_wSystem(),dataForm.getF_wBrowser());
			return result;
		}else{
			admin.setF_wwName(dataForm.getF_wwName());
			admin.setF_wwPw(dataForm.getF_wwPw());
			admin.setF_wwContact(dataForm.getF_wwContact());
			admin.setT_webRole(role);
		}
		webWorkerLogService.makeLog(webWorkerName, webWorkerId, "更改网络部人员信息！", "更改成功",dataForm.getF_wSystem(),dataForm.getF_wBrowser());
		return result;
	}

	@Override
	public void initClassName() {
		// TODO Auto-generated method stub
		
	}

	public MyVoParent add_admin(FormBeanParent dataParentForm) {
		// TODO Auto-generated method stub
		WebWorkerForm dataForm = (WebWorkerForm) dataParentForm;
		List<Object> w = new ArrayList<Object>();
		String wStr = hql + " where f_wwName=?";
		w.add(dataForm.getF_wwName());
		T_WebWorker admin = (T_WebWorker) super.find(wStr, w);
		if(admin != null){
			result.isError("该账号已经存在!");
			return result;
		}
		
		T_WebRole role = (T_WebRole) super.find(T_WebRole.class, dataForm.getT_webRole());
		if(role == null){
			result.isError("您选择的角色不存在!");
			return result;
		}
		
		
		admin = new T_WebWorker(dataForm.getF_wwName(),dataForm.getF_wwPw(),dataForm.getF_wwContact(),role,"admin" ,dataForm.getF_wwStudentNo() );
		super.save(admin);
		return result;
	}

	public MyVoParent delete_admin(FormBeanParent dataParentForm) {
		// TODO Auto-generated method stub
		WebWorkerForm dataForm = (WebWorkerForm) dataParentForm;
		super.dele(dataForm, tableName, "f_wwId");
		return result;
	}

	public MyVoParent update_admin(FormBeanParent dataParentForm) {
		// TODO Auto-generated method stub
		WebWorkerForm dataForm = (WebWorkerForm) dataParentForm;
		List<Object> w = new ArrayList<Object>();
		String wStr = hql + " where f_wwName=?";
		w.add(dataForm.getF_wwName());
		T_WebWorker admin = (T_WebWorker) super.find(wStr, w);
		// 需要判断找到的账号ID与传进来的ID是否相等，如果是相等的，那么说明没有修改账号，只是修改了信息
		if(admin != null && !admin.getF_wwId().equals(dataForm.getF_wwId())){
			result.isError("该账号已经存在!");
			return result;
		}
		List<Object> w1 = new ArrayList<Object>();
		String wStr1 = "from T_WebRole where f_wrId=?";
		w1.add(dataForm.getT_webRole());
		T_WebRole role = (T_WebRole) super.find(wStr1, w1);
		if(role == null){
			result.isError("您选择的角色不存在!");
			return result;
		}
		
		w.clear();
		w.add(dataForm.getF_wwId());
		wStr = hql + " where f_wwId=?";
		admin = (T_WebWorker) super.find(wStr, w);
		admin.setF_wwName(dataForm.getF_wwName());
		admin.setF_wwPw(dataForm.getF_wwPw());
		admin.setF_wwContact(dataForm.getF_wwContact());
		admin.setT_webRole(role);
		return result;
	}

}
