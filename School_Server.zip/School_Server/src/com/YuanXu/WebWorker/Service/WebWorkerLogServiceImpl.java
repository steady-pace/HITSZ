package com.YuanXu.WebWorker.Service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

import com.YuanXu.Util.Parent.MyServiceParent;
import com.YuanXu.Util.Util.GetIPUtil;
import com.YuanXu.Util.Util.JsonEasyUI;
import com.YuanXu.Util.Util.QueryResult;
import com.YuanXu.WebWorker.Entity.T_WebWorkerLog;
import com.YuanXu.WebWorker.FormBean.WebWorkerLogForm;
import com.YuanXu.WebWorker.Vo.VoWebWorkerLog;
/**
 * 网络部工作人员日志实现类
 * @author 罗培彬
 *
 */
@Service("webWorkerLogService")
@Scope("prototype")
public class WebWorkerLogServiceImpl extends MyServiceParent implements WebWorkerLogService{
	
	private String tableName = "T_WebWorkerLog";
	
	@Override
	public void initClassName() {
		// TODO Auto-generated method stub
	}
	
	public JsonEasyUI<VoWebWorkerLog> getData(WebWorkerLogForm dataForm) {
		// TODO Auto-generated method stub
		JsonEasyUI<VoWebWorkerLog> jsonEasyUI = new JsonEasyUI<VoWebWorkerLog>();
		List<VoWebWorkerLog> voLogs = new ArrayList<VoWebWorkerLog>();
		
		// 查询所有登录记录
		QueryResult<T_WebWorkerLog> qr = this.getData(tableName, " f_wLogDoStr like '%登录%'",null, dataForm);
		for(T_WebWorkerLog tLog : qr.getResultList()){
			VoWebWorkerLog voLog = new VoWebWorkerLog(tLog);
			voLogs.add(voLog);
		}
		jsonEasyUI.setRows(voLogs);
		jsonEasyUI.setTotal(qr.getTotalrecord());
		return jsonEasyUI;
	}
	
	public JsonEasyUI<VoWebWorkerLog> queryOneData(WebWorkerLogForm dataForm) {
		// TODO Auto-generated method stub
		JsonEasyUI<VoWebWorkerLog> jsonEasyUI = new JsonEasyUI<VoWebWorkerLog>();
		List<VoWebWorkerLog> voLogs = new ArrayList<VoWebWorkerLog>();
		QueryResult<T_WebWorkerLog> qr = null;
		if(dataForm.getId()!=null||!dataForm.getId().equals("null")){
			String where = "f_wLogUserId=?";
			List<Object> list = new ArrayList<Object>();
			list.add(dataForm.getId());
			// 单个查询
			qr = this.getData(tableName, where,list, dataForm);
		}else{
			// 单个查询
			qr = this.getData(tableName, null,null, dataForm);
		}
		
		for(T_WebWorkerLog tLog : qr.getResultList()){
			VoWebWorkerLog voLog = new VoWebWorkerLog(tLog);
			voLogs.add(voLog);
		}
		jsonEasyUI.setRows(voLogs);
		jsonEasyUI.setTotal(qr.getTotalrecord());
		return jsonEasyUI;
	}
	
	// 获取单个人员的操作记录
	public JsonEasyUI<VoWebWorkerLog> queryOneOperateData(WebWorkerLogForm dataForm) {
		// TODO Auto-generated method stub
		JsonEasyUI<VoWebWorkerLog> jsonEasyUI = new JsonEasyUI<VoWebWorkerLog>();
		List<VoWebWorkerLog> voLogs = new ArrayList<VoWebWorkerLog>();
		QueryResult<T_WebWorkerLog> qr = null;
		if(dataForm.getId()!=null||!dataForm.getId().equals("null")){
			String where = "f_wLogUserId=? and f_wLogDoStr not like '%登录%'";
			List<Object> list = new ArrayList<Object>();
			list.add(dataForm.getId());
			// 单个查询
			qr = this.getData(tableName, where,list, dataForm);
		}else{
			// 查询所有
			qr = this.getData(tableName, null,null, dataForm);
		}
		
		for(T_WebWorkerLog tLog : qr.getResultList()){
			VoWebWorkerLog voLog = new VoWebWorkerLog(tLog);
			voLogs.add(voLog);
		}
		jsonEasyUI.setRows(voLogs);
		jsonEasyUI.setTotal(qr.getTotalrecord());
		return jsonEasyUI;
	}

	public void makeLog(String fWLogDoUser,String fWLogUserId, String fWLogDoStr, String fWLogDoResult,String fWSystem,String fWBrowser) {
		// TODO Auto-generated method stub
		T_WebWorkerLog t = new T_WebWorkerLog(new Date(),GetIPUtil.getMyIP(),fWLogDoUser,fWLogUserId,fWLogDoStr,fWLogDoResult,fWSystem,fWBrowser);
		this.save(t);
	}

	public String getTraceInfo(){  
        StringBuffer sb = new StringBuffer();   
        StackTraceElement[] stacks = new Throwable().getStackTrace();  
        sb.append("class: ").append(stacks[1].getClassName()).append("; method: ").append(stacks[1].getMethodName());  
        return sb.toString();  
    }
}
