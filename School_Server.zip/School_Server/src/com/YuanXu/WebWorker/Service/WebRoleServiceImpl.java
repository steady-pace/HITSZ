package com.YuanXu.WebWorker.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import javax.annotation.Resource;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

import com.YuanXu.Util.Filter.HTTPSessionUtil;
import com.YuanXu.Util.Parent.FormBeanParent;
import com.YuanXu.Util.Parent.MyServiceParent;
import com.YuanXu.Util.Parent.MyVoParent;
import com.YuanXu.WebWorker.Entity.T_WebRole;
import com.YuanXu.WebWorker.Entity.T_WebWorker;
import com.YuanXu.WebWorker.FormBean.WebRoleForm;
import com.YuanXu.WebWorker.Vo.VoWebRole;

/**
 * 
 * @author Lyra_Phoenix
 *
 */
@Service("webRoleService")
@Scope("prototype")
public class WebRoleServiceImpl extends MyServiceParent implements WebRoleService{

	String tableName = "T_WebRole";
	
	@Resource
	private WebWorkerLogService webWorkerLogService;
	
	private String webWorkerName = (String) HTTPSessionUtil.getObject(HTTPSessionUtil.WebWorkerPower.webWorker_adminName.getKey());
	private String webWorkerId = (String) HTTPSessionUtil.getObject(HTTPSessionUtil.WebWorkerPower.webWorker_adminId.getKey());
	
	@Override
	public void initClassName() {
		super.setTableClass(T_WebRole.class);
		super.setVoClass(VoWebRole.class);
		super.setIdName("f_wrId");
		//获取easyui列表传特殊条件
		super.setGetDateWhere(null, null);
	}
	
	@SuppressWarnings("unchecked")
	public MyVoParent add(FormBeanParent dataForm){
		WebRoleForm data = (WebRoleForm)dataForm;
		List<Object> li = new ArrayList<Object>();
		li.add(data.getF_wrName());
		List<T_WebRole> list = (List<T_WebRole>)super.findAll("from T_WebRole where f_wrName=?", li);
		if(list != null && list.size() > 0 ){
			result.isError("该角色已存在,不能重复添加!");
			webWorkerLogService.makeLog(webWorkerName, webWorkerId, "添加网络部角色！", "添加失败,角色已经存在！","","");
			return result;
		}else{
			T_WebRole role = new T_WebRole();
			role.setF_wrId(UUID.randomUUID().toString());
			role.setF_wrDescribe(data.getF_wrDescribe());
			role.setF_wrName(data.getF_wrName());
			String power = "";
			for(int i = 0; i < data.getF_wrPowers().length; i++){
				power += data.getF_wrPowers()[i] + ";";
			}
			role.setF_wrPower(power);
			role.setF_newFrom("other");
			
			super.save(role);
			webWorkerLogService.makeLog(webWorkerName, webWorkerId, "添加网络部角色！", "添加成功！","","");
			return result;
		}
	}
	
	@SuppressWarnings("unchecked")
	public MyVoParent update(FormBeanParent dataForm){
		WebRoleForm data = (WebRoleForm)dataForm;
		List<Object> li = new ArrayList<Object>();
		li.add(data.getF_wrName());
		List<T_WebRole> list = (List<T_WebRole>)super.findAll("from T_WebRole where f_wrName=?", li);
		T_WebRole role = (T_WebRole)super.find(T_WebRole.class,data.getId());
		if(list != null && list.size() > 0){
			for(int i=0;i<list.size();i++){
				if(data.getId().equals(list.get(i).getF_wrId())){
					if(role == null){
						result.isError("该角色已不存在,修改失败!");
						webWorkerLogService.makeLog(webWorkerName, webWorkerId, "修改网络部角色！", "修改失败,角色已经不存在！","","");
						return result;
					}
				}else{
					result.isError("该角色已存在,不能重复!");
					webWorkerLogService.makeLog(webWorkerName, webWorkerId, "修改网络部角色！", "修改失败,角色已经存在！","","");
					return result;
				}
			}
		}
		if(role != null){
			if(role.getF_newFrom().equals("other")){
				role.setF_wrName(data.getF_wrName());
				role.setF_wrDescribe(data.getF_wrDescribe());
				String power = "";
				for(int i = 0; i < data.getF_wrPowers().length; i++){
					power += data.getF_wrPowers()[i] + ";";
				}
				role.setF_wrPower(power);
			}else{
				result.isError("该角色由终极管理员创建，您无权对其进行修改！");
				webWorkerLogService.makeLog(webWorkerName, webWorkerId, "修改网络部角色！", "角色由终极管理员创建，无权对其进行修改！","","");
				return result;
			}
		}else{
			result.isError("该角色已经不存在,修改失败!");
			webWorkerLogService.makeLog(webWorkerName, webWorkerId, "修改网络部角色！", "修改失败,角色已经不存在！","","");
			return result;
		}
		webWorkerLogService.makeLog(webWorkerName, webWorkerId, "修改网络部角色！", "修改成功！","","");
		return result;
	}

	@SuppressWarnings("unchecked")
	public MyVoParent delete(FormBeanParent dataForm){
		List<T_WebRole> list = (List<T_WebRole>)super.finddele(dataForm, tableName, "f_wrId");
		if(list != null && list.size() > 0){
			for(int i=0;i<list.size();i++){
				List<Object> li = new ArrayList<Object>();
				li.add(list.get(i));
				List<T_WebWorker> workList = (List<T_WebWorker>)super.findAll("from T_WebWorker where t_webRole=?", li);
				if(workList != null && workList.size() > 0){
					for(int n=0;n<workList.size();n++){
						if(!list.get(i).getF_wrId().equals(workList.get(n).getF_wwId())){
							result.isError("角色【"+list.get(i).getF_wrName()+"】已关联了工作人员，不能直接删除!");
							webWorkerLogService.makeLog(webWorkerName, webWorkerId, "删除网络部角色！", "删除失败,角色【"+list.get(i).getF_wrName()+"】已关联了工作人员，不能直接删除！","","");
							return result;
						}
					}
				}
			}
		}
		// 将其所有要删除的角色都进行判断，如果工作人员没有权利删除就禁止删除
		String error = "";
		for(T_WebRole r : list){
			if(!r.getF_newFrom().equals("other")){
				// 拼接错误字符串
				error += r.getF_wrName();
			}
		}
		if(error==null || error.equals("")){
			super.dele(dataForm, tableName, "f_wrId");
			webWorkerLogService.makeLog(webWorkerName, webWorkerId, "删除网络部角色！", "删除成功！","","");
			return result;
		}else{
			result.isError("该角色由终极管理员创建,您无权对其进行删除！");
			webWorkerLogService.makeLog(webWorkerName, webWorkerId, "删除网络部角色！", "删除失败,角色由终极管理员创建,无权对其进行删除！","","");
			return result;
		}
	}
	
	@SuppressWarnings("unchecked")
	public List<VoWebRole> getAll() {
		List<VoWebRole> voRoles = new ArrayList<VoWebRole>();
		String hql = "from T_WebRole";
		
		List<T_WebRole> tDepartments = (List<T_WebRole>) this.findAll(hql,null );
		if(tDepartments!=null){
			for(T_WebRole t : tDepartments){
				VoWebRole role = new VoWebRole(t);
				voRoles.add(role);
			}
		}
		return voRoles;
	}

	@SuppressWarnings("unchecked")
	public MyVoParent add_admin(FormBeanParent dataForm) {
		// TODO Auto-generated method stub
		WebRoleForm data = (WebRoleForm)dataForm;
		List<Object> li = new ArrayList<Object>();
		li.add(data.getF_wrName());
		List<T_WebRole> list = (List<T_WebRole>)super.findAll("from T_WebRole where f_wrName=?", li);
		if(list != null && list.size() > 0 ){
			result.isError("该角色已存在,不能重复添加!");
			return result;
		}else{
			T_WebRole role = new T_WebRole();
			role.setF_wrId(UUID.randomUUID().toString());
			role.setF_wrDescribe(data.getF_wrDescribe());
			role.setF_wrName(data.getF_wrName());
			String power = "";
			for(int i = 0; i < data.getF_wrPowers().length; i++){
				power += data.getF_wrPowers()[i] + ";";
			}
			role.setF_wrPower(power);
			role.setF_newFrom("admin");
			super.save(role);
			return result;
		}
	}

	@SuppressWarnings("unchecked")
	public MyVoParent delete_admin(FormBeanParent dataForm) {
		// TODO Auto-generated method stub
		List<T_WebRole> list = (List<T_WebRole>)super.finddele(dataForm, tableName, "f_wrId");
		if(list != null && list.size() > 0){
			for(int i=0;i<list.size();i++){
				List<Object> li = new ArrayList<Object>();
				li.add(list.get(i));
				List<T_WebWorker> workList = (List<T_WebWorker>)super.findAll("from T_WebWorker where t_webRole=?", li);
				if(workList != null && workList.size() > 0){
					for(int n=0;n<workList.size();n++){
						if(!list.get(i).getF_wrId().equals(workList.get(n).getF_wwId())){
							result.isError("角色【"+list.get(i).getF_wrName()+"】已关联了工作人员，不能直接删除!");
							return result;
						}
					}
				}
			}
		}
		
		super.dele(dataForm, tableName, "f_wrId");
		return result;
	}

	@SuppressWarnings("unchecked")
	public MyVoParent update_admin(FormBeanParent dataForm) {
		// TODO Auto-generated method stub
		WebRoleForm data = (WebRoleForm)dataForm;
		List<Object> li = new ArrayList<Object>();
		li.add(data.getF_wrName());
		List<T_WebRole> list = (List<T_WebRole>)super.findAll("from T_WebRole where f_wrName=?", li);
		T_WebRole role = (T_WebRole)super.find(T_WebRole.class,data.getId());
		if(list != null && list.size() > 0){
			for(int i=0;i<list.size();i++){
				if(data.getId().equals(list.get(i).getF_wrId())){
					if(role == null){
						result.isError("该角色已不存在,修改失败!");
						return result;
					}
				}else{
					result.isError("该角色已存在,不能重复!");
					return result;
				}
			}
		}
		if(role != null){
			role.setF_wrName(data.getF_wrName());
			role.setF_wrDescribe(data.getF_wrDescribe());
			String power = "";
			for(int i = 0; i < data.getF_wrPowers().length; i++){
				power += data.getF_wrPowers()[i] + ";";
			}
			role.setF_wrPower(power);
			return result;
		}else{
			result.isError("该角色已经不存在,修改失败!");
			return result;
		}
	}

}
