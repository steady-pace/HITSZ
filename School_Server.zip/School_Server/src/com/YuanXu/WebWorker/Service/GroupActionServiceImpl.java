package com.YuanXu.WebWorker.Service;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

import com.YuanXu.Util.Filter.HTTPSessionUtil;
import com.YuanXu.Util.Parent.FormBeanParent;
import com.YuanXu.Util.Parent.MyServiceParent;
import com.YuanXu.Util.Parent.MyVoParent;
import com.YuanXu.Util.Util.JsonEasyUI;
import com.YuanXu.Util.Util.QueryResult;
import com.YuanXu.WebWorker.Entity.T_GetGoods;
import com.YuanXu.WebWorker.Entity.T_GroupAction;
import com.YuanXu.WebWorker.Enum.EnumLosegoodsStatus;
import com.YuanXu.WebWorker.FormBean.GetGoodsForm;
import com.YuanXu.WebWorker.FormBean.GroupActionForm;
import com.YuanXu.WebWorker.Vo.VoGroupAction;
/**
 * 
 * @author Lyra_Phoenix
 *
 */
@Service("groupActionService")
@Scope("prototype")
public class GroupActionServiceImpl extends MyServiceParent implements GroupActionService{
	private String tableName = "T_GroupAction";
	private String hql = "from " + tableName;
	@Override
	public MyVoParent add(FormBeanParent dataParentForm)
			throws FileNotFoundException, IOException {
		GroupActionForm data = (GroupActionForm)dataParentForm;
	
		T_GroupAction entity = new T_GroupAction();
		entity.setF_gaId(UUID.randomUUID().toString());
		entity.setF_gaAddress(data.getF_gaAddress());
		entity.setF_gaBegin(data.getF_gaBegin());
		entity.setF_gaEnd(data.getF_gaEnd());
		entity.setF_gaHit(0);
		entity.setF_gaInfo(data.getF_gaInfo());
		entity.setF_gaName(data.getF_gaName());
		entity.setF_gaPublic(data.getF_gaPublic());
		entity.setF_gaSponsors(data.getF_gaSponsors());
		entity.setF_gaZan(0);
		entity.setF_gcName(data.getF_gcName());
		super.save(entity);
		return result;
	}
	
	@Override
	public MyVoParent getData(FormBeanParent dataParentForm) {
		GroupActionForm data = (GroupActionForm)dataParentForm;
		JsonEasyUI<VoGroupAction> js = new JsonEasyUI<VoGroupAction>();
		//QueryResult<T_GroupAction> qr = super.get
		
		String hql = this.hql + " where f_wwId=?";
		List<Object> wp = new ArrayList<Object>();
		String adminId = (String)HTTPSessionUtil.getObject(HTTPSessionUtil.WebWorkerPower.webWorker_adminId.getKey());
		wp.add(adminId);
		
		QueryResult<T_GroupAction> qr = super.getData(tableName, null, null, data);
		for(T_GroupAction entity:qr.getResultList()){
			VoGroupAction vo = new VoGroupAction(entity);
			js.getRows().add(vo);
		}
		js.setTotal(qr.getTotalrecord());
		return js;
	}
		
	
	@Override
	public MyVoParent delete(FormBeanParent dataParentForm) {
		return null;
	}
	
	
	@Override
	public MyVoParent doOpreate(FormBeanParent dataParentForm) {
		GetGoodsForm data = (GetGoodsForm)dataParentForm;
		T_GetGoods entity = (T_GetGoods) super.find(T_GetGoods.class, data.getF_gId());
		if(entity.getF_gStatus() == EnumLosegoodsStatus.PENSON_LOSE){
			entity.setF_gStatus(EnumLosegoodsStatus.PENSON_GET);
		}else{
		}
		return result;
	}
	
	@Override
	public MyVoParent update(FormBeanParent dataParentForm)
			throws FileNotFoundException, IOException {
		return null;
	}	
	
	@Override
	public void initClassName() {
		super.setGetDateWhere(null, null);
		super.setTableClass(T_GetGoods.class);
		super.setVoClass(T_GetGoods.class);
		super.setIdName("f_gId");
	}
}
