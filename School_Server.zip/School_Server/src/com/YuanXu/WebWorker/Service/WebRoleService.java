package com.YuanXu.WebWorker.Service;

import java.util.List;

import com.YuanXu.Util.Parent.FormBeanParent;
import com.YuanXu.Util.Parent.MyServiceInterface;
import com.YuanXu.Util.Parent.MyVoParent;
import com.YuanXu.WebWorker.Vo.VoWebRole;

/**
 * 
 * @author Lyra_Phoenix
 *
 */
public interface WebRoleService extends MyServiceInterface {
	public List<VoWebRole> getAll();
	// 终极管理员调用方法
	public MyVoParent add_admin(FormBeanParent dataForm);
	public MyVoParent update_admin(FormBeanParent dataForm);
	public MyVoParent delete_admin(FormBeanParent dataForm);
}
