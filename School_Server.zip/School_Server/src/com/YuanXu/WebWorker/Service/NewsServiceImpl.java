package com.YuanXu.WebWorker.Service;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.UUID;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

import com.YuanXu.Util.Parent.FormBeanParent;
import com.YuanXu.Util.Parent.MyServiceParent;
import com.YuanXu.Util.Parent.MyVoParent;
import com.YuanXu.Util.Util.JsonEasyUI;
import com.YuanXu.Util.Util.QueryResult;
import com.YuanXu.WebWorker.Entity.T_News;
import com.YuanXu.WebWorker.FormBean.NewsForm;
import com.YuanXu.WebWorker.Vo.VoNews;

@Service("newsService")
@Scope("prototype")
public class NewsServiceImpl extends MyServiceParent implements NewsService{
	
	private String tableName = "T_News";
	
	
	
	@Override
	public MyVoParent add(FormBeanParent dataParentForm)
			throws FileNotFoundException, IOException {
		NewsForm data = (NewsForm)dataParentForm;
		T_News news = new T_News();
		news.setF_nId(UUID.randomUUID().toString());
		news.setF_nAuthor(data.getF_nAuthor());
		news.setF_nContent(data.getF_nContent());
		news.setF_nDate(data.getF_nDate());
		news.setF_nPaiWei(new Date().getTime());
		news.setF_nSubtitle(data.getF_nSubtitle());
		news.setF_nTitle(data.getF_nTitle());
		news.setF_nUrl(data.getF_nUrl());
		super.save(news);
		return result;
	}
	
	@Override
	public MyVoParent getData(FormBeanParent dataParentForm) {
		NewsForm data = (NewsForm)dataParentForm;
		JsonEasyUI<VoNews> js = new JsonEasyUI<VoNews>();
		QueryResult<T_News> qr = super.getData(tableName, null, null, data);
		for(T_News entity:qr.getResultList()){
			VoNews vo = new VoNews();
			vo.vo_easyui(entity);
			js.getRows().add(vo);
		}
		js.setTotal(qr.getTotalrecord());
		return js;
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public MyVoParent delete(FormBeanParent dataParentForm) {
		NewsForm data = (NewsForm)dataParentForm;
		List<T_News> list = (List<T_News>) super.finddele(data, tableName, "f_nId");
		for(T_News entity:list){
			super.dele(entity);
		}
		return result;
	}
	
	@Override
	public MyVoParent update(FormBeanParent dataParentForm)
			throws FileNotFoundException, IOException {
		NewsForm data = (NewsForm)dataParentForm;
		T_News news = (T_News) super.find(T_News.class, data.getF_nId());
		if(news==null){
			result.isError("数据已经不存在了");
			return result;
		}
		news.setF_nAuthor(data.getF_nAuthor());
		news.setF_nContent(data.getF_nContent());
		news.setF_nDate(data.getF_nDate());
		news.setF_nSubtitle(data.getF_nSubtitle());
		news.setF_nTitle(data.getF_nTitle());
		news.setF_nUrl(data.getF_nUrl());
		super.update(news);
		return result;
	}
	
	@Override
	public void initClassName() {
		// TODO Auto-generated method stub
		
	}
	
	@Override
	public MyVoParent doOpreate(FormBeanParent dataParentForm) {
		NewsForm data = (NewsForm)dataParentForm;
		T_News news = (T_News) super.find(T_News.class, data.getF_nId());
		FormBeanParent data1 = new FormBeanParent();
		data1.setPage(1);
		data1.setOrder("asc");
		data1.setRows(1);
		data1.setSort("f_nPaiWei");
		List<Object> w = new ArrayList<Object>();
		w.add(data.getF_nPaiWei());
		QueryResult<T_News> qr = super.getData(tableName, "f_nPaiWei>?", w, data1);
		if(qr.getResultList().size()==0){
			result.isError("已经是最上");
			return result;
		}
		T_News news1 = qr.getResultList().get(0);
		long num = news1.getF_nPaiWei();
		news1.setF_nPaiWei(news.getF_nPaiWei());
		news.setF_nPaiWei(num);
		return result;
	}

	public VoNews getNews(NewsForm data) {
		T_News news = (T_News) super.find(T_News.class, data.getF_nId());
		VoNews vo = new VoNews();
		vo.vo_easyui(news);
		return vo;
	}

	public MyVoParent doMove(NewsForm data) {
		T_News news = (T_News) super.find(T_News.class, data.getF_nId());
		FormBeanParent data1 = new FormBeanParent();
		data1.setPage(1);
		data1.setOrder("desc");
		data1.setRows(1);
		data1.setSort("f_nPaiWei");
		List<Object> w = new ArrayList<Object>();
		w.add(data.getF_nPaiWei());
		QueryResult<T_News> qr = super.getData(tableName, "f_nPaiWei<?", w, data1);
		if(qr.getResultList().size()==0){
			result.isError("已经是最下");
			return result;
		}
		T_News news1 = qr.getResultList().get(0);
		long num = news1.getF_nPaiWei();
		news1.setF_nPaiWei(news.getF_nPaiWei());
		news.setF_nPaiWei(num);
		return result;
	}

	public MyVoParent doShow(FormBeanParent data) {
		NewsForm entity = (NewsForm)data;
		T_News news = (T_News) super.find(T_News.class, entity.getF_nId());
		if(news==null){
			result.isError("数据不存在了");
			return result;
		}
		return result;
	}

}
