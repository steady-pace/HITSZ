package com.YuanXu.WebWorker.Service;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.UUID;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

import com.YuanXu.Util.Parent.FormBeanParent;
import com.YuanXu.Util.Parent.MyServiceParent;
import com.YuanXu.Util.Parent.MyVoParent;
import com.YuanXu.Util.Util.JsonEasyUI;
import com.YuanXu.Util.Util.QueryResult;
import com.YuanXu.WebWorker.Entity.T_Member;
import com.YuanXu.WebWorker.Enum.EnumMemberStatus;
import com.YuanXu.WebWorker.FormBean.MemberForm;
import com.YuanXu.WebWorker.Vo.VoMember;




@Service("memberService")
@Scope("prototype")
public class MemberServiceImpl extends MyServiceParent implements MemberService{
	private String tableName = "T_Member";
	
	
	@Override
	public MyVoParent add(FormBeanParent dataParentForm)
			throws FileNotFoundException, IOException {
		MemberForm data = (MemberForm)dataParentForm;
		List<Object> w = new ArrayList<Object>();
		w.add(data.getF_mNo());
		T_Member member1 = (T_Member) super.find("from T_Member where f_mNo=?", w);
		if(member1!=null&&!member1.getF_mNo().trim().equals("")){
			result.isError("学号已经存在了");
			return result;
		}
		T_Member entity = new T_Member();
		entity.setF_mId(UUID.randomUUID().toString());
		entity.setF_mEmail(data.getF_mEmail());
		entity.setF_mName(data.getF_mName());
		entity.setF_mNewTime(new Date());
		entity.setF_mNo(data.getF_mNo());
		entity.setF_mPhone(data.getF_mPhone());
		entity.setF_mPwd(data.getF_mPwd());
		entity.setF_mStatus(EnumMemberStatus.MANAGE_OK);
		super.save(entity);
		return result;
	}
	

	//过滤路径：/School/webworker/member_list.jhtml
	//过滤路径：/School/webworker/losegoods_list.jhtml
	
	@Override
	public MyVoParent getData(FormBeanParent dataParentForm) {
		MemberForm data = (MemberForm)dataParentForm;
		JsonEasyUI<VoMember> js = new JsonEasyUI<VoMember>();
		QueryResult<T_Member> qr = super.getData(tableName, null, null, data);
		for(T_Member entity:qr.getResultList()){
			VoMember vo = new VoMember(entity);
			js.getRows().add(vo);
		}
		js.setTotal(qr.getTotalrecord());
		return js;
	}
		
	
	@SuppressWarnings("unchecked")
	@Override
	public MyVoParent delete(FormBeanParent dataParentForm) {
		MemberForm data = (MemberForm)dataParentForm;
		List<T_Member> list = (List<T_Member>) super.finddele(data, tableName, "f_mId");
		List<Object> w = new ArrayList<Object>();
		for(T_Member m:list){
			w.clear();
			w.add(m.getF_mNo());
			List<Object> wt = new ArrayList<Object>();
			wt.add(m.getF_mId());
			super.dele(m);
		}
		return result;
	}
	
	
	@Override
	public MyVoParent doOpreate(FormBeanParent dataParentForm) {
		MemberForm data = (MemberForm)dataParentForm;
		T_Member entity = (T_Member) super.find(T_Member.class, data.getF_mId());
		if(entity.getF_mStatus()==EnumMemberStatus.MANAGE_OK){
			entity.setF_mStatus(EnumMemberStatus.MANAGE_CLOSE);
		}else{
			entity.setF_mStatus(EnumMemberStatus.MANAGE_OK);
		}
		return result;
	}
	
	@Override
	public MyVoParent update(FormBeanParent dataParentForm)
			throws FileNotFoundException, IOException {
		MemberForm data = (MemberForm)dataParentForm;
		T_Member entity = (T_Member) super.find(T_Member.class, data.getF_mId());
		List<Object> w = new ArrayList<Object>();
		w.add(data.getF_mName());
		T_Member m = (T_Member) super.find("from T_Member where f_mName=?", w);
		w.clear();
		w.add(data.getF_mNo());
		T_Member member1 = (T_Member) super.find("from T_Member where f_mNo=?", w);
		if(member1!=null&&!member1.getF_mId().equals(entity.getF_mId())&&!member1.getF_mNo().trim().equals("")){
			result.isError("编号已经存在了");
			return result;
		}
		if(m!=null){
			if(!entity.getF_mId().equals(m.getF_mId())){
				result.isError("用户名已经存在,修改失败");
				return result;
			}
		}			
		w.add(data.getF_mId());	
		entity.setF_mEmail(data.getF_mEmail());
		entity.setF_mName(data.getF_mName());
		entity.setF_mNo(data.getF_mNo());
		entity.setF_mPhone(data.getF_mPhone());
		entity.setF_mPwd(data.getF_mPwd());
		return result;
	}	
	
	@Override
	public void initClassName() {
		super.setGetDateWhere(null, null);
		super.setTableClass(T_Member.class);
		super.setVoClass(T_Member.class);
		super.setIdName("f_mId");
	}
	
	/**
	 * 拿出所有子级会员
	 */
	public void getAllMember(String id){
		T_Member member = (T_Member) super.find(T_Member.class, id);
		initVo(member);
	}
	
	private List<Object> wt = new ArrayList<Object>();
	private List<VoMember> voMems = new ArrayList<VoMember>();
	
	@SuppressWarnings("unchecked")
	public void initVo(T_Member m){
		wt.clear();
		wt.add(m.getF_mNo());
		List<T_Member> list = (List<T_Member>) super.findAll("from T_Member where f_mReFereesNo=?", wt);
		if(list.size()>0){
			for(T_Member mem:list){
				VoMember vo = new VoMember();
				vo.voInit(mem, null);
				voMems.add(vo);
				if(mem.getF_mNo().equals("")){
					break;
				}
				initVo(mem);
				
			}
		}
	}

	public List<T_Member> getAll() {
		// TODO Auto-generated method stub
		return null;
	}
	
}
