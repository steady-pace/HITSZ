package com.YuanXu.WebWorker.Service;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

import com.YuanXu.Util.Filter.HTTPSessionUtil;
import com.YuanXu.Util.Parent.FormBeanParent;
import com.YuanXu.Util.Parent.MyServiceParent;
import com.YuanXu.Util.Parent.MyVoParent;
import com.YuanXu.Util.Util.JsonEasyUI;
import com.YuanXu.Util.Util.QueryResult;
import com.YuanXu.WebWorker.Entity.T_GetGoods;
import com.YuanXu.WebWorker.Entity.T_WebWorker;
import com.YuanXu.WebWorker.Enum.EnumLosegoodsStatus;
import com.YuanXu.WebWorker.FormBean.GetGoodsForm;
import com.YuanXu.WebWorker.Vo.VoGetGoods;
/**
 * 招领的方法实现
 * @author Lyra_Phoenix
 *
 */
@Service("getGoodsService")
@Scope("prototype")
public class GetGoodsServiceImpl extends MyServiceParent implements GetGoodsService{
	private String tableName = "T_GetGoods";
	
	
	@Override
	public MyVoParent add(FormBeanParent dataParentForm)
			throws FileNotFoundException, IOException {
		GetGoodsForm data = (GetGoodsForm)dataParentForm;
	
		T_GetGoods entity = new T_GetGoods();
		List<Object> pa = new ArrayList<Object>();
		entity.setF_gId(UUID.randomUUID().toString());
		entity.setF_gDescribe(data.getF_gDescribe());
		
		pa.add(EnumLosegoodsStatus.PENSON_GET);
		long pageSize = super.findCount_all("select count(*) from T_GetGoods where f_gStatus=?", pa);
		pa.clear();
		pa.add(EnumLosegoodsStatus.PENSON_LOSE);
		long pageSize1 = super.findCount_all("select count(*) from T_GetGoods where f_gStatus=?", pa);
		String NO_lose = pageSize+ pageSize1 + 1 + "";
		entity.setF_gNo(NO_lose);
		//entity.setF_gPhone(data.getF_gPhone());
		entity.setF_gType(data.getF_gType());
		entity.setF_gStatus(EnumLosegoodsStatus.PENSON_LOSE);
		
		String adminId = (String)HTTPSessionUtil.getObject(HTTPSessionUtil.WebWorkerPower.webWorker_adminId.getKey());
		String SqlFind = " from T_WebWorker where f_wwId=? " ;
		List<Object> listHQL = new ArrayList<Object>();
		listHQL.add(adminId);
		T_WebWorker pwd = (T_WebWorker)super.find(SqlFind, listHQL);
		if(pwd != null){
			entity.setF_gmName(pwd.getF_wwName());
			entity.setF_gmNo(pwd.getF_wwStudentNo());
			entity.setF_gmPhone(pwd.getF_wwContact());
		}
		super.save(entity);
		return result;
	}
	
	@Override
	public MyVoParent getData(FormBeanParent dataParentForm) {
		GetGoodsForm data = (GetGoodsForm)dataParentForm;
		JsonEasyUI<VoGetGoods> js = new JsonEasyUI<VoGetGoods>();
		QueryResult<T_GetGoods> qr = super.getData(tableName, null, null, data);
		for(T_GetGoods entity:qr.getResultList()){
			VoGetGoods vo = new VoGetGoods(entity);
			js.getRows().add(vo);
		}
		js.setTotal(qr.getTotalrecord());
		return js;
	}
		
	
	@Override
	public MyVoParent delete(FormBeanParent dataParentForm) {
		return null;
	}
	
	
	@Override
	public MyVoParent doOpreate(FormBeanParent dataParentForm) {
		GetGoodsForm data = (GetGoodsForm)dataParentForm;
		T_GetGoods entity = (T_GetGoods) super.find(T_GetGoods.class, data.getF_gId());
		if(entity.getF_gStatus() == EnumLosegoodsStatus.PENSON_LOSE){
			entity.setF_gStatus(EnumLosegoodsStatus.PENSON_GET);
		}else{
		}
		return result;
	}
	
	@Override
	public MyVoParent update(FormBeanParent dataParentForm)
			throws FileNotFoundException, IOException {
		return null;
	}	
	
	@Override
	public void initClassName() {
		super.setGetDateWhere(null, null);
		super.setTableClass(T_GetGoods.class);
		super.setVoClass(T_GetGoods.class);
		super.setIdName("f_gId");
	}
}
