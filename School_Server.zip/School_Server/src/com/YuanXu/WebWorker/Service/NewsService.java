package com.YuanXu.WebWorker.Service;

import com.YuanXu.Util.Parent.FormBeanParent;
import com.YuanXu.Util.Parent.MyServiceInterface;
import com.YuanXu.Util.Parent.MyVoParent;

import com.YuanXu.WebWorker.FormBean.NewsForm;
import com.YuanXu.WebWorker.Vo.VoNews;

public interface NewsService extends MyServiceInterface{
	public VoNews getNews(NewsForm data);
	
	public MyVoParent doMove(NewsForm data);
	
	
	public MyVoParent doShow(FormBeanParent data);
}
