package com.YuanXu.WebWorker.Enum;

/****
 * 总部统计分析人员权限
 * @author 吕锡田
 *
 */
public enum EnumAnalysePower {
	ANALYSE_01("ANALYSE_01","查阅客户统计","工作人员管理（越南语）"),
	ANALYSE_02("ANALYSE_02","查阅订单统计","越南语"),
	ANALYSE_03("ANALYSE_03","查阅销售概况",""),
	ANALYSE_04("ANALYSE_04","查阅会员消费排行",""),
	ANALYSE_05("ANALYSE_05","查阅销售明细",""),
	ANALYSE_06("ANALYSE_06","查阅销售排行",""),
	ANALYSE_07("ANALYSE_07","查阅访问购买率","");
	
	private String vietnam_value;// 越南语
	private String value;// 中文
	private String name;// 值
	
	private EnumAnalysePower(String name, String value, String vietnam_value){
		this.name = name;
		this.value = value;
		this.vietnam_value = vietnam_value;
	}
	
	public static String getName(String value){
		for(EnumAnalysePower e :EnumAnalysePower.values()){
			if(e.getValue().equals(value)){
				return e.getName();
			}else if(e.getVietnam_value().equals(value)){
				return e.getName();
			}
		}
		return null;
	}
	
	public static String getValue(String Name){
		for(EnumAnalysePower e :EnumAnalysePower.values()){
			if(e.getName().equals(Name)){
				return e.getValue();
			}
		}
		return null;
	}
	// 获取越南语
	public static String getVietnamValue(String Name){
		for(EnumAnalysePower e :EnumAnalysePower.values()){
			if(e.getName().equals(Name)){
				return e.getVietnam_value();
			}
		}
		return null;
	}
	
	public String getVietnam_value() {
		return vietnam_value;
	}
	public void setVietnam_value(String vietnamValue) {
		vietnam_value = vietnamValue;
	}
	public String getValue() {
		return value;
	}
	public void setValue(String value) {
		this.value = value;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
}
