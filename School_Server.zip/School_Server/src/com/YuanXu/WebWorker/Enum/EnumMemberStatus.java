package com.YuanXu.WebWorker.Enum;



public enum EnumMemberStatus {
	MANAGE_OK("MANAGE_OK","正常"),
	MANAGE_CLOSE("MANAGE_CLOSE","关闭");
	private String name;
	private String value;
	
	public static String getName(String value){
		for(EnumMemberStatus e :EnumMemberStatus.values()){
			if(e.getValue().equals(value)){
				return e.getName();
			}
		}
		return null;
	}
	public static String getValue(String Name){
		for(EnumMemberStatus e :EnumMemberStatus.values()){
			if(e.getName().equals(Name)){
				return e.getValue();
			}
		}
		return null;
	}
	
	
	public String getName() {
		return name;
	}



	public void setName(String name) {
		this.name = name;
	}



	public String getValue() {
		return value;
	}



	public void setValue(String value) {
		this.value = value;
	}

	private EnumMemberStatus(String name,String value){
		this.name = name;
		this.value = value;
		
	}
}
