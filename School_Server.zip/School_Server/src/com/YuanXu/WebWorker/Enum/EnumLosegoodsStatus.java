package com.YuanXu.WebWorker.Enum;



public enum EnumLosegoodsStatus {
	GOODS_LOSE("GOODS_LOSE","未找到失物"),
	GOODS_GET("GOODS_GET","已找到失物"),
	PENSON_LOSE("PENSON_LOSE","未找到失主"),
	PENSON_GET("PENSON_GET","已找到失主");
	private String name;
	private String value;
	
	public static String getName(String value){
		for(EnumLosegoodsStatus e :EnumLosegoodsStatus.values()){
			if(e.getValue().equals(value)){
				return e.getName();
			}
		}
		return null;
	}
	public static String getValue(String Name){
		for(EnumLosegoodsStatus e :EnumLosegoodsStatus.values()){
			if(e.getName().equals(Name)){
				return e.getValue();
			}
		}
		return null;
	}
	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	private EnumLosegoodsStatus(String name,String value){
		this.name = name;
		this.value = value;
	}
}
