package com.YuanXu.WebWorker.Enum;

/**
 * 
 * @author Lyra_Phoenix
 *
 */
public enum EnumWebRolePower {
	web_group("web_group","社团组织"),
	web_news("web_news","校园新闻"),
	web_lose("web_lose","失物招领");
	
	private String value;
	private String name;
	private EnumWebRolePower(String value,String name){
		this.value = value;
		this.name = name;
	}
	public static String getName(String value){
		for(EnumWebRolePower e :EnumWebRolePower.values()){
			if(e.getValue().equals(value)){
				return e.getName();
			}
		}
		return null;
	}
	public static String getValue(String Name){
		for(EnumWebRolePower e :EnumWebRolePower.values()){
			if(e.getName().equals(Name)){
				return e.getValue();
			}
		}
		return null;
	}
	public String getValue() {
		return value;
	}
	public void setValue(String value) {
		this.value = value;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
}
