package com.YuanXu.WebWorker.Action;

import javax.annotation.Resource;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

import com.YuanXu.Util.Filter.HTTPSessionUtil;
import com.YuanXu.Util.Parent.FormBeanParent;
import com.YuanXu.Util.Parent.MyActionParent;
import com.YuanXu.WebWorker.FormBean.WebWorkerForm;
import com.YuanXu.WebWorker.Service.WebWorkerService;
import com.YuanXu.WebWorker.Vo.VoWebWorker;

/**
 * 网络部工作人员action
 * @author 罗培彬
 *
 */
@SuppressWarnings({"serial"})
@Service("webWorkerAction")
@Scope("prototype")
public class WebWorkerAction extends MyActionParent{
	@Resource
	private WebWorkerService webWorkerService;
	private WebWorkerForm dataForm = new WebWorkerForm();
	private VoWebWorker voWebWorker;
	@Override
	public void doPutPower() {
		// TODO Auto-generated method stub
		super.putParentMethodPower("/webworker","WEB_USER_MANAGE","WEB_USER_MANAGE","WEB_USER_MANAGE","WEB_USER_MANAGE");
	}
	
	/*
	 * 总部登陆
	 */
	public String login(){
		String result[] = null;
		try {
			result = webWorkerService.dologin(dataForm);
		} catch (Exception e) {
			e.printStackTrace();
			result = new String[]{"error","跳转出错"};
		}finally{
			addActionMessage(result[1]);
		}
		return result[0];
	}
	
	public String exit(){
		try{
			HTTPSessionUtil.exitWebWorker();
		}catch (Exception e) {
			// TODO: handle exception
			return "input";
		}finally{
			
		}
		return "success";
	}
	
	
	public String updateName(){
		String result[] = null;
		try {
			result = webWorkerService.updateName(dataForm);
		} catch (Exception e) {
			result = new String[]{"error","跳转出错"};
		}finally{
			addActionMessage(result[1]);
		}
		if(result[0].equals("error")){
			return result[0];
		}else{
			return result[0];
		}
	}
	
	public String updatePw(){
		String result[] = null;
		try {
			result = webWorkerService.updatePw(dataForm);
		} catch (Exception e) {
			result = new String[]{"error","跳转出错"};
		}finally{
			addActionMessage(result[1]);
		}
		if(result[0].equals("error")){
			return result[0];
		}else{
			return result[0];
		}
		
	}
	
	@Override
	public void doStartAction() {
		// TODO Auto-generated method stub
		super.setServiceIntterface(webWorkerService);
		super.setDataParentForm(dataForm);
	}
	public FormBeanParent getModel() {
		// TODO Auto-generated method stub
		return dataForm;
	}
	public WebWorkerService getWebWorkerService() {
		return webWorkerService;
	}
	public void setWebWorkerService(WebWorkerService webWorkerService) {
		this.webWorkerService = webWorkerService;
	}
	public WebWorkerForm getDataForm() {
		return dataForm;
	}
	public void setDataForm(WebWorkerForm dataForm) {
		this.dataForm = dataForm;
	}
	public VoWebWorker getVoWebWorker() {
		return voWebWorker;
	}
	public void setVoWebWorker(VoWebWorker voWebWorker) {
		this.voWebWorker = voWebWorker;
	}
	
}
