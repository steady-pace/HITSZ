package com.YuanXu.WebWorker.Action;

import java.io.PrintWriter;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.sf.json.JSONObject;

import org.apache.struts2.ServletActionContext;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

import com.YuanXu.Util.Parent.FormBeanParent;
import com.YuanXu.Util.Parent.MyActionParent;
import com.YuanXu.WebWorker.FormBean.NewsForm;
import com.YuanXu.WebWorker.Service.NewsService;
import com.YuanXu.WebWorker.Vo.VoNews;

@SuppressWarnings("serial")
@Service("newsAction")
@Scope("prototype")
public class NewsAction extends MyActionParent{
	
	@Resource
	private NewsService newsService;
	
	private NewsForm data = new NewsForm();
	@Override
	public void doPutPower() {
		// TODO Auto-generated method stub
		
	}
	
	
	public String admin_saveNews(){
		String result[] = new String[]{"success","操作成功"};
		try{
			newsService.add(data);
		}catch (Exception e) {
			result = new String[]{"error","跳转出错"};
		}finally{
			addActionMessage(result[1]);
		}
		return result[0];
	}
	
	public void admin_show(){
		HttpServletResponse response = ServletActionContext.getResponse();
		response.setCharacterEncoding("UTF-8");
		response.setContentType("textml; charset=utf-8");
		PrintWriter out = null;
		JSONObject jsonObject = null;
		try{
		    out = response.getWriter();
		    //直接输入响应的内容
		    jsonObject = JSONObject.fromObject(newsService.doShow(data));
		}catch (Exception e) {
			
		}
		System.out.println(jsonObject.toString());
	    out.print(jsonObject.toString());       
	    out.flush();
	    out.close();
		
	}
	
	public String admin_editNews(){
		String result[] = new String[]{"success","操作成功"};
		try{
			newsService.update(data);
		}catch (Exception e) {
			result = new String[]{"error","跳转出错"};
		}finally{
			addActionMessage(result[1]);
		}
		return result[0];
	}
	
	public void admin_doMove(){
		HttpServletResponse response = ServletActionContext.getResponse();
		response.setCharacterEncoding("UTF-8");
		response.setContentType("textml; charset=utf-8");
		PrintWriter out = null;
		JSONObject jsonObject = null;
		try{
		    out = response.getWriter();
		    //直接输入响应的内容
		    jsonObject = JSONObject.fromObject(newsService.doMove(data));
		}catch (Exception e) {
			
		}
		System.out.println(jsonObject.toString());
	    out.print(jsonObject.toString());       
	    out.flush();
	    out.close();
	}

	@Override
	public void doStartAction() {
		super.setDataParentForm(data);
		super.setServiceIntterface(newsService);
	}

	public void admin_getNews(){
		VoNews news = newsService.getNews(data);
		HttpServletRequest request = ServletActionContext.getRequest();
		request.setAttribute("voNews", news);
	}
	
	public FormBeanParent getModel() {
		return data;
	}

	public NewsForm getData() {
		return data;
	}

	public void setData(NewsForm data) {
		this.data = data;
	}
	
}
