package com.YuanXu.WebWorker.Action;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.apache.struts2.ServletActionContext;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

import com.YuanXu.Util.Parent.FormBeanParent;
import com.YuanXu.Util.Parent.MyActionParent;
import com.YuanXu.WebWorker.FormBean.WebRoleForm;
import com.YuanXu.WebWorker.Service.WebRoleService;
import com.YuanXu.WebWorker.Vo.VoWebRole;
/**
 * 
 * @author Lyra_Phoenix
 *
 */
@SuppressWarnings("serial")
@Service("webRoleAction")
@Scope("prototype")
public class WebRoleAction extends MyActionParent{
	@Resource
	private WebRoleService webRoleService;
	private WebRoleForm dataForm = new WebRoleForm();
	@Override
	public void doPutPower() {
		// TODO Auto-generated method stub
		super.putParentMethodPower("/webworker","WEB_USER_MANAGE","WEB_USER_MANAGE","WEB_USER_MANAGE","WEB_USER_MANAGE");
	}
	
	public void admin_getAll(){
		List<VoWebRole> vo = null;
		try{
			vo = this.webRoleService.getAll();
		}catch (Exception e) {
			e.printStackTrace();
			vo = new ArrayList<VoWebRole>();
		} finally{
			HttpServletRequest request = ServletActionContext.getRequest();
			request.setAttribute("voWebRoles", vo);
		}
	}
	
	@Override
	public void doStartAction() {
		// TODO Auto-generated method stub
		super.setServiceIntterface(webRoleService);
		super.setDataParentForm(dataForm);
	}
	public FormBeanParent getModel() {
		// TODO Auto-generated method stub
		return dataForm;
	}
	public WebRoleService getWebRoleService() {
		return webRoleService;
	}
	public void setWebRoleService(WebRoleService webRoleService) {
		this.webRoleService = webRoleService;
	}
	public WebRoleForm getDataForm() {
		return dataForm;
	}
	public void setDataForm(WebRoleForm dataForm) {
		this.dataForm = dataForm;
	}
	
}
