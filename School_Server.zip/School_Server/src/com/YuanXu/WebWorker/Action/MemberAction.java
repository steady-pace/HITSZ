package com.YuanXu.WebWorker.Action;

import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.sf.json.JSONObject;

import org.apache.struts2.ServletActionContext;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

import com.YuanXu.Util.Parent.FormBeanParent;
import com.YuanXu.Util.Parent.MyActionParent;
import com.YuanXu.Util.Parent.MyVoParent;
import com.YuanXu.WebWorker.FormBean.MemberForm;
import com.YuanXu.WebWorker.Service.MemberService;

@SuppressWarnings("serial")
@Service("memberAction")
@Scope("prototype")
public class MemberAction extends MyActionParent{
	
	@Resource
	private MemberService memberService;

	private MemberForm  data = new MemberForm();
	
	@Override
	public void doPutPower() {
		// TODO Auto-generated method stub
		
	}
	
	public void admin_save(){
		HttpServletRequest request = ServletActionContext.getRequest();
		try {
			request.setCharacterEncoding("utf-8");
		} catch (UnsupportedEncodingException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		List<String> list = new ArrayList<String>();
		
		data.setParamStr(list);
		HttpServletResponse response = ServletActionContext.getResponse();    
		response.setCharacterEncoding("UTF-8");
		response.setContentType("textml; charset=utf-8");
		PrintWriter out = null;
		JSONObject jsonObject = null;
		try{
		    out = response.getWriter();
		    //直接输入响应的内容
		    jsonObject = JSONObject.fromObject(memberService.add(data));
		}catch (Exception e) {
			MyVoParent vo = new MyVoParent();
			vo.isError("添加失败");
			jsonObject = JSONObject.fromObject(vo);
		}
		System.out.println(jsonObject.toString());
	    out.print(jsonObject.toString());       
	    out.flush();
	    out.close();
	}
	
	public void admin_edit(){
		HttpServletRequest request = ServletActionContext.getRequest();
		try {
			request.setCharacterEncoding("utf-8");
		} catch (UnsupportedEncodingException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		List<String> list = new ArrayList<String>();
	
		data.setParamStr(list);
		HttpServletResponse response = ServletActionContext.getResponse();    
		response.setCharacterEncoding("UTF-8");
		response.setContentType("textml; charset=utf-8");
		PrintWriter out = null;
		JSONObject jsonObject = null;
		try{
		    out = response.getWriter();
		    //直接输入响应的内容
		    jsonObject = JSONObject.fromObject(memberService.update(data));
		}catch (Exception e) {
			MyVoParent vo = new MyVoParent();
			vo.isError("更新失败");
			jsonObject = JSONObject.fromObject(vo);
		}
		System.out.println(jsonObject.toString());
	    out.print(jsonObject.toString());       
	    out.flush();
	    out.close();
	}

	@Override
	public void doStartAction() {
		super.setDataParentForm(data);
		super.setServiceIntterface(memberService);
	}

	public FormBeanParent getModel() {
		return data;
	}

	public MemberForm getData() {
		return data;
	}

	public void setData(MemberForm data) {
		this.data = data;
	}
	
}
