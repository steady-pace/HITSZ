package com.YuanXu.WebWorker.Action;

import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.sf.json.JSONObject;

import org.apache.struts2.ServletActionContext;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

import com.YuanXu.Util.Parent.FormBeanParent;
import com.YuanXu.Util.Parent.MyActionParent;
import com.YuanXu.Util.Parent.MyVoParent;
import com.YuanXu.WebWorker.FormBean.GroupActionForm;
import com.YuanXu.WebWorker.Service.GroupActionService;

@SuppressWarnings("serial")
@Service("groupactionAction")
@Scope("prototype")
public class GroupActionAction extends MyActionParent{
	
	@Resource
	private GroupActionService groupActionService;

	private GroupActionForm  data = new GroupActionForm();
	
	@Override
	public void doPutPower() {
	}
	
	public void admin_save(){
		HttpServletRequest request = ServletActionContext.getRequest();
		try {
			request.setCharacterEncoding("utf-8");
		} catch (UnsupportedEncodingException e1) {
			e1.printStackTrace();
		}
		List<String> list = new ArrayList<String>();
		
		data.setParamStr(list);
		HttpServletResponse response = ServletActionContext.getResponse();    
		response.setCharacterEncoding("UTF-8");
		response.setContentType("textml; charset=utf-8");
		PrintWriter out = null;
		JSONObject jsonObject = null;
		try{
		    out = response.getWriter();
		    //直接输入响应的内容
		    jsonObject = JSONObject.fromObject(groupActionService.add(data));
		}catch (Exception e) {
			MyVoParent vo = new MyVoParent();
			vo.isError("添加失败");
			jsonObject = JSONObject.fromObject(vo);
		}
		System.out.println(jsonObject.toString());
	    out.print(jsonObject.toString());       
	    out.flush();
	    out.close();
	}
	
	
	
	
//	@Override
//	public void admin_list() {
//		System.out.println("getdata");
//		super.admin_list();
//	}

//	public void admin_edit(){
//		HttpServletRequest request = ServletActionContext.getRequest();
//		try {
//			request.setCharacterEncoding("utf-8");
//		} catch (UnsupportedEncodingException e1) {
//			// TODO Auto-generated catch block
//			e1.printStackTrace();
//		}
//		List<String> list = new ArrayList<String>();
//	
//		data.setParamStr(list);
//		HttpServletResponse response = ServletActionContext.getResponse();    
//		response.setCharacterEncoding("UTF-8");
//		response.setContentType("textml; charset=utf-8");
//		PrintWriter out = null;
//		JSONObject jsonObject = null;
//		try{
//		    out = response.getWriter();
//		    //直接输入响应的内容
//		    jsonObject = JSONObject.fromObject(loseGoodsService.update(data));
//		}catch (Exception e) {
//			MyVoParent vo = new MyVoParent();
//			vo.isError("更新失败");
//			jsonObject = JSONObject.fromObject(vo);
//		}
//		System.out.println(jsonObject.toString());
//	    out.print(jsonObject.toString());       
//	    out.flush();
//	    out.close();
//	}

	@Override
	public void doStartAction() {
		super.setDataParentForm(data);
		super.setServiceIntterface(groupActionService);
	}

	public FormBeanParent getModel() {
		return data;
	}

	public GroupActionForm getData() {
		return data;
	}

	public void setData(GroupActionForm data) {
		this.data = data;
	}
	
}
