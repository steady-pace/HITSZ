package com.YuanXu.External.Entity;
/*
 * 源续监控标志
 * 
 */
import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
@SuppressWarnings("serial")
@Entity
@Table(name="tb_YuanXuTip")
public class T_YuanXuTip implements Serializable {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Integer f_id;
	@Column(length=20)
	private String f_tip;
	@Column(length=200)
	private String f_project;
	private Date f_lastTime;//最近检测时间
	
	public void isNew(String projectName){
		this.f_tip = "yuanxu";
		this.f_project = projectName;
		this.f_lastTime = new Date();
	}
	
	public Integer getF_id() {
		return f_id;
	}
	public void setF_id(Integer fId) {
		f_id = fId;
	}
	public String getF_tip() {
		return f_tip;
	}
	public void setF_tip(String fTip) {
		f_tip = fTip;
	}
	public String getF_project() {
		return f_project;
	}
	public void setF_project(String fProject) {
		f_project = fProject;
	}

	public Date getF_lastTime() {
		return f_lastTime;
	}

	public void setF_lastTime(Date fLastTime) {
		f_lastTime = fLastTime;
	}
	
}
