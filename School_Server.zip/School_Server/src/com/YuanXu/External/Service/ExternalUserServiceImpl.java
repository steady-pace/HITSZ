package com.YuanXu.External.Service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.UUID;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

import com.YuanXu.External.FormBean.MemberForm;
import com.YuanXu.External.Vo.VoGetGoods;
import com.YuanXu.External.Vo.VoGroupAction;
import com.YuanXu.External.Vo.VoLoseGoods;
import com.YuanXu.External.Vo.VoMember;
import com.YuanXu.External.Vo.VoNews;
import com.YuanXu.External.Web.MsgGetGoods;
import com.YuanXu.External.Web.MsgGroupAction;
import com.YuanXu.External.Web.MsgLoginUser;
import com.YuanXu.External.Web.MsgLoseGoods;
import com.YuanXu.External.Web.MsgNews;
import com.YuanXu.Util.Parent.MyServiceParent;
import com.YuanXu.Util.Parent.MyVoParent;
import com.YuanXu.WebWorker.Entity.T_GetGoods;
import com.YuanXu.WebWorker.Entity.T_GroupAction;
import com.YuanXu.WebWorker.Entity.T_GroupActionItem;
import com.YuanXu.WebWorker.Entity.T_LoseGoods;
import com.YuanXu.WebWorker.Entity.T_Member;
import com.YuanXu.WebWorker.Entity.T_News;
import com.YuanXu.WebWorker.Enum.EnumLosegoodsStatus;
import com.YuanXu.WebWorker.Enum.EnumMemberStatus;

@Service("externalUserService")
@Scope("prototype")
public class ExternalUserServiceImpl extends MyServiceParent implements
		ExternalUserService {

	@Override
	public void initClassName() {
	}
	/**
	 * 判断AppKey是否正确  
	 * AppKey的作用是判断该用户是否登录 或者是登录状态是否正确
	 * @param user
	 * @param appKey
	 * @return
	 */
	private Boolean checkAppKey(T_Member user,String appKey){
		if(!user.getAppKey().equals(appKey)){
			return false;
		}else{
			return true;
		}
	}
	
	/**
	 * 会员手机端登录方法
	 */
	
	public MyVoParent doLoginUser(MemberForm dataForm) {
		List<Object> list = new ArrayList<Object>();
		MsgLoginUser msgloginUser = new MsgLoginUser();
		list.add(dataForm.getF_mName());
		T_Member user = (T_Member)super.find(" from T_Member where f_mName=? ", list);
		if(user!=null){
			if(user.getF_mPwd().equals(dataForm.getF_mPwd())){
				try {
					//登录成功添加用户appKey
					user.setAppKey(UUID.randomUUID().toString());
					super.update(user);
					//返回Vo
					VoMember voUser = new VoMember();
					voUser.setAppKey(user.getAppKey());
					voUser.setF_mName(user.getF_mName());
					voUser.setF_mId(user.getF_mId());
					msgloginUser.setVoUser(voUser);
					super.update(user);
				} catch (Exception e) {
				}
				return msgloginUser;
			}else{

				result.isError("账号或密码错误!");
			}
		}else{
			result.isError("账号或密码错误!");
		}
		return result;
	}
	
	/**
	 * 会员修改密码 
	 */
	public MyVoParent doUpdateUserPw(MemberForm userForm) {
		T_Member user = (T_Member) super.find(T_Member.class,userForm.getF_mId());
		if(user != null ){
			if(checkAppKey(user,userForm.getAppKey())){
				if(user.getF_mPwd().equals(userForm.getF_mPwd())){
					try {
						user.setF_mPwd(userForm.getF_mNewPwd());
						super.save(user);
					} catch (Exception e) {
						result.isError("输入的密码不正确!");
					}
				}else{
				}
			}else{
				result.isError("登录状态丢失，请重新登录！");
			}
			return result;
		}else{
			result.isError();
			return result;
		}
	}
	

	/**
	 * 安全退出接口
	 * @param userForm
	 * @return
	 */
	public MyVoParent doUserLogOut(MemberForm userForm){
		T_Member user = (T_Member) super.find(T_Member.class,userForm.getF_mId());
		if(checkAppKey(user,userForm.getAppKey())){
			try {
				user.setAppKey(null);
				super.update(user);
			} catch (Exception e) {
			}
		}else{
			result.isError("登录状态丢失");
		}
		return result;
	}

	/**
	 * 寻找失物
	 */

	@SuppressWarnings("unchecked")
	public MyVoParent doGetforlose(MemberForm userForm) {
		List<Object> list = new ArrayList<Object>();
		MsgLoseGoods msgloseGoods = new MsgLoseGoods();
		list.add(EnumLosegoodsStatus.GOODS_LOSE);
		List<T_LoseGoods> actionsList =  (List<T_LoseGoods>) super.findAll(" from T_LoseGoods where f_lStatus = ? ", list);
		List<VoLoseGoods> loselist = new ArrayList<VoLoseGoods>();
		if(actionsList.size() !=0){
			for(T_LoseGoods goods : actionsList){
				VoLoseGoods loseGoods = new VoLoseGoods();
				loseGoods.vo_easyui(goods);
				loselist.add(loseGoods);
			}
			msgloseGoods.setLoseGoods(loselist);
			return msgloseGoods;
		}else{
			result.setData("暂时没有人丢失物品");
			return result;
		}
	}


	/**
	 * 点赞
	 */
	public MyVoParent doGivegood(MemberForm userForm) {
		MemberForm data = (MemberForm)userForm;
		List<Object> w = new ArrayList<Object>();
		w.add(data.getF_mId());
		w.add(data.getF_gaId());
		
		T_GroupActionItem actionItem = (T_GroupActionItem) super.find(" from T_GroupActionItem where f_stuId = ? and f_actId = ?", w);
		if(actionItem == null){
			actionItem = new T_GroupActionItem();
			actionItem.setF_actzan(1+"");
			actionItem.setF_stuId(data.getF_mId());
			actionItem.setF_actId(data.getF_gaId());
			super.save(actionItem);
			List<Object> wq = new ArrayList<Object>();
			wq.add(data.getF_gaId());
			T_GroupAction action = (T_GroupAction) super.find("from T_GroupAction where f_gaId=?", wq);
			if(action != null){
				int zan = action.getF_gaZan();
				action.setF_gaZan(zan+1);
				super.update(action);
				return result;
			}else{
				result.isError("数据异常！");
				return result;
			}
		}
		result.isError("你已经评论过，不能再次发表意见！");
		return result;
	}



	public MyVoParent doGivehit(MemberForm userForm) {
		MemberForm data = (MemberForm)userForm;
		List<Object> w = new ArrayList<Object>();
		w.add(data.getF_mId());
		w.add(data.getF_gaId());
		
		T_GroupActionItem actionItem = (T_GroupActionItem) super.find(" from T_GroupActionItem where f_stuId = ? and f_actId = ?", w);
		if(actionItem == null){
			actionItem = new T_GroupActionItem();
			actionItem.setF_acthit(1+"");
			actionItem.setF_stuId(data.getF_mId());
			actionItem.setF_actId(data.getF_gaId());
			super.save(actionItem);
			List<Object> wq = new ArrayList<Object>();
			wq.add(data.getF_gaId());
			T_GroupAction action = (T_GroupAction) super.find("from T_GroupAction where f_gaId=?", wq);
			if(action != null){
				int zan = action.getF_gaHit();
				action.setF_gaHit(zan+1);
				super.update(action);
				return result;
			}else{
				result.isError("数据异常！");
				return result;
			}
		}
		result.isError("你已经评论过，不能再次发表意见！");
		return result;
	}



	@SuppressWarnings("unchecked")
	public MyVoParent doGroupaction(MemberForm userForm) {
		MsgGroupAction groupAction= new MsgGroupAction();
		List<T_GroupAction> actionsList =  (List<T_GroupAction>) super.findAll("from T_GroupAction ", null);
		List<VoGroupAction> glist = new ArrayList<VoGroupAction>();
		if(actionsList.size() !=0){
			for(T_GroupAction news : actionsList){
				VoGroupAction voGroupAction = new VoGroupAction();
				voGroupAction.vo_action(news);
				glist.add(voGroupAction);
			}
			groupAction.setAction(glist);
			return groupAction;
		}else{
			result.setData("暂无活动");
			return result;
		}
	}



	@SuppressWarnings("unchecked")
	public MyVoParent doLookforlose(MemberForm userForm) {
		List<Object> list = new ArrayList<Object>();
		MsgGetGoods msgGetGoods = new MsgGetGoods();
		list.add(EnumLosegoodsStatus.PENSON_LOSE);
		List<T_GetGoods> actionsList =  (List<T_GetGoods>) super.findAll(" from T_GetGoods where f_gStatus = ? ", list);
		List<VoGetGoods> vogGoodslist = new ArrayList<VoGetGoods>();
		if(actionsList.size() !=0){
			for(T_GetGoods goods : actionsList){
				VoGetGoods getGoods = new VoGetGoods();
				getGoods.vo_easyui(goods);
				vogGoodslist.add(getGoods);
			}
			msgGetGoods.setGetGoods(vogGoodslist);
			return msgGetGoods;
		}else{
			result.setData("暂无失物");
			return msgGetGoods;
		}
	}

	@SuppressWarnings("unchecked")
	public MyVoParent doSchoolnews(MemberForm userForm) {
		MsgNews msgNews= new MsgNews();
		List<T_News> actionsList =  (List<T_News>) super.findAll(" from T_News ",null);
		List<VoNews> voNewslist = new ArrayList<VoNews>();
		VoNews voNews = null;
		if(actionsList.size() !=0){
			for(T_News news : actionsList){
				voNews = new VoNews();
				voNews.vo_easyui(news);
				voNewslist.add(voNews);
			}
			msgNews.setVoNews(voNewslist);
			return msgNews;
		}else{
			result.setData("暂无新闻");
			return msgNews;
		}
	}


	/**
	 * 用户注册的实现方法
	 */
	public MyVoParent doregisterUser(MemberForm userForm) {
		MemberForm data = (MemberForm)userForm;
		List<Object> w = new ArrayList<Object>();
		w.add(data.getF_mNo());
		T_Member member1 = (T_Member) super.find("from T_Member where f_mNo=?", w);
		if(member1!=null&&!member1.getF_mNo().trim().equals("")){
			result.isError("学号已经存在了");
			return result;
		}
		T_Member entity = new T_Member();
		entity.setF_mId(UUID.randomUUID().toString());
		entity.setF_mEmail(data.getF_mEmail());
		entity.setF_mName(data.getF_mName());
		entity.setF_mNewTime(new Date());
		entity.setF_mNo(data.getF_mNo());
		entity.setF_mPhone(data.getF_mPhone());
		entity.setF_mPwd(data.getF_mPwd());
		entity.setF_mStatus(EnumMemberStatus.MANAGE_OK);
		super.save(entity);
		return result;
	}
	
	
	
	@SuppressWarnings("unchecked")
	public MyVoParent doGroupactionById(MemberForm userForm) {
		MsgGroupAction groupAction= new MsgGroupAction();
		List<Object> w = new ArrayList<Object>();
		w.add(userForm.getF_gaId());
		List<T_GroupAction> actionsList =  (List<T_GroupAction>) super.findAll("from T_GroupAction where f_gaId=?", w);
		List<VoGroupAction> glist = new ArrayList<VoGroupAction>();
		if(actionsList.size() !=0){
			for(T_GroupAction news : actionsList){
				VoGroupAction voGroupAction = new VoGroupAction();
				voGroupAction.vo_easyui(news);
				glist.add(voGroupAction);
			}
			groupAction.setAction(glist);
			return groupAction;
		}else{
			result.setData("暂无活动");
			return result;
		}
	}
}
