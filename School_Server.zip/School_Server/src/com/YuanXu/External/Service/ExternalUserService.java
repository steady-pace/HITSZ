package com.YuanXu.External.Service;
import com.YuanXu.External.FormBean.MemberForm;
import com.YuanXu.Util.Parent.MyServiceInterface;
import com.YuanXu.Util.Parent.MyVoParent;


public interface ExternalUserService extends MyServiceInterface{

	/**
	 * 用户登录接口
	 * @param dataForm
	 * @return
	 */
	public MyVoParent doLoginUser(MemberForm dataForm);

	/**
	 * 修改密码
	 * @param userForm
	 * @return
	 */
	public MyVoParent doUpdateUserPw(MemberForm userForm);
	/**
	 * 退出
	 * @param userForm
	 * @return
	 */
	public MyVoParent doUserLogOut(MemberForm userForm); 
	/**
	 * 注册
	 * @param userForm
	 * @return
	 */
	public MyVoParent doregisterUser(MemberForm userForm); 
	/**
	 * 寻找失物
	 * @param userForm
	 * @return
	 */
	public MyVoParent doLookforlose(MemberForm userForm); 
	/**
	 * 拾物招领
	 * @param userForm
	 * @return
	 */
	public MyVoParent doGetforlose(MemberForm userForm); 
	/**
	 * 校园新闻
	 * @param userForm
	 * @return
	 */
	public MyVoParent doSchoolnews(MemberForm userForm); 
	/**
	 * 社团活动
	 * @param userForm
	 * @return
	 */
	public MyVoParent doGroupaction(MemberForm userForm); 
	/**
	 * 社团活动
	 * @param userForm
	 * @return
	 */
	public MyVoParent doGroupactionById(MemberForm userForm); 
	/**
	 * 点赞
	 * @param userForm
	 * @return
	 */
	public MyVoParent doGivegood(MemberForm userForm); 
	/**
	 * 点批
	 * @param userForm
	 * @return
	 */
	public MyVoParent doGivehit(MemberForm userForm); 

}

