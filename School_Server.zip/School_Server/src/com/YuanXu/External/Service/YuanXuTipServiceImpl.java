package com.YuanXu.External.Service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

import com.YuanXu.External.Entity.T_YuanXuTip;
import com.YuanXu.External.Web.MsgYuanXuTip;
import com.YuanXu.Util.Parent.MyServiceParent;
@Service("yuanXuTipService")
@Scope("prototype")
public class YuanXuTipServiceImpl extends MyServiceParent implements YuanXuTipService {
	private String hql = "from T_YuanXuTip";
	@SuppressWarnings("deprecation")
	public MsgYuanXuTip doCheck(String projectName) {
		// TODO Auto-generated method stub
		MsgYuanXuTip result = new MsgYuanXuTip();
		List<Object> wp = new ArrayList<Object>();
		T_YuanXuTip tYuanXuTip = (T_YuanXuTip) this.find(hql, wp);
		if(tYuanXuTip == null){
			T_YuanXuTip tYuanXuTip2 = new T_YuanXuTip();
			tYuanXuTip2.isNew(projectName);
			this.save(tYuanXuTip2);
			result.setLastTime("第一次检测");
		}else{
			result.setLastTime(tYuanXuTip.getF_lastTime().toLocaleString());
			tYuanXuTip.setF_lastTime(new Date());
		}
		result.isSuccess();
		return result;
	}
	@Override
	public void initClassName() {
		// TODO Auto-generated method stub
		
	}

}
