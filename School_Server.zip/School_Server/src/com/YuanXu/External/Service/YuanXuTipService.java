package com.YuanXu.External.Service;

import com.YuanXu.External.Web.MsgYuanXuTip;



public interface YuanXuTipService {
	public MsgYuanXuTip doCheck(String projectName);
}
