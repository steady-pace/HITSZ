package com.YuanXu.External.Web;


public class MsgCarrier implements java.io.Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public String result;
	public String data;
	
	public MsgCarrier(){
		
	}
	
	public MsgCarrier(String result,String data){
		this.result = result;
		this.data = data;
	}
	
	public String getResult() {
		if(result == null){
			return "input";
		}
		return result;
	}
	public void setResult(String result) {
		
		this.result = result;
	}
	public String getData() {
		if(data == null){
			data = "serivce-fail";
		}
		return data;
	}
	public void setData(String data) {
		this.data = data;
	}
	public void isSuccess(String data){
		this.result = "success";
		this.data = data;
	}

	public void isError(String data){
		this.result = "error";
		this.data = data;
	}
	
	public void isException(String data){
		this.result = "input";
		this.data = data;
	}
	
	public void isException(){
		this.result = "input";
		this.data = "操作异常!";
	}
	
	public void isSuccess(){
		this.result = "success";
		this.data = "操作成功!";
	}

	public void isError(){
		this.result = "error";
		this.data = "操作失败!";
	}
}	
