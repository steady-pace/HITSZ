package com.YuanXu.External.Web;

import java.util.List;

import com.YuanXu.External.Vo.VoGetGoods;
import com.YuanXu.Util.Parent.MyVoParent;


public class MsgGetGoods extends MyVoParent implements java.io.Serializable{

	private static final long serialVersionUID = 1L;

	private List<VoGetGoods> getGoods ;

	public List<VoGetGoods> getGetGoods() {
		return getGoods;
	}

	public void setGetGoods(List<VoGetGoods> getGoods) {
		this.getGoods = getGoods;
	}

}
