package com.YuanXu.External.Web;

import java.util.List;

import com.YuanXu.External.Vo.VoLoseGoods;
import com.YuanXu.Util.Parent.MyVoParent;


public class MsgLoseGoods extends MyVoParent implements java.io.Serializable{

	private static final long serialVersionUID = 1L;

	private List<VoLoseGoods> loseGoods ;

	public List<VoLoseGoods> getLoseGoods() {
		return loseGoods;
	}

	public void setLoseGoods(List<VoLoseGoods> loseGoods) {
		this.loseGoods = loseGoods;
	}



}
