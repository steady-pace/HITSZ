package com.YuanXu.External.Web;

import java.util.List;

import com.YuanXu.External.Vo.VoNews;
import com.YuanXu.Util.Parent.MyVoParent;


public class MsgNews extends MyVoParent implements java.io.Serializable{


	private static final long serialVersionUID = 1L;

	private List<VoNews>VoNews ;

	public List<VoNews> getVoNews() {
		return VoNews;
	}

	public void setVoNews(List<VoNews> voNews) {
		VoNews = voNews;
	}

}
