package com.YuanXu.External.Web;


public class MsgYuanXuTip extends MsgCarrier implements java.io.Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public String checkStartTime;
	public String checkResultTime;
	public String lastTime;//上次检测时间
	
	public MsgYuanXuTip() {
		super();
	}
	public void isMsgYuanXuTip(MsgYuanXuTip msTip) {
		this.lastTime = msTip.getLastTime();
		super.result = msTip.getResult();
		super.data = msTip.getData();
	}
	public String getCheckStartTime() {
		return checkStartTime;
	}
	public void setCheckStartTime(String checkStartTime) {
		this.checkStartTime = checkStartTime;
	}
	public String getCheckResultTime() {
		return checkResultTime;
	}
	public void setCheckResultTime(String checkResultTime) {
		this.checkResultTime = checkResultTime;
	}
	public String getLastTime() {
		return lastTime;
	}
	public void setLastTime(String lastTime) {
		this.lastTime = lastTime;
	}
	
}
