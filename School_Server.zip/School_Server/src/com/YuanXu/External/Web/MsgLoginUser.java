package com.YuanXu.External.Web;

import com.YuanXu.External.Vo.VoMember;
import com.YuanXu.Util.Parent.MyVoParent;


public class MsgLoginUser extends MyVoParent implements java.io.Serializable{

	/**
	 * 用户登录
	 */
	private static final long serialVersionUID = 1L;

	private VoMember voUser;

	public VoMember getVoUser() {
		return voUser;
	}
	public void setVoUser(VoMember voUser) {
		this.voUser = voUser;
	}
}
