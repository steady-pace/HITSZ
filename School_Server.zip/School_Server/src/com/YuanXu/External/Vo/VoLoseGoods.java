package com.YuanXu.External.Vo;

import com.YuanXu.WebWorker.Entity.T_LoseGoods;

public class VoLoseGoods {
	private String f_lId;  //Id
	private String f_lType; //失物类型
	private String f_lDescribe; //失物特征描述
	private String f_lPhone; //失主的联系方式
	
	public VoLoseGoods(){
		super();
	}
	
	public VoLoseGoods(T_LoseGoods tl){
		super();
		this.f_lId = tl.getF_lId();
		this.f_lType = tl.getF_lType();
		this.f_lDescribe = tl.getF_lDescribe();
		this.f_lPhone = tl.getF_lPhone();
	}
	
	
	public void vo_easyui(T_LoseGoods tl){
		this.f_lId = tl.getF_lId();
		this.f_lType = tl.getF_lType();
		this.f_lDescribe = tl.getF_lDescribe();
		this.f_lPhone = tl.getF_lPhone();
	}

	public String getF_lId() {
		return f_lId;
	}
	public void setF_lId(String fLId) {
		f_lId = fLId;
	}
	public String getF_lType() {
		return f_lType;
	}
	public void setF_lType(String fLType) {
		f_lType = fLType;
	}
	public String getF_lDescribe() {
		return f_lDescribe;
	}
	public void setF_lDescribe(String fLDescribe) {
		f_lDescribe = fLDescribe;
	}
	public String getF_lPhone() {
		return f_lPhone;
	}
	public void setF_lPhone(String fLPhone) {
		f_lPhone = fLPhone;
	}
	
}
