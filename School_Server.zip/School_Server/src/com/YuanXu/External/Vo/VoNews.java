package com.YuanXu.External.Vo;



import com.YuanXu.Util.Parent.MyEntityParent;
import com.YuanXu.Util.Util.DateUtil;
import com.YuanXu.WebWorker.Entity.T_News;

public class VoNews {
	private String f_nId;  //Id
	private String f_nTitle; //新闻标题
	private String f_nSubtitle; //副标题
	private String f_nDate; //时间
	private String f_nContent; //内容
	private String f_nAuthor; //作者
	private String f_type;
	private String f_nUrl; //url
	
	public void vo_easyui(MyEntityParent data){
		T_News news = (T_News)data;
		this.f_nAuthor = news.getF_nAuthor();
		this.f_nContent = news.getF_nContent();
		if(news.getF_nDate()!=null){
			this.f_nDate = DateUtil.dateToString(news.getF_nDate());
		}else{
			this.f_nDate = "";
		}
		this.f_nId = news.getF_nId();
		this.f_nSubtitle = news.getF_nSubtitle();
		this.f_nTitle = news.getF_nTitle();
		this.f_nUrl = news.getF_nUrl();
	}
	
	
	
	public String getF_nUrl() {
		return f_nUrl;
	}



	public void setF_nUrl(String fNUrl) {
		f_nUrl = fNUrl;
	}



	public String getF_nId() {
		return f_nId;
	}
	public void setF_nId(String fNId) {
		f_nId = fNId;
	}
	public String getF_nTitle() {
		return f_nTitle;
	}
	public void setF_nTitle(String fNTitle) {
		f_nTitle = fNTitle;
	}
	public String getF_nSubtitle() {
		return f_nSubtitle;
	}
	public void setF_nSubtitle(String fNSubtitle) {
		f_nSubtitle = fNSubtitle;
	}
	
	public String getF_nDate() {
		return f_nDate;
	}

	public void setF_nDate(String fNDate) {
		f_nDate = fNDate;
	}

	public String getF_nContent() {
		return f_nContent;
	}
	public void setF_nContent(String fNContent) {
		f_nContent = fNContent;
	}
	public String getF_nAuthor() {
		return f_nAuthor;
	}
	public void setF_nAuthor(String fNAuthor) {
		f_nAuthor = fNAuthor;
	}
	public String getF_type() {
		return f_type;
	}

	public void setF_type(String fType) {
		f_type = fType;
	}
}
