package com.YuanXu.External.Vo;

import com.YuanXu.Util.Parent.MyVoParent;

/**
 * 
 * 会员使用APP时候 
 * 
 * @author Administrator
 *
 */
@SuppressWarnings("serial")
public class VoMember extends MyVoParent {
	//公用
	private String appKey;//唯一码
	private String f_mId;//用户ID
	
	//登录接口
	private String f_mName;//用户账号
	private String f_mPwd;//用户密码
	private String systemfrom;
	
	
	
	
	public String getAppKey() {
		return appKey;
	}
	public void setAppKey(String appKey) {
		this.appKey = appKey;
	}
	public String getF_mId() {
		return f_mId;
	}
	public void setF_mId(String fMId) {
		f_mId = fMId;
	}
	public String getF_mName() {
		return f_mName;
	}
	public void setF_mName(String fMName) {
		f_mName = fMName;
	}
	public String getF_mPwd() {
		return f_mPwd;
	}
	public void setF_mPwd(String fMPwd) {
		f_mPwd = fMPwd;
	}
	public String getSystemfrom() {
		return systemfrom;
	}
	public void setSystemfrom(String systemfrom) {
		this.systemfrom = systemfrom;
	}
	 
	

	
}
