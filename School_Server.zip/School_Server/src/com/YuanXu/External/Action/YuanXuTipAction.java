package com.YuanXu.External.Action;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Date;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;

import net.sf.json.JSONObject;

import org.apache.struts2.ServletActionContext;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

import com.YuanXu.External.Service.YuanXuTipService;
import com.YuanXu.External.Web.MsgYuanXuTip;
import com.opensymphony.xwork2.ActionSupport;
@SuppressWarnings({"serial"})
@Service("yuanXuTipAction")
@Scope("prototype")
public class YuanXuTipAction extends ActionSupport{
	@Resource 
	private YuanXuTipService yuanXuTipService;
	private String projectName;
	  
	@SuppressWarnings("deprecation")
	public String checkYuanXuProject() throws IOException{
		MsgYuanXuTip result = new MsgYuanXuTip();
		result.setCheckStartTime(new Date().toLocaleString());
		try {
			result.isMsgYuanXuTip(yuanXuTipService.doCheck(projectName));
		}catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			result.isError(e.getMessage());
		}finally{
			result.setCheckResultTime(new Date().toLocaleString());
			HttpServletResponse response = ServletActionContext.getResponse();    
			response.setCharacterEncoding("UTF-8");    
	        PrintWriter out = response.getWriter();
	        //直接输入响应的内容
	        JSONObject jsonObject = JSONObject.fromObject(result);
			System.out.println(jsonObject.toString());
	        out.print(jsonObject.toString());       
	        out.flush();    
	        out.close();
		}
		return null;
	}

	public String getProjectName() {
		return projectName;
	}

	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}
}
