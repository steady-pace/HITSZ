package com.YuanXu.External.Action;


import java.io.IOException;

import javax.annotation.Resource;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

import com.YuanXu.External.FormBean.MemberForm;
import com.YuanXu.External.Service.ExternalUserService;
import com.YuanXu.Util.Parent.FormBeanParent;
import com.YuanXu.Util.Parent.MyActionParent;
@SuppressWarnings({"serial"})
@Service("externaluserAction")
@Scope("prototype")
public class ExternalUserAction extends MyActionParent{
	@Resource 
	private ExternalUserService externalUserService;
	private MemberForm dataForm = new MemberForm();
	
	@Override
	public void doPutPower() {
	}
	@Override
	public void doStartAction() {
		super.setServiceIntterface(externalUserService);
		super.setDataParentForm(dataForm);
	}
	
	/**
	 * 用户登录接口
	 * @param dataForm
	 * @throws IOException 
	 */
	public void loginUser() throws IOException{
		returnJSONObject(externalUserService.doLoginUser(dataForm));
	}
	
	/**
	 * 修改密码
	 * @throws IOException
	 */
	public void updatePw() throws IOException{
		returnJSONObject(externalUserService.doUpdateUserPw(dataForm));
	}
	
	/**
	 * 退出
	 * @throws IOException
	 */
	public void doUserLogOut() throws IOException{
		returnJSONObject(externalUserService.doUserLogOut(dataForm));
	}
	/**
	 * 注册
	 * @throws IOException
	 */
	public void registerUser() throws IOException{
		returnJSONObject(externalUserService.doregisterUser(dataForm));
	}
	/**
	 * 招领
	 * @throws IOException
	 */
	public void doLookforlose() throws IOException{
		returnJSONObject(externalUserService.doLookforlose(dataForm));
	}
	/**
	 * 寻找失物
	 * @throws IOException
	 */
	public void doGetforlose() throws IOException{
		returnJSONObject(externalUserService.doGetforlose(dataForm));
	}
	/**
	 * 校园新闻
	 * @throws IOException
	 */
	public void doSchoolnews() throws IOException{
		returnJSONObject(externalUserService.doSchoolnews(dataForm));
	}
	/**
	 * 社团活动
	 * @throws IOException
	 */
	public void doGroupaction() throws IOException{
		returnJSONObject(externalUserService.doGroupaction(dataForm));
	}
	/**
	 * 社团活动
	 * @throws IOException
	 */
	public void doGroupactionById() throws IOException{
		returnJSONObject(externalUserService.doGroupactionById(dataForm));
	}
	/**
	 * 点赞
	 * @throws IOException
	 */
	public void doGivegood() throws IOException{
		try {
			returnJSONObject(externalUserService.doGivegood(dataForm));
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	/**
	 * 点批
	 * @throws IOException
	 */
	public void doGivehit() throws IOException{
		returnJSONObject(externalUserService.doGivehit(dataForm));
	}
	
	public FormBeanParent getModel() {
		return dataForm;
	}
	public MemberForm getDataForm() {
		return dataForm;
	}
	public void setDataForm(MemberForm dataForm) {
		this.dataForm = dataForm;
	}
}
