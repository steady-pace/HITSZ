package com.YuanXu.External.FormBean;

import com.YuanXu.Util.DES.Des;
import com.YuanXu.Util.Parent.FormBeanParent;

/**
 * 
 * 会员使用APP时候的Form
 * 
 * @author Administrator
 *
 */
public class MemberForm extends FormBeanParent {
	
	//公用
	private String appKey;//唯一码
	private String f_mId;//用户ID
	
	//登录接口
	private String f_mName;//用户姓名
	private String f_mPwd;//用户密码
	private String systemfrom;
	private String f_mNewPwd ; // 新密码
	private String f_sex ; //性别
	private String f_email ; //邮箱
	
	
	private String f_mEmail; //输入有效邮箱地址并成功激活，可用此邮箱做为登录账号及找回密码
	private String f_mNo; //会员编号，经销商线下登记后系统按规则生成的编号
	private String f_mPhone; //手机号码，经销商线下登记后系统输入
	private String f_newtime;
	
	private String f_gaId;  //活动id
	
	public String getF_gaId() {
		return f_gaId;
	}
	public void setF_gaId(String fGaId) {
		f_gaId = fGaId;
	}
	public String getF_mEmail() {
		return f_mEmail;
	}
	public void setF_mEmail(String fMEmail) {
		f_mEmail = fMEmail;
	}
	public String getF_mNo() {
		return f_mNo;
	}
	public void setF_mNo(String fMNo) {
		f_mNo = fMNo;
	}
	public String getF_mPhone() {
		return f_mPhone;
	}
	public void setF_mPhone(String fMPhone) {
		f_mPhone = fMPhone;
	}
	public String getF_newtime() {
		return f_newtime;
	}
	public void setF_newtime(String fNewtime) {
		f_newtime = fNewtime;
	}
	public String getF_sex() {
		return f_sex;
	}
	public void setF_sex(String fSex) {
		f_sex = fSex;
	}
	public String getF_email() {
		return f_email;
	}
	public void setF_email(String fEmail) {
		f_email = fEmail;
	}
	public String getF_mNewPwd() {
		return f_mNewPwd;
	}
	public void setF_mNewPwd(String fMNewPwd) {
		f_mNewPwd = fMNewPwd;
	}
	public String getAppKey() {
		return appKey;
	}
	public void setAppKey(String appKey) {
		this.appKey = appKey;
	}
	public String getF_mId() {
		return f_mId;
	}
	public void setF_mId(String fMId) {
		f_mId = fMId;
	}
	public String getF_mName() {
		return f_mName;
	}
	public void setF_mName(String fMName) {
		f_mName = fMName;
	}
	public String getF_mPwd() {
		try {
			return Des.decryptDES(this.f_mPwd);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return "";
		}
	}
	public void setF_mPwd(String fMPwd) {
		f_mPwd = fMPwd;
	}
	public String getSystemfrom() {
		return systemfrom;
	}
	public void setSystemfrom(String systemfrom) {
		this.systemfrom = systemfrom;
	}
	

	
	
}
