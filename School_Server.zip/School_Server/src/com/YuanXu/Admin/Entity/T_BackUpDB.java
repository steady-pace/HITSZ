package com.YuanXu.Admin.Entity;
/*
 * 备份数据库
 * 
 */
import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
@SuppressWarnings("serial")
@Entity
@Table(name="tb_backupdb")
public class T_BackUpDB implements Serializable {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Integer f_dbId;
	private Date f_time;
	@Column(length=150)
	private String f_fileName;
	
	public void isNew(String fFileName) {
		f_time = new Date();
		f_fileName = fFileName;
	}

	public T_BackUpDB() {
		super();
	}

	public Integer getF_dbId() {
		return f_dbId;
	}

	public void setF_dbId(Integer fDbId) {
		f_dbId = fDbId;
	}

	public Date getF_time() {
		return f_time;
	}

	public void setF_time(Date fTime) {
		f_time = fTime;
	}

	public String getF_fileName() {
		return f_fileName;
	}

	public void setF_fileName(String fFileName) {
		f_fileName = fFileName;
	}
	
}
