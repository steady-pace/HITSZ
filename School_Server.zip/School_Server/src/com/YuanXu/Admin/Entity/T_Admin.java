package com.YuanXu.Admin.Entity;
/*
 * 后台管理员
 * 
 */
import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.YuanXu.Util.DES.Des;
@SuppressWarnings("serial")
@Entity
@Table(name="tb_admin")
public class T_Admin implements Serializable {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Integer f_adminId;
	@Column(length=20)
	private String f_adminName;
	@Column(length=200)
	private String f_adminPw;
	private Date f_logintime;//最近登录时间
	
	public Integer getF_adminId() {
		return f_adminId;
	}
	public void setF_adminId(Integer fAdminId) {
		f_adminId = fAdminId;
	}
	public String getF_adminName() {
		return f_adminName;
	}
	public void setF_adminName(String fAdminName) {
		f_adminName = fAdminName;
	}
	public String getF_adminPw() {
		try {
			return Des.decryptDES(f_adminPw);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return "";
		}
	}
	public void setF_adminPw(String fAdminPw) {
		try {
			f_adminPw = Des.encryptDES(fAdminPw);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public Date getF_logintime() {
		return f_logintime;
	}
	public void setF_logintime(Date fLogintime) {
		f_logintime = fLogintime;
	}
}
