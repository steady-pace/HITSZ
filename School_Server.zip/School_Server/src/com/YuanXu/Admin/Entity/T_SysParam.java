package com.YuanXu.Admin.Entity;

import java.io.Serializable;
import java.util.UUID;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import com.YuanXu.Admin.FormBean.SysParamForm;
import com.YuanXu.Util.Parent.FormBeanParent;
import com.YuanXu.Util.Parent.MyEntityParent;
import com.YuanXu.Util.Parent.MyVoParent;

/**
 * 系统参数配置实体类
 * @author 罗培彬
 *
 */
@SuppressWarnings("serial")
@Entity
@Table(name="tb_sysparam")
public class T_SysParam extends MyEntityParent implements Serializable {
	@Id
	@Column(length=40)
	private String f_sId;// ID
	@Column(length=20)
	private String f_sName;// 参数名
	@Column(length=100)
	private String f_sValue;// 参数值
	@Column(length=100)
	private String f_sKey;// key
	public T_SysParam(){
		super();
	}
	public String getF_sId() {
		return f_sId;
	}
	public void setF_sId(String fSId) {
		f_sId = fSId;
	}
	public String getF_sName() {
		return f_sName;
	}
	public void setF_sName(String fSName) {
		f_sName = fSName;
	}
	public String getF_sValue() {
		return f_sValue;
	}
	public void setF_sValue(String fSValue) {
		f_sValue = fSValue;
	}
	public String getF_sKey() {
		return f_sKey;
	}
	public void setF_sKey(String fSKey) {
		f_sKey = fSKey;
	}
	@Override
	public MyVoParent isDoOpreate(FormBeanParent parent, MyVoParent result) {
		// TODO Auto-generated method stub
		return result;
	}
	@Override
	public MyVoParent isNews(FormBeanParent parent, MyVoParent result) {
		// TODO Auto-generated method stub
		SysParamForm dataForm = (SysParamForm)parent;
		this.f_sId = UUID.randomUUID().toString();
		this.f_sName = dataForm.getF_sName();
		this.f_sValue = dataForm.getF_sValue();
		this.f_sKey = dataForm.getF_sKey();
		return result;
	}
	@Override
	public MyVoParent isUpdate(FormBeanParent parent, MyVoParent result) {
		// TODO Auto-generated method stub
		SysParamForm dataForm = (SysParamForm)parent;
		this.f_sName = dataForm.getF_sName();
		this.f_sValue = dataForm.getF_sValue();
		this.f_sKey = dataForm.getF_sKey();
		return result;
	}
}
