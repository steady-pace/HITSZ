package com.YuanXu.Admin.Entity;
/*
 * 日志记录
 * 
 */
import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
@SuppressWarnings("serial")
@Entity
@Table(name="tb_log")
public class T_Log implements Serializable {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Integer f_logId;
	private Date f_time;
	@Column(length=50)
	private String f_doIp;
	@Column(length=20)
	private String f_doUser;
	@Column(length=60)
	private String f_doStr;
	@Column(length=60)
	private String f_doResult;
	@Column(length=200)
	private String f_doMothod;
	@Column(length=1000)
	private String f_exception;
	
	public T_Log() {
		super();
	}
	
	public T_Log(Date fTime, String fDoUser, String fDoStr,
			String fDoResult, String fDoMothod, String fException,String fDoIp) {
		super();
		f_time = fTime;
		f_doUser = fDoUser;
		f_doStr = fDoStr;
		f_doResult = fDoResult;
		f_doMothod = fDoMothod;
		f_exception = fException;
		f_doIp = fDoIp;
	}
	public Integer getF_logId() {
		return f_logId;
	}
	public void setF_logId(Integer fLogId) {
		f_logId = fLogId;
	}
	public Date getF_time() {
		return f_time;
	}
	public void setF_time(Date fTime) {
		f_time = fTime;
	}
	public String getF_doStr() {
		return f_doStr;
	}
	public void setF_doStr(String fDoStr) {
		f_doStr = fDoStr;
	}
	public String getF_doResult() {
		return f_doResult;
	}
	public void setF_doResult(String fDoResult) {
		f_doResult = fDoResult;
	}
	public String getF_doMothod() {
		return f_doMothod;
	}
	public void setF_doMothod(String fDoMothod) {
		f_doMothod = fDoMothod;
	}
	public String getF_exception() {
		return f_exception;
	}
	public void setF_exception(String fException) {
		f_exception = fException;
	}
	public String getF_doUser() {
		return f_doUser;
	}
	public void setF_doUser(String fDoUser) {
		f_doUser = fDoUser;
	}

	public String getF_doIp() {
		return f_doIp;
	}

	public void setF_doIp(String fDoIp) {
		f_doIp = fDoIp;
	}
	
}
