package com.YuanXu.Admin.Vo;

import com.YuanXu.Admin.Entity.T_BackUpDB;
import com.YuanXu.Util.Parent.MyVoParent;

public class VoBackUpDB extends MyVoParent{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String f_dbId;
	private String f_time;
	private String f_fileName;
	private String f_opreate;
	
	@SuppressWarnings("deprecation")
	public VoBackUpDB(T_BackUpDB tDb) {
		super();
		f_dbId = tDb.getF_dbId() + "";
		f_time = tDb.getF_time().toLocaleString();
		f_fileName = tDb.getF_fileName();
		f_opreate = "";
	}
	public String getF_dbId() {
		return f_dbId;
	}
	public void setF_dbId(String fDbId) {
		f_dbId = fDbId;
	}
	public String getF_time() {
		return f_time;
	}
	public void setF_time(String fTime) {
		f_time = fTime;
	}
	public String getF_fileName() {
		return f_fileName;
	}
	public void setF_fileName(String fFileName) {
		f_fileName = fFileName;
	}
	public String getF_opreate() {
		return f_opreate;
	}
	public void setF_opreate(String fOpreate) {
		f_opreate = fOpreate;
	}
	
}
