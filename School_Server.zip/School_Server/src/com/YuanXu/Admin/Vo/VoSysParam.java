package com.YuanXu.Admin.Vo;

import com.YuanXu.Admin.Entity.T_SysParam;
import com.YuanXu.Util.Parent.MyEntityParent;
import com.YuanXu.Util.Parent.MyVoInterface;
import com.YuanXu.Util.Parent.MyVoParent;

/**
 * 系统参数配置Vo
 * @author 罗培彬
 *
 */
public class VoSysParam extends MyVoParent implements MyVoInterface{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String f_sId;// ID
	private String f_sName;// 参数名
	private String f_sValue;// 参数值
	private String f_sKey;// key
	public VoSysParam(){
		super();
	}
	public void vo_easyui(MyEntityParent data) {
		T_SysParam t = (T_SysParam)data;
		this.f_sId = t.getF_sId();
		this.f_sName = t.getF_sName();
		this.f_sValue = t.getF_sValue();
		this.f_sKey = t.getF_sKey();
	}
	public String getF_sId() {
		return f_sId;
	}
	public void setF_sId(String fSId) {
		f_sId = fSId;
	}
	public String getF_sName() {
		return f_sName;
	}
	public void setF_sName(String fSName) {
		f_sName = fSName;
	}
	public String getF_sValue() {
		return f_sValue;
	}
	public void setF_sValue(String fSValue) {
		f_sValue = fSValue;
	}
	public String getF_sKey() {
		return f_sKey;
	}
	public void setF_sKey(String fSKey) {
		f_sKey = fSKey;
	}
	
}
