package com.YuanXu.Admin.Vo;

import com.YuanXu.Admin.Entity.T_Log;
import com.YuanXu.Util.Parent.MyVoParent;



public class VoLog extends MyVoParent{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Integer f_logId;
	private String f_doIp;
	private String f_time;
	private String f_doUser;
	private String f_doStr;
	private String f_doResult;
	private String f_doMothod;
	private String f_exception;
	
	@SuppressWarnings("deprecation")
	public VoLog(T_Log tLog) {
		super();
		f_logId = tLog.getF_logId();
		f_doIp = tLog.getF_doIp();
		f_time = tLog.getF_time().toLocaleString();
		f_doUser = tLog.getF_doUser();
		f_doStr = tLog.getF_doStr();
		f_doResult = tLog.getF_doResult();
		f_doMothod = tLog.getF_doMothod();
		f_exception = tLog.getF_exception();
	}
	
	public Integer getF_logId() {
		return f_logId;
	}
	public void setF_logId(Integer fLogId) {
		f_logId = fLogId;
	}
	public String getF_time() {
		return f_time;
	}
	public void setF_time(String fTime) {
		f_time = fTime;
	}
	public String getF_doUser() {
		return f_doUser;
	}
	public void setF_doUser(String fDoUser) {
		f_doUser = fDoUser;
	}
	public String getF_doStr() {
		return f_doStr;
	}
	public void setF_doStr(String fDoStr) {
		f_doStr = fDoStr;
	}
	public String getF_doResult() {
		return f_doResult;
	}
	public void setF_doResult(String fDoResult) {
		f_doResult = fDoResult;
	}
	public String getF_doMothod() {
		return f_doMothod;
	}
	public void setF_doMothod(String fDoMothod) {
		f_doMothod = fDoMothod;
	}
	public String getF_exception() {
		return f_exception;
	}
	public void setF_exception(String fException) {
		f_exception = fException;
	}
	public String getF_doIp() {
		return f_doIp;
	}
	public void setF_doIp(String fDoIp) {
		f_doIp = fDoIp;
	}
	
}
