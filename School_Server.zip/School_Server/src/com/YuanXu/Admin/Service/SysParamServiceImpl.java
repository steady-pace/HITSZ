package com.YuanXu.Admin.Service;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

import com.YuanXu.Admin.Entity.T_SysParam;
import com.YuanXu.Admin.Vo.VoSysParam;
import com.YuanXu.Util.Parent.MyServiceParent;

/**
 * 系统参数实现类
 * @author 罗培彬
 *
 */
@Service("sysParamService")
@Scope("prototype")
public class SysParamServiceImpl extends MyServiceParent implements SysParamService{

	@Override
	public void initClassName() {
		// TODO Auto-generated method stub
		super.setTableClass(T_SysParam.class);
		super.setVoClass(VoSysParam.class);
		super.setIdName("f_sId");
		//获取easyui列表传特殊条件
		super.setGetDateWhere(null, null);
	}

}
