package com.YuanXu.Admin.Service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

import com.YuanXu.Admin.Entity.T_Log;
import com.YuanXu.Admin.FormBean.LogForm;
import com.YuanXu.Admin.Vo.VoLog;
import com.YuanXu.Util.Parent.MyServiceParent;
import com.YuanXu.Util.Util.GetIPUtil;
import com.YuanXu.Util.Util.JsonEasyUI;
import com.YuanXu.Util.Util.QueryResult;
@Service("logService")
@Scope("prototype")
public class LogServiceImpl extends MyServiceParent implements LogService {
	
	private String tableName = "T_Log";
	public JsonEasyUI<VoLog> getData(LogForm dataForm) {
		// TODO Auto-generated method stub
		JsonEasyUI<VoLog> jsonEasyUI = new JsonEasyUI<VoLog>();
		List<VoLog> voLogs = new ArrayList<VoLog>();
		QueryResult<T_Log> qr = this.getData(tableName, null,null, dataForm);
		for(T_Log tLog : qr.getResultList()){
			VoLog voLog = new VoLog(tLog);
			voLogs.add(voLog);
		}
		jsonEasyUI.setRows(voLogs);
		jsonEasyUI.setTotal(qr.getTotalrecord());
		return jsonEasyUI;
	}

	public void makeLog( String fDoUser, String fDoStr,
			String fDoResult, String fException){
		T_Log tLog = new T_Log( new Date(), fDoUser, fDoStr, fDoResult, getTraceInfo(), fException,GetIPUtil.getMyIP());
		this.save(tLog);
	}
	
	public String getTraceInfo(){  
        StringBuffer sb = new StringBuffer();   
        StackTraceElement[] stacks = new Throwable().getStackTrace();  
        sb.append("class: ").append(stacks[1].getClassName()).append("; method: ").append(stacks[1].getMethodName());  
        return sb.toString();  
    }

	@Override
	public void initClassName() {
		// TODO Auto-generated method stub
		
	}
}
