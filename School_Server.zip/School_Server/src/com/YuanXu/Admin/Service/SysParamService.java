package com.YuanXu.Admin.Service;

import com.YuanXu.Util.Parent.MyServiceInterface;

/**
 * 系统参数接口类
 * @author 罗培彬
 *
 */
public interface SysParamService extends MyServiceInterface {

}
