package com.YuanXu.Admin.Service;

import java.io.FileNotFoundException;
import java.io.IOException;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

import com.YuanXu.Admin.Entity.T_BackUpDB;
import com.YuanXu.Admin.FormBean.BackUpDBForm;
import com.YuanXu.Admin.Vo.VoBackUpDB;
import com.YuanXu.Util.BackUpDB.DatabaseBackup;
import com.YuanXu.Util.Parent.FormBeanParent;
import com.YuanXu.Util.Parent.MyServiceParent;
import com.YuanXu.Util.Parent.MyVoParent;
import com.YuanXu.Util.Util.JsonEasyUI;
import com.YuanXu.Util.Util.QueryResult;
@Service("backUpDBService")
@Scope("prototype")
public class BackUpDBServiceImpl extends MyServiceParent implements
		BackUpDBService {
	private String tableName = "T_BackUpDB";
	private String tableId = "f_dbId";
	public MyVoParent add(FormBeanParent dataParentForm)
			throws FileNotFoundException, IOException {
		// TODO Auto-generated method stub
		String fileName = null;
		try {
			fileName = DatabaseBackup.backupDB();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			result.isError("备份出错!无法备份.");
			return result;
		}
		T_BackUpDB tBackUpDB = new T_BackUpDB();
		tBackUpDB.isNew(fileName);
		super.save(tBackUpDB);
		return result;
	}

	public MyVoParent delete(FormBeanParent dataParentForm) {
		// TODO Auto-generated method stub
		BackUpDBForm dataForm = (BackUpDBForm) dataParentForm;
		result = super.dele(dataForm, tableName, tableId);
		return result;
	}

	public MyVoParent doOpreate(FormBeanParent dataParentForm) {
		// TODO Auto-generated method stub
		BackUpDBForm dataForm = (BackUpDBForm) dataParentForm;
		try {
			if(!DatabaseBackup.restoreDB(dataForm.getF_fileName())){
				result.isError("文件已经损坏或丢失，无法恢复!");
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			result.isError("文件已经损坏或丢失，无法恢复!");
		}
		return result;
	}

	public MyVoParent getData(FormBeanParent dataParentForm) {
		// TODO Auto-generated method stub
		BackUpDBForm dataForm = (BackUpDBForm) dataParentForm;
		JsonEasyUI<VoBackUpDB> jsonEasyUI = new JsonEasyUI<VoBackUpDB>();
		QueryResult<T_BackUpDB> qr = super.getData(tableName, null,null,dataForm);
		for(T_BackUpDB obj : qr.getResultList()){
			VoBackUpDB vo = new VoBackUpDB(obj);
			jsonEasyUI.getRows().add(vo);
		}
		jsonEasyUI.setTotal(qr.getTotalrecord());
		return jsonEasyUI;
	}

	public MyVoParent update(FormBeanParent dataParentForm)
			throws FileNotFoundException, IOException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void initClassName() {
		// TODO Auto-generated method stub
		
	}
}
