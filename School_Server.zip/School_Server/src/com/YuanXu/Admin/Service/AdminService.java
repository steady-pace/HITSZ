package com.YuanXu.Admin.Service;

import com.YuanXu.Admin.FormBean.AdminForm;


public interface AdminService {
	/**
	 * 
	 * @param adminName 登录名
	 * @param adminPw  密码
	 * @return 
	 */
	public String[] dologin(AdminForm dataForm);
	
	public String[] addAdmin(AdminForm dataForm);
	
	public String[] updateName(AdminForm dataForm);
	
	public String[] updatePw(AdminForm dataForm);

}
