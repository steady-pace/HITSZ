package com.YuanXu.Admin.Service;

//import java.util.Date;
//import java.util.UUID;

import javax.annotation.Resource;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

import com.YuanXu.Admin.FormBean.AdminForm;
import com.YuanXu.Util.Parent.MyServiceParent;
import com.YuanXu.Util.Parent.MyVoParent;
@Service("initDataService")
@Scope("prototype")
public class InitDataServiceImpl extends MyServiceParent implements
		InitDataService {
	@Resource
	private AdminService adminService;
	public MyVoParent doInitData() {
		// TODO Auto-generated method stub
		MyVoParent result = new MyVoParent();
		String adminName = "lyra";
		String adminPw = "lyra";
		AdminForm dataForm = new AdminForm();
		dataForm.setF_adminName(adminName);
		dataForm.setF_adminPw(adminPw);
		String[] resultadmin = adminService.addAdmin(dataForm);
		System.out.println(resultadmin[0] + ":" + resultadmin[1]);
		return result;
	}
	@Override
	public void initClassName() {
		// TODO Auto-generated method stub
		
	}
	
}
