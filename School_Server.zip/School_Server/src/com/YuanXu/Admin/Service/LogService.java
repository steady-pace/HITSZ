package com.YuanXu.Admin.Service;

import com.YuanXu.Admin.FormBean.LogForm;
import com.YuanXu.Admin.Vo.VoLog;
import com.YuanXu.Util.Util.JsonEasyUI;

public interface LogService {
	public void makeLog( String fDoUser, String fDoStr,String fDoResult, String fException);
	public JsonEasyUI<VoLog> getData(LogForm dataForm);
}
