package com.YuanXu.Admin.Service;

import java.net.URLDecoder;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.annotation.Resource;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;


import com.YuanXu.Admin.Entity.T_Admin;
import com.YuanXu.Admin.FormBean.AdminForm;
import com.YuanXu.Util.Filter.HTTPSessionUtil;
import com.YuanXu.Util.Parent.MyServiceParent;
import com.YuanXu.Util.RSA.BytesUtil;
import com.YuanXu.Util.RSA.RSAUtil;
import com.YuanXu.Util.Util.FileUtil;
@Service("adminService")
@Scope("prototype")
@SuppressWarnings("deprecation")
public class AdminServiceImpl extends MyServiceParent implements AdminService{
	private String hql = "from T_Admin";
	@Resource
	private LogService logService;
	public String[] dologin(AdminForm dataForm) {
		//判断验证码
		if(dataForm.getRandom() == null || dataForm.getRandom().length() == 0){
			logService.makeLog("未知", "请求后台登录", "验证码为NULL！","");
			return new String[]{"error","验证码错误！"};
		}
		if(!dataForm.getRandom().toLowerCase().equals(HTTPSessionUtil.getObject(HTTPSessionUtil.RANDOM))){
			logService.makeLog("未知", "请求后台登录", "验证码错误！","");
			return new String[]{"error","验证码错误！"};
		}
		byte[] en_result = BytesUtil.hexStringToBytes(dataForm.getF_adminPw());
		byte[] en_name = BytesUtil.hexStringToBytes(dataForm.getF_adminName());
		byte[] de_result;
		byte[] de_name;
		String adminName = "";
		try {
			de_result = RSAUtil.decrypt(RSAUtil.getKeyPair(FileUtil.getKeyPairFilePath()).getPrivate(), en_result);
			StringBuffer sb = new StringBuffer();
			sb.append(new String(de_result));
			String adminPw = sb.reverse().toString();
			adminPw = URLDecoder.decode(adminPw, "UTF-8");
			de_name = RSAUtil.decrypt(RSAUtil.getKeyPair(FileUtil.getKeyPairFilePath()).getPrivate(), en_name);
			StringBuffer sbname = new StringBuffer();
			sbname.append(new String(de_name));
			adminName = sbname.reverse().toString();
			adminName = URLDecoder.decode(adminName, "UTF-8");
			String hql = this.hql + " where f_adminName=?";
			List<Object> wp = new ArrayList<Object>();
			wp.add(adminName);
			T_Admin admin = (T_Admin) this.find(hql,wp);
			if(admin == null || !admin.getF_adminPw().equals(adminPw)){
				logService.makeLog(adminName, "请求后台登录", "账号或密码错误！","");
				return new String[]{"error","账号或密码错误！"};
			}
			String loginTime = null;
			if(admin.getF_logintime() != null){
				loginTime = admin.getF_logintime().toLocaleString();
			}else{
				loginTime = "第一次登录";
			}
			HTTPSessionUtil.putAdmin(adminName,admin.getF_adminId(),loginTime,"");
			admin.setF_logintime(new Date());
			logService.makeLog(adminName, "请求后台登录", "成功登录", "");
			return new String[]{"success","成功"};
		} catch (Exception e) {
			e.printStackTrace();
			logService.makeLog(adminName, "请求后台登录", "异常", e.toString());
			return new String[]{"error","登录异常"};
		}
	}

	public String[] addAdmin(AdminForm dataForm) {
		T_Admin tAdmin = new T_Admin();
		tAdmin.setF_adminName(dataForm.getF_adminName());
		tAdmin.setF_adminPw(dataForm.getF_adminPw());
		this.save(tAdmin);
		return new String[]{"success","成功添加:" + dataForm.getF_adminName()};
	}

	public String[] updateName(AdminForm dataForm) {
		String oldAdminName = (String) HTTPSessionUtil.getObject(HTTPSessionUtil.AdminPower.admin_adminName.getKey());
		String hql = this.hql + " where f_adminName=?";
		List<Object> wp = new ArrayList<Object>();
		wp.add(oldAdminName);
		T_Admin admin = (T_Admin) this.find(hql,wp);
		if(!admin.getF_adminPw().equals(dataForm.getF_adminPw())){
			logService.makeLog(oldAdminName, "请求修改管理员账号", "密码错误！","");
			return new String[]{"error","密码错误！"};
		}
		admin.setF_adminName(dataForm.getF_adminName());
		HTTPSessionUtil.exitAdmin();
		logService.makeLog(oldAdminName, "请求修改管理员账号", "成功修改登录账号！","");
		return new String[]{"success","成功修改登录账号！请重新登录！"};
	}

	public String[] updatePw(AdminForm dataForm) {
		String oldAdminName = (String) HTTPSessionUtil.getObject(HTTPSessionUtil.AdminPower.admin_adminName.getKey());
		String hql = this.hql + " where f_adminName=?";
		List<Object> wp = new ArrayList<Object>();
		wp.add(oldAdminName);
		T_Admin admin = (T_Admin) this.find(hql,wp);
		if(!admin.getF_adminPw().equals(dataForm.getOldPw())){
			logService.makeLog(oldAdminName, "请求修改管理员密码", "密码错误！","");
			return new String[]{"error","密码错误！"};
		}
		admin.setF_adminPw(dataForm.getNewPw());
		HTTPSessionUtil.exitAdmin();
		logService.makeLog(oldAdminName, "请求修改管理员密码", "成功修改", "");
		return new String[]{"success","成功修改登录密码！请重新登录！"};
	}

	@Override
	public void initClassName() {
		// TODO Auto-generated method stub
		
	}
	
}
