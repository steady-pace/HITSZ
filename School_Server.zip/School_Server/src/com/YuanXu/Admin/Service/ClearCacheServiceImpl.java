package com.YuanXu.Admin.Service;

import javax.annotation.Resource;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

import net.sf.ehcache.Cache;

import com.YuanXu.Util.Parent.MyVoParent;
@Service("clearCacheService")
@Scope("prototype")
public class ClearCacheServiceImpl implements ClearCacheService {
	@Resource
	private Cache methodCache;
	public MyVoParent clearCache() {
		// TODO Auto-generated method stub
		MyVoParent myVoParent = new MyVoParent();
		methodCache.removeAll();
		return myVoParent;
	}

}
