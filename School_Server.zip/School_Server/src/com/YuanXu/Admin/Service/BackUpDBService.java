package com.YuanXu.Admin.Service;

import com.YuanXu.Util.Parent.MyServiceInterface;


public interface BackUpDBService extends MyServiceInterface{
	
}
