package com.YuanXu.Admin.Service;

import com.YuanXu.Util.Parent.MyVoParent;

public interface InitDataService {
	public MyVoParent doInitData();
}
