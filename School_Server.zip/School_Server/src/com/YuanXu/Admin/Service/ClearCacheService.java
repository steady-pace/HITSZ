package com.YuanXu.Admin.Service;

import com.YuanXu.Util.Parent.MyVoParent;

public interface ClearCacheService {
	public MyVoParent clearCache();
}
