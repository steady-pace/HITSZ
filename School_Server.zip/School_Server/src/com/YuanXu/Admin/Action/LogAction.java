package com.YuanXu.Admin.Action;

import java.io.PrintWriter;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;

import net.sf.json.JSONObject;

import org.apache.struts2.ServletActionContext;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

import com.YuanXu.Admin.FormBean.LogForm;
import com.YuanXu.Admin.Service.LogService;
import com.YuanXu.Admin.Vo.VoLog;
import com.YuanXu.Util.Parent.MyActionParent;
import com.YuanXu.Util.Util.JsonEasyUI;

@Service("logAction")
@Scope("prototype")
public class LogAction extends MyActionParent{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@Resource
	private LogService logService;
	
	private LogForm dataForm = new LogForm();
	
	public void getLogData(){
		try{
			JsonEasyUI<VoLog> jsonEasyUI = this.logService.getData(dataForm);			
			HttpServletResponse response = ServletActionContext.getResponse();    
			response.setCharacterEncoding("UTF-8");    
	        PrintWriter out = response.getWriter();
	        //直接输入响应的内容
	        JSONObject jsonObject = JSONObject.fromObject(jsonEasyUI);
	        out.print(jsonObject);       
	        out.flush();    
	        out.close();
		}catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
	}
	
	public LogService getLogService() {
		return logService;
	}



	public void setLogService(LogService logService) {
		this.logService = logService;
	}



	public LogForm getDataForm() {
		return dataForm;
	}



	public void setDataForm(LogForm dataForm) {
		this.dataForm = dataForm;
	}



	public static long getSerialversionuid() {
		return serialVersionUID;
	}



	public LogForm getModel() {
		// TODO Auto-generated method stub
		return dataForm;
	}
	@Override
	public void doPutPower() {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void doStartAction() {
		// TODO Auto-generated method stub
		
	}

}
