package com.YuanXu.Admin.Action;

import java.io.IOException;

import javax.annotation.Resource;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

import com.YuanXu.Util.Parent.FormBeanParent;
import com.YuanXu.Util.Parent.MyActionParent;
import com.YuanXu.WebWorker.FormBean.WebWorkerForm;
import com.YuanXu.WebWorker.Service.WebWorkerService;
import com.YuanXu.WebWorker.Vo.VoWebWorker;

/**
 * 网络部工作人员action
 * @author 罗培彬
 *
 */
@SuppressWarnings({"serial"})
@Service("adminWebWorkerAction")
@Scope("prototype")
public class WebWorkerAction extends MyActionParent{
	@Resource
	private WebWorkerService webWorkerService;
	private WebWorkerForm dataForm = new WebWorkerForm();
	private VoWebWorker voWebWorker;
	@Override
	public void doPutPower() {
		// TODO Auto-generated method stub
		
	}
	
	// 终极管理员调用
	public void admin_save_admin(){
		try {
			returnJSONObject(this.webWorkerService.add_admin(dataForm));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	// 终极管理员调用
	public void admin_delete_admin(){
		try {
			returnJSONObject(this.webWorkerService.delete_admin(dataForm));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	// 终极管理员调用
	public void admin_edit_admin(){
		try {
			returnJSONObject(this.webWorkerService.update_admin(dataForm));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	
	@Override
	public void doStartAction() {
		// TODO Auto-generated method stub
		super.setServiceIntterface(webWorkerService);
		super.setDataParentForm(dataForm);
	}
	public FormBeanParent getModel() {
		// TODO Auto-generated method stub
		return dataForm;
	}
	public WebWorkerService getWebWorkerService() {
		return webWorkerService;
	}
	public void setWebWorkerService(WebWorkerService webWorkerService) {
		this.webWorkerService = webWorkerService;
	}
	public WebWorkerForm getDataForm() {
		return dataForm;
	}
	public void setDataForm(WebWorkerForm dataForm) {
		this.dataForm = dataForm;
	}
	public VoWebWorker getVoWebWorker() {
		return voWebWorker;
	}
	public void setVoWebWorker(VoWebWorker voWebWorker) {
		this.voWebWorker = voWebWorker;
	}
	
}
