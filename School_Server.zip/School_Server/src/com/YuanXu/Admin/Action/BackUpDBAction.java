package com.YuanXu.Admin.Action;

import javax.annotation.Resource;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

import com.YuanXu.Admin.FormBean.BackUpDBForm;
import com.YuanXu.Admin.Service.BackUpDBService;
import com.YuanXu.Util.Parent.FormBeanParent;
import com.YuanXu.Util.Parent.MyActionParent;
@SuppressWarnings({"serial"})
@Service("backUpDBAction")
@Scope("prototype")
public class BackUpDBAction extends MyActionParent{
	@Resource 
	private BackUpDBService backUpDBService;
	
	private BackUpDBForm dataForm = new BackUpDBForm();
	
	@Override
	public void doPutPower() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void doStartAction() {
		// TODO Auto-generated method stub
		super.setServiceIntterface(backUpDBService);
		super.setDataParentForm(dataForm);
	}
	
	public BackUpDBForm getDataForm() {
		return dataForm;
	}

	public void setDataForm(BackUpDBForm dataForm) {
		this.dataForm = dataForm;
	}

	public FormBeanParent getModel() {
		// TODO Auto-generated method stub
		return dataForm;
	}

	
}
