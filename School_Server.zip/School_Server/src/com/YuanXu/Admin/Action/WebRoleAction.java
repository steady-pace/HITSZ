package com.YuanXu.Admin.Action;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.apache.struts2.ServletActionContext;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

import com.YuanXu.Util.Parent.FormBeanParent;
import com.YuanXu.Util.Parent.MyActionParent;
import com.YuanXu.WebWorker.FormBean.WebRoleForm;
import com.YuanXu.WebWorker.Service.WebRoleService;
import com.YuanXu.WebWorker.Vo.VoWebRole;
/**
 * 网络部角色Action
 * @author 罗培彬
 *
 */
@SuppressWarnings("serial")
@Service("adminWebRoleAction")
@Scope("prototype")
public class WebRoleAction extends MyActionParent{
	@Resource 
	private WebRoleService webRoleService;
	private WebRoleForm dataForm = new WebRoleForm();
	@Override
	public void doPutPower() {
		// TODO Auto-generated method stub
		
	}
	
	// 终极管理员调用
	public void admin_save_admin(){
		try {
			returnJSONObject(this.webRoleService.add_admin(dataForm));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	// 终极管理员调用
	public void admin_delete_admin(){
		try {
			returnJSONObject(this.webRoleService.delete_admin(dataForm));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	// 终极管理员调用
	public void admin_edit_admin(){
		try {
			returnJSONObject(this.webRoleService.update_admin(dataForm));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void admin_getAll(){
		List<VoWebRole> vo = null;
		try{
			vo = this.webRoleService.getAll();
		}catch (Exception e) {
			e.printStackTrace();
			vo = new ArrayList<VoWebRole>();
		} finally{
			HttpServletRequest request = ServletActionContext.getRequest();
			request.setAttribute("voWebRoles", vo);
		}
	}
	
	@Override
	public void doStartAction() {
		// TODO Auto-generated method stub
		super.setServiceIntterface(webRoleService);
		super.setDataParentForm(dataForm);
	}
	public FormBeanParent getModel() {
		// TODO Auto-generated method stub
		return dataForm;
	}
	public WebRoleService getWebRoleService() {
		return webRoleService;
	}
	public void setWebRoleService(WebRoleService webRoleService) {
		this.webRoleService = webRoleService;
	}
	public WebRoleForm getDataForm() {
		return dataForm;
	}
	public void setDataForm(WebRoleForm dataForm) {
		this.dataForm = dataForm;
	}
	
}
