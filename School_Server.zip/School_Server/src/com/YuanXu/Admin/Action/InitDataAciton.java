package com.YuanXu.Admin.Action;

import javax.annotation.Resource;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

import com.YuanXu.Admin.Service.InitDataService;
import com.YuanXu.Util.BackUpDB.DatabaseBackup;
import com.YuanXu.Util.Parent.MyVoParent;
import com.opensymphony.xwork2.ActionSupport;

@Service("initDataAciton")
@Scope("prototype")
public class InitDataAciton extends ActionSupport {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@Resource
	private InitDataService initDataService;
	
	public String initData(){
		MyVoParent result = null;
		try{
			result = this.initDataService.doInitData();
		}catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			result = new MyVoParent("input", "操作异常!");
		}finally{
			addActionMessage(result.getData());
		}
		return result.getResult();
	}
	
	public String bakeupDB(){
		MyVoParent result = new MyVoParent();
		result.isSuccess();
		try{
			DatabaseBackup.backupDB();
		}catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			result = new MyVoParent("input", "操作异常!");
		}finally{
			addActionMessage(result.getData());
		}
		return result.getResult();
	}

}
