package com.YuanXu.Admin.Action;

import javax.annotation.Resource;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

import com.YuanXu.Admin.FormBean.SysParamForm;
import com.YuanXu.Admin.Service.SysParamService;
import com.YuanXu.Util.Parent.FormBeanParent;
import com.YuanXu.Util.Parent.MyActionParent;

/**
 * 系统参数action
 * @author 罗培彬
 *
 */
@SuppressWarnings("serial")
@Service("sysParamAction")
@Scope("prototype")
public class SysParamAction extends MyActionParent{

	@Resource
	private SysParamService sysParamService;
	
	private SysParamForm dataForm = new SysParamForm();
	
	@Override
	public void doPutPower() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void doStartAction() {
		// TODO Auto-generated method stub
		super.setServiceIntterface(sysParamService);
		super.setDataParentForm(dataForm);
	}

	public FormBeanParent getModel() {
		// TODO Auto-generated method stub
		return dataForm;
	}

	public SysParamService getSysParamService() {
		return sysParamService;
	}

	public void setSysParamService(SysParamService sysParamService) {
		this.sysParamService = sysParamService;
	}

	public SysParamForm getDataForm() {
		return dataForm;
	}

	public void setDataForm(SysParamForm dataForm) {
		this.dataForm = dataForm;
	}

	
}
