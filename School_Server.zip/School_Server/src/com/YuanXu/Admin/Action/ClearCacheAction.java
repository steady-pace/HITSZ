package com.YuanXu.Admin.Action;

import javax.annotation.Resource;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

import com.YuanXu.Admin.Service.ClearCacheService;
import com.YuanXu.Util.Parent.FormBeanParent;
import com.YuanXu.Util.Parent.MyActionParent;
import com.YuanXu.Util.Parent.MyVoParent;
@SuppressWarnings({"serial"})
@Service("clearCacheAction")
@Scope("prototype")
public class ClearCacheAction extends MyActionParent{
	@Resource
	private ClearCacheService clearCacheService;
	
	public String clearCache(){
		MyVoParent result = null;
		try {
			result = clearCacheService.clearCache();
		} catch (Exception e) {
			result = new MyVoParent();
			result.isError("操作失败!");
		}finally{
			addActionMessage(result.getData());
		}
		return result.getResult();
	}

	@Override
	public void doPutPower() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void doStartAction() {
		// TODO Auto-generated method stub
		
	}

	public FormBeanParent getModel() {
		// TODO Auto-generated method stub
		return null;
	}

	
}
