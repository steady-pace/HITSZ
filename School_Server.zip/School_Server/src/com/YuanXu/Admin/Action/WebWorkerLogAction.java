package com.YuanXu.Admin.Action;

import java.io.PrintWriter;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;

import net.sf.json.JSONObject;

import org.apache.struts2.ServletActionContext;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

import com.YuanXu.Util.Parent.FormBeanParent;
import com.YuanXu.Util.Parent.MyActionParent;
import com.YuanXu.Util.Util.JsonEasyUI;
import com.YuanXu.WebWorker.FormBean.WebWorkerLogForm;
import com.YuanXu.WebWorker.Service.WebWorkerLogService;
import com.YuanXu.WebWorker.Vo.VoWebWorkerLog;
/**
 * 网络部工作人员日志action
 * @author 罗培彬
 *
 */
@Service("adminWebWorkerLogAction")
@Scope("prototype")
public class WebWorkerLogAction extends MyActionParent{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@Resource
	private WebWorkerLogService webWorkerLogService;
	private WebWorkerLogForm dataForm = new WebWorkerLogForm();
	
	public void getWebWorkerLogData(){
		try{
			JsonEasyUI<VoWebWorkerLog> jsonEasyUI = this.webWorkerLogService.getData(dataForm);			
			HttpServletResponse response = ServletActionContext.getResponse();    
			response.setCharacterEncoding("UTF-8");    
	        PrintWriter out = response.getWriter();
	        //直接输入响应的内容
	        JSONObject jsonObject = JSONObject.fromObject(jsonEasyUI);
	        out.print(jsonObject);       
	        out.flush();    
	        out.close();
		}catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
	}
	
	@Override
	public void doPutPower() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void doStartAction() {
		// TODO Auto-generated method stub
		
	}

	public FormBeanParent getModel() {
		// TODO Auto-generated method stub
		return dataForm;
	}

	public WebWorkerLogService getWebWorkerLogService() {
		return webWorkerLogService;
	}

	public void setWebWorkerLogService(WebWorkerLogService webWorkerLogService) {
		this.webWorkerLogService = webWorkerLogService;
	}

	public WebWorkerLogForm getDataForm() {
		return dataForm;
	}

	public void setDataForm(WebWorkerLogForm dataForm) {
		this.dataForm = dataForm;
	}
	
}
