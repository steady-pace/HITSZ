package com.YuanXu.Admin.Action;

import javax.annotation.Resource;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

import com.YuanXu.Admin.FormBean.AdminForm;
import com.YuanXu.Admin.Service.AdminService;
import com.YuanXu.Admin.Service.ClearCacheService;
import com.YuanXu.Util.Filter.HTTPSessionUtil;
import com.YuanXu.Util.Parent.MyActionParent;
import com.YuanXu.Util.Parent.MyVoParent;
@SuppressWarnings({"serial"})
@Service("adminAction")
@Scope("prototype")
public class AdminAction extends MyActionParent{
	@Resource 
	private AdminService adminService;
	private AdminForm dataForm = new AdminForm();
	@Resource
	private ClearCacheService clearCacheService;
	/*
	 * 总部登陆
	 */
	public String login(){
		String result[] = null;
		try {
			result = adminService.dologin(dataForm);
		} catch (Exception e) {
			e.printStackTrace();
			result = new String[]{"error","跳转出错"};
		}finally{
			addActionMessage(result[1]);
		}
		return result[0];
	}
	
	public String exit(){
		try{
			HTTPSessionUtil.exitAdmin();
		}catch (Exception e) {
			// TODO: handle exception
			return "input";
		}finally{
			
		}
		return "success";
	}
	
	
	public String updateName(){
		String result[] = null;
		try {
			result = adminService.updateName(dataForm);
		} catch (Exception e) {
			result = new String[]{"error","跳转出错"};
		}finally{
			addActionMessage(result[1]);
		}
		return result[0];
	}
	
	public String updatePw(){
		String result[] = null;
		try {
			result = adminService.updatePw(dataForm);
		} catch (Exception e) {
			result = new String[]{"error","跳转出错"};
		}finally{
			addActionMessage(result[1]);
		}
		return result[0];
	}
	
	public String clearCache(){
		MyVoParent result = null;
		try {
			result = clearCacheService.clearCache();
		} catch (Exception e) {
			result = new MyVoParent();
			result.isError("操作失败!");
		}finally{
			addActionMessage(result.getData());
		}
		return result.getResult();
	}
	
	//测试tokenaction
	public void testEmail_ajax() throws Exception{
		MyVoParent result = new MyVoParent();
		returnJSONObject(result);
	}
	//测试tokenaction
	public String testEmail_form() throws Exception{
		MyVoParent result = new MyVoParent();
		result.setData(result.getData() + "   " +  dataForm.getF_adminName());
		addActionMessage(result.getData());
		return "success";
	}

	public AdminForm getModel() {
		// TODO Auto-generated method stub
		return dataForm;
	}

	@Override
	public void doPutPower() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void doStartAction() {
		// TODO Auto-generated method stub
	}
}
