package com.YuanXu.Admin.Action;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.struts2.ServletActionContext;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

import com.YuanXu.Util.MakeHtml.MakeHtml;
import com.YuanXu.Util.Util.MyAppConfigs;
import com.opensymphony.xwork2.ActionSupport;
@Service("makeHtmlAction")
@Scope("prototype")
public class MakeHtmlAction extends ActionSupport{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public String updateWeb(){
		String flag = "";
		try{
			HttpServletRequest request = ServletActionContext.getRequest();
			String basePath = request.getScheme()+"://"+request.getServerName()+":"+request.getServerPort()+request.getContextPath()+"/";
			MakeHtml makeHtml = new com.YuanXu.Util.MakeHtml.MakeHtml();
			flag = "success";
			String msg = "";
			List<String[]> otherUrls = new ArrayList<String[]>();
			
			otherUrls.add(new String[]{"news.jsp","news.htm"});
			MakeHtml.JspHtml jspHtml = makeHtml.newJspHtml("index.htm", "index.jsp", otherUrls);
			
			if(!makeHtml.makeHtml("",basePath,MyAppConfigs.getValue("webUrl"), MakeHtml.FLAG_YES,jspHtml)){
				flag = "error"; 
			}
			msg = makeHtml.getMakeHtmlReturnInfo();
			addActionMessage(msg);
		}catch (Exception e) {
			// TODO: handle exception
		}
		return flag;
	}
}
