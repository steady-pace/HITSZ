package com.YuanXu.Admin.FormBean;

import com.YuanXu.Util.Parent.FormBeanParent;

/**
 * 系统参数配置Form
 * @author 罗培彬
 *
 */
public class SysParamForm extends FormBeanParent {
	private String f_sId;// ID
	private String f_sName;// 参数名
	private String f_sValue;// 参数值
	private String f_sKey;// key
	public String getF_sId() {
		return f_sId;
	}
	public void setF_sId(String fSId) {
		f_sId = fSId;
	}
	public String getF_sName() {
		return f_sName;
	}
	public void setF_sName(String fSName) {
		f_sName = fSName;
	}
	public String getF_sValue() {
		return f_sValue;
	}
	public void setF_sValue(String fSValue) {
		f_sValue = fSValue;
	}
	public String getF_sKey() {
		return f_sKey;
	}
	public void setF_sKey(String fSKey) {
		f_sKey = fSKey;
	}
	
}
