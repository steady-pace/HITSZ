package com.YuanXu.Admin.FormBean;

import com.YuanXu.Util.Parent.FormBeanParent;

public class LogForm extends FormBeanParent{
	
}
