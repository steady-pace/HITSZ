package com.YuanXu.Admin.FormBean;

import com.YuanXu.Util.Parent.FormBeanParent;

public class BackUpDBForm extends FormBeanParent {
	private String f_dbId;
	private String f_time;
	private String f_fileName;
	public String getF_dbId() {
		return f_dbId;
	}
	public void setF_dbId(String fDbId) {
		f_dbId = fDbId;
	}
	public String getF_time() {
		return f_time;
	}
	public void setF_time(String fTime) {
		f_time = fTime;
	}
	public String getF_fileName() {
		return f_fileName;
	}
	public void setF_fileName(String fFileName) {
		f_fileName = fFileName;
	}
	
}
