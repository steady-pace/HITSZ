package com.YuanXu.Admin.FormBean;

import com.YuanXu.Util.Parent.FormBeanParent;

public class AdminForm extends FormBeanParent{
	//修改登录名
	private String f_adminName;
	private String f_adminPw;
	//修改密码
	private String oldPw;
	private String newPw;
	private String random;
	
	
	public String getRandom() {
		return random;
	}
	public void setRandom(String random) {
		this.random = random;
	}
	public String getF_adminName() {
		return f_adminName;
	}
	public void setF_adminName(String fAdminName) {
		f_adminName = fAdminName;
	}
	public String getF_adminPw() {
		return f_adminPw;
	}
	public void setF_adminPw(String fAdminPw) {
		f_adminPw = fAdminPw;
	}
	public String getOldPw() {
		return oldPw;
	}
	public void setOldPw(String oldPw) {
		this.oldPw = oldPw;
	}
	public String getNewPw() {
		return newPw;
	}
	public void setNewPw(String newPw) {
		this.newPw = newPw;
	}
}
