package com.YuanXu.Util.NewCompressPic;

import java.io.File;

import com.YuanXu.Util.Parent.MyVoParent;
import com.YuanXu.Util.Util.FileUtil;

public class ProImgMakeNewUtil {
	private File inFile;
	private File bigFile;
	private File smallFile;
	private Integer bigW;
	private Integer bigH;
	private Integer middleW;
	private Integer middleH;
	private Integer smallW;
	private Integer smallH;
	private String bigName;
	private String smallName;
	private String bigPath;
	private String smallPath;
	private String middleName;
	private String middlePath;
	private float mid_ratio;
	private float small_ratio;
	
	private int maxMidWith;
	private int maxMidHight;
	private int maxSmallWith;
	private int maxSmallHight;
	private boolean isNeedWH = false;
	
	/*
	 * @param 
	 * 文件路径path 需要 绝对路径，例如："E:\\javapro\\files\\"
	 */
	public ProImgMakeNewUtil(File inFile, Integer smallW, Integer middleW, String bigPath,String bigName,  String smallPath, String smallName, String middlePath, String middleName) {
		this.inFile = inFile;
		this.smallW = smallW;
		this.bigName = bigName;
		this.smallName = smallName;
		this.bigPath = bigPath;
		this.smallPath = smallPath;
		this.middleW = middleW;
		this.middleName = middleName;
		this.middlePath = middlePath;
	}
	
	/*
	 * @param 
	 * 文件路径path 需要 绝对路径，例如："E:\\javapro\\files\\"
	 * ratio : 缩小比例
	 */
	public ProImgMakeNewUtil(File inFile, String savePath,String bigName,String middleName,String smallName,float mid_ratio,float small_ratio) {
		this.inFile = inFile;
		this.bigName = bigName;
		this.smallName = smallName;
		this.bigPath = savePath;
		this.smallPath = savePath;
		this.middleName = middleName;
		this.middlePath = savePath;
		this.mid_ratio = mid_ratio;
		this.small_ratio = small_ratio;
	}
	
	/*
	 * @param 
	 * 文件路径path 需要 绝对路径，例如："E:\\javapro\\files\\"
	 * maxWith : 最大宽度
	 * maxHight： 最大高度
	 */
	public void makeProImgMakeUtil(File inFile, String savePath,String bigName,String middleName,String smallName,int maxMidWH,int maxSmallWH) {
		this.inFile = inFile;
		this.bigName = bigName;
		this.smallName = smallName;
		this.bigPath = savePath;
		this.smallPath = savePath;
		this.middleName = middleName;
		this.middlePath = savePath;
		this.maxMidWith = maxMidWH;
		this.maxMidHight = maxMidWH;
		this.maxSmallWith = maxSmallWH;
		this.maxSmallHight = maxSmallWH;
		this.isNeedWH = true;
	}
	
	public ProImgMakeNewUtil() {
		super();
	}
	
	public MyVoParent makeBigAndSmallImg(){
		MyVoParent result = new MyVoParent();
		//上传大图片
		if(!FileUtil.uploadPhotos(inFile, bigPath, bigName)){
			result.isError("无法上传文件!");
			return result;
		}
		Integer bigWH[] = FileUtil.getImgSize(inFile);
		if(isNeedWH){
			if(maxMidWith <= 0 || maxMidHight <= 0 || maxSmallWith <= 0 || maxSmallHight <= 0){
				result.isError("请正确配置压缩尺寸宽、高值!");
				return result;
			}
			if(bigWH[0] > maxMidWith || bigWH[1] > maxMidHight){
				float oldWH = (float) (bigWH[0]*0.1 / bigWH[1]*0.1); //宽高比例
				float newWH = (float) (maxMidWith*0.1 / maxMidHight*0.1);
				if(oldWH < newWH){
					//以高度进行压缩
					middleH = maxMidHight;
					middleW = bigWH[0] * middleH / bigWH[1];
					smallH = maxSmallHight;
					smallW = bigWH[0] * smallH / bigWH[1];
				}else{
					//以高度进行压缩
					middleW = maxMidWith;
					middleH = middleW * bigWH[1] / bigWH[0];
					smallW = maxSmallWith;
					smallH = smallW * bigWH[1] / bigWH[0];
				}
			}else{
				//mid不做压缩
				middleH = bigWH[0];
				middleW = bigWH[0];
				smallH = maxSmallHight;
				smallW = bigWH[1] * smallH / bigWH[0];
			}
		}else{
			this.middleW = (int)(bigWH[1] * mid_ratio + 0.5);
			this.smallW = (int)(bigWH[1] * small_ratio + 0.5);;
			smallH = smallW * bigWH[1] / bigWH[0];  //压缩后的图片高度
			middleH = middleW * bigWH[1] / bigWH[0];
		}
		CompressPicDemo cPicDemo = new CompressPicDemo();
		if(!cPicDemo.compressPic(inFile, middlePath, middleName, middleW, middleH, false,true)){
			result.isError("生成中图片出错!");
			return result;
		}
		if(!cPicDemo.compressPic(inFile, smallPath, smallName, smallW, smallH, false,true)){
			result.isError("生成小图片出错!");
			return result;
		}
		result.isSuccess();
		return result;
	}
	
	public float getMid_ratio() {
		return mid_ratio;
	}

	public void setMid_ratio(float midRatio) {
		mid_ratio = midRatio;
	}

	public float getSmall_ratio() {
		return small_ratio;
	}

	public void setSmall_ratio(float smallRatio) {
		small_ratio = smallRatio;
	}

	public File getInFile() {
		return inFile;
	}
	public void setInFile(File inFile) {
		this.inFile = inFile;
	}
	public File getBigFile() {
		return bigFile;
	}
	public void setBigFile(File bigFile) {
		this.bigFile = bigFile;
	}
	public File getSmallFile() {
		return smallFile;
	}
	public void setSmallFile(File smallFile) {
		this.smallFile = smallFile;
	}
	public Integer getBigW() {
		return bigW;
	}
	public void setBigW(Integer bigW) {
		this.bigW = bigW;
	}
	public Integer getBigH() {
		return bigH;
	}
	public void setBigH(Integer bigH) {
		this.bigH = bigH;
	}
	public Integer getSmallW() {
		return smallW;
	}
	public void setSmallW(Integer smallW) {
		this.smallW = smallW;
	}
	public Integer getSmallH() {
		return smallH;
	}
	public void setSmallH(Integer smallH) {
		this.smallH = smallH;
	}
	public String getBigName() {
		return bigName;
	}
	public void setBigName(String bigName) {
		this.bigName = bigName;
	}
	public String getSmallName() {
		return smallName;
	}
	public void setSmallName(String smallName) {
		this.smallName = smallName;
	}
	public String getBigPath() {
		return bigPath;
	}
	public void setBigPath(String bigPath) {
		this.bigPath = bigPath;
	}
	public String getSmallPath() {
		return smallPath;
	}
	public void setSmallPath(String smallPath) {
		this.smallPath = smallPath;
	}
	public Integer getMiddleW() {
		return middleW;
	}
	public void setMiddleW(Integer middleW) {
		this.middleW = middleW;
	}
	public Integer getMiddleH() {
		return middleH;
	}
	public void setMiddleH(Integer middleH) {
		this.middleH = middleH;
	}
	public String getMiddleName() {
		return middleName;
	}
	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}
	public String getMiddlePath() {
		return middlePath;
	}
	public void setMiddlePath(String middlePath) {
		this.middlePath = middlePath;
	}
	
	public Integer getMaxMidWith() {
		return maxMidWith;
	}

	public void setMaxMidWith(Integer maxMidWith) {
		this.maxMidWith = maxMidWith;
	}

	public Integer getMaxMidHight() {
		return maxMidHight;
	}

	public void setMaxMidHight(Integer maxMidHight) {
		this.maxMidHight = maxMidHight;
	}

	public Integer getMaxSmallWith() {
		return maxSmallWith;
	}

	public void setMaxSmallWith(Integer maxSmallWith) {
		this.maxSmallWith = maxSmallWith;
	}

	public Integer getMaxSmallHight() {
		return maxSmallHight;
	}

	public void setMaxSmallHight(Integer maxSmallHight) {
		this.maxSmallHight = maxSmallHight;
	}
	
}
