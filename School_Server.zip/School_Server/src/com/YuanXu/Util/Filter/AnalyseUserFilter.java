package com.YuanXu.Util.Filter;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class AnalyseUserFilter implements Filter{
	@SuppressWarnings("unused")
	private FilterConfig config;
	public void init(FilterConfig config)throws ServletException{
		this.config=config;
	}
	public void destroy(){
		config=null;
	}
	public void doFilter(ServletRequest request,ServletResponse response,FilterChain chain)
		throws IOException,ServletException{
 		HttpServletRequest req=(HttpServletRequest)request;
		HttpServletResponse res=(HttpServletResponse)response;
		String url = req.getRequestURI();
		System.out.println("analyseUserFilter");
		if(url.contains("login") || url.contains("randomGraphics2")){
			request.setCharacterEncoding("UTF-8");
			response.setContentType("text/html;charset=UTF-8");
		    chain.doFilter(req, res);
		}else if(url.equals(req.getContextPath() + "/analyseuser") || url.equals(req.getContextPath() + "/analyseuser/")){
			if(!HTTPSessionUtil.isAnanlyseUserLogin()){//登录超时
				res.sendRedirect(req.getContextPath() + "/analyseuser/login.jsp");
			}else{
				res.sendRedirect(req.getContextPath() + "/analyseuser/manage.jsp");
			}
		}else{
			if(!HTTPSessionUtil.isAnanlyseUserLogin()){//登录超时
				res.sendRedirect(req.getContextPath() + "/analyseuser/login.jsp");
			}else{
				request.setCharacterEncoding("UTF-8");
				response.setContentType("text/html;charset=UTF-8");
			    chain.doFilter(req, res);
			}
		}
	}
}
