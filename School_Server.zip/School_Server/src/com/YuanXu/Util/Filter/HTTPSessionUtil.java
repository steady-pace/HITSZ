package com.YuanXu.Util.Filter;

import java.util.Map;

import com.opensymphony.xwork2.ActionContext;

public class HTTPSessionUtil {
	public final static String RANDOM = "random";
	public static Object getObject(String key){
		Map<String, Object> m = getSession();
		return m.get(key);
	}
	private static Map<String, Object> getSession(){
		return (Map<String, Object>)ActionContext.getContext().getSession();
	}
	
	//////////////////////////////////////////////////////////////////
	//
	// admin 模块
	// 需要获取某个单项值用法：HTTPSessionUtil.getObject(HTTPSessionUtil.AdminPower.admin_adminName.getKey());
	//
	/////////////////////////////////////////////////////////////////
	public enum AdminPower {
		admin_adminName("admin_adminName"),
		admin_adminId("admin_adminId"),
		admin_loginTime("admin_loginTime"),
		admin_power("admin_power");
		private String key;
		AdminPower(String key) {
			this.key = key;
		}
		public String getKey() {
			return key;
		}
	}
	
	public static void putAdmin(String adminName,Integer adminId,String loginTime,String power){
		Map<String, Object> m = getSession();
		m.put(AdminPower.admin_adminName.getKey(), adminName);
		m.put(AdminPower.admin_adminId.getKey(), adminId);
		m.put(AdminPower.admin_loginTime.getKey(), loginTime);
		m.put(AdminPower.admin_power.getKey(), power);
	}
	
	public static boolean isAdminLogin(){
		for(AdminPower e :AdminPower.values()){
			if(getObject(e.getKey()) == null){
				return false;
			}
		}
		return true;
	}
	
	public static void exitAdmin(){
		Map<String, Object> m = getSession();
		for(AdminPower e :AdminPower.values()){
			if(getObject(e.getKey()) != null){
				m.remove(e.getKey());
			}
		}
	}
	
	//////////////////////////////////////////////////////////////////
	//
	// WebWorker 模块
	// 需要获取某个单项值用法：HTTPSessionUtil.getObject(HTTPSessionUtil.UserPower.user_adminName.getKey());
	//
	/////////////////////////////////////////////////////////////////
	public enum WebWorkerPower {
		webWorker_adminName("webWorker_adminName"),
		webWorker_adminId("webWorker_adminId"),
		webWorker_loginTime("webWorker_loginTime"),
		webWorker_power("webWorker_power");
		private String key;
		WebWorkerPower(String key) {
			this.key = key;
		}
		public String getKey() {
			return key;
		}
	}
	
	public static void putWebWorker(String adminName,String adminId,String loginTime,String power){
		Map<String, Object> m = getSession();
		m.put(WebWorkerPower.webWorker_adminName.getKey(), adminName);
		m.put(WebWorkerPower.webWorker_adminId.getKey(), adminId);
		m.put(WebWorkerPower.webWorker_loginTime.getKey(), loginTime);
		m.put(WebWorkerPower.webWorker_power.getKey(), power);
	}
	
	public static boolean isWebWorkerLogin(){
		for(WebWorkerPower e :WebWorkerPower.values()){
			if(getObject(e.getKey()) == null){
				return false;
			}
		}
		return true;
	}
	
	public static void exitWebWorker(){
		Map<String, Object> m = getSession();
		for(WebWorkerPower e :WebWorkerPower.values()){
			if(getObject(e.getKey()) != null){
				m.remove(e.getKey());
			}
		}
	}
	
	//////////////////////////////////////////////////////////////////
	//
	// AnalyseUser 模块
	// 需要获取某个单项值用法：HTTPSessionUtil.getObject(HTTPSessionUtil.UserPower.user_adminName.getKey());
	//
	/////////////////////////////////////////////////////////////////
	
	public enum AnalyseUserPower {
		AnalyseUser_adminName("analyseUser_adminName"),
		AnalyseUser_adminId("analyseUser_adminId"),
		AnalyseUser_loginTime("analyseUser_loginTime"),
		AnalyseUser_power("analyseUser_power");
		private String key;
		AnalyseUserPower(String key) {
			this.key = key;
		}
		public String getKey() {
			return key;
		}
	}
	public static void putAnalyseUser(String adminName,String adminId,String loginTime,String power){
		Map<String, Object> m = getSession();
		m.put(AnalyseUserPower.AnalyseUser_adminName.getKey(), adminName);
		m.put(AnalyseUserPower.AnalyseUser_adminId.getKey(), adminId);
		m.put(AnalyseUserPower.AnalyseUser_loginTime.getKey(), loginTime);
		m.put(AnalyseUserPower.AnalyseUser_power.getKey(), power);
	}
	
	public static boolean isAnanlyseUserLogin(){
		for(AnalyseUserPower e :AnalyseUserPower.values()){
			if(getObject(e.getKey()) == null){
				return false;
			}
		}
		return true;
	}
	
	public static void exitAnanlyseUser(){
		Map<String, Object> m = getSession();
		for(AnalyseUserPower e :AnalyseUserPower.values()){
			if(getObject(e.getKey()) != null){
				m.remove(e.getKey());
			}
		}
	}
	//////////////////////////////////////////////////////////////////
	//
	// Dealer 模块
	// 需要获取某个单项值用法：HTTPSessionUtil.getObject(HTTPSessionUtil.UserPower.user_adminName.getKey());
	//
	/////////////////////////////////////////////////////////////////
	public enum DealerPower {
		Dealer_adminId("Dealer_adminId"),
		Dealer_loginTime("Dealer_loginTime"),
		Dealer_power("Dealer_power"),
		Dealer_dealerId("Dealer_dealerId"),
		Dealer_rolename("Dealer_rolename"),
		Dealer_adminName("Dealer_adminName");
		private String key;
		DealerPower(String key) {
			this.key = key;
		}
		public String getKey() {
			return key;
		}
	}
	public static void putDealer(String adminName,String adminId,String loginTime,String power,String dealerId,String rolename){
		Map<String, Object> m = getSession();
		m.put(DealerPower.Dealer_adminName.getKey(), adminName);
		m.put(DealerPower.Dealer_adminId.getKey(), adminId);
		m.put(DealerPower.Dealer_loginTime.getKey(), loginTime);
		m.put(DealerPower.Dealer_power.getKey(), power);
		m.put(DealerPower.Dealer_dealerId.getKey(), dealerId);
		m.put(DealerPower.Dealer_rolename.getKey(), rolename);
		
	}
	
	public static boolean isDealerLogin(){
		for(DealerPower e :DealerPower.values()){
			if(getObject(e.getKey()) == null){
				return false;
			}
		}
		return true;
	}
	
	public static void exitDealer(){
		Map<String, Object> m = getSession();
		for(DealerPower e :DealerPower.values()){
			if(getObject(e.getKey()) != null){
				m.remove(e.getKey());
			}
		}
	}
}
