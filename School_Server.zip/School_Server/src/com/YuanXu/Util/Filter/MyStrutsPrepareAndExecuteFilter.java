package com.YuanXu.Util.Filter;

import java.io.IOException;

import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;

import org.apache.struts2.dispatcher.ng.filter.StrutsPrepareAndExecuteFilter;

public class MyStrutsPrepareAndExecuteFilter extends
		StrutsPrepareAndExecuteFilter {
	String noFilter = null;
	private String[] noFilterPath;
	@Override
	public void destroy() {
		super.destroy();
	}

	@Override
    public void doFilter(ServletRequest arg0, ServletResponse arg1,
            FilterChain arg2) throws IOException, ServletException {
        // TODO Auto-generated method stub
		HttpServletRequest req=(HttpServletRequest)arg0;
        String requestURI = req.getRequestURI();
        if(requestURI == null){
        	
        }else{
			try {
				if (isHad(requestURI)) {
					arg2.doFilter(arg0, arg1);
					System.out.println("不过滤:" + requestURI);
				}else {
					System.out.println("过滤路径：" + requestURI);
					super.doFilter(arg0, arg1, arg2);
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
        }
    }
	
	public boolean isHad(String requestURI){
		for(String str : noFilterPath){
			if(str.length() > 0 && requestURI.contains(str)){
				return true;
			}
		}
		return false;
	}


	@Override
	public void init(FilterConfig arg0) throws ServletException {
		// TODO Auto-generated method stub
		super.init(arg0);
		noFilter = arg0.getInitParameter("noFilter");
		noFilterPath = noFilter.split(";");
	}
	
}
