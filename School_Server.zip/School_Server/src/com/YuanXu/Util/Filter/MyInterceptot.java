package com.YuanXu.Util.Filter;
/*
 * 统一拦截器
 */
import java.util.Map;

import com.YuanXu.Util.Filter.HTTPSessionUtil.AdminPower;
import com.YuanXu.Util.Filter.HTTPSessionUtil.DealerPower;
import com.YuanXu.Util.Filter.HTTPSessionUtil.AnalyseUserPower;
import com.YuanXu.Util.Filter.HTTPSessionUtil.WebWorkerPower;
import com.YuanXu.Util.Parent.MyActionParent;
import com.opensymphony.xwork2.ActionInvocation;
import com.opensymphony.xwork2.interceptor.MethodFilterInterceptor;
@SuppressWarnings("unused")
public class MyInterceptot extends MethodFilterInterceptor {
	private final String returnStr_loginTimeOut_list = "loginTimeOut_list";
	private final String returnStr_loginTimeOut = "loginTimeOut";
	private final String returnStr_noPower = "noPower";
	private final String returnStr_noPower_list = "noPower_list";
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private static final String easyuiMethodName[] = new String[]{"admin_list","admin_save","admin_delete","admin_edit","admin_opreate"};
	@Override
	protected String doIntercept(ActionInvocation arg0) throws Exception {
		// TODO Auto-generated method stub
		System.out.println("In MyInterceptot");
		boolean isLogin = false;
		boolean isPower = false;
		String powerStr = "";
		String nameSpace = arg0.getProxy().getNamespace();
		MyActionParent myActionParent = (MyActionParent) arg0.getAction();
		if(nameSpace.equals("/admin")){
			isLogin = HTTPSessionUtil.isAdminLogin();
			powerStr = (String) HTTPSessionUtil.getObject(AdminPower.admin_power.getKey());
		}else if(nameSpace.equals("/webworker")){
			isLogin = HTTPSessionUtil.isWebWorkerLogin();
			powerStr = (String) HTTPSessionUtil.getObject(WebWorkerPower.webWorker_power.getKey());
		}else if(nameSpace.equals("/dealer")){
			isLogin = HTTPSessionUtil.isDealerLogin();
			powerStr = (String) HTTPSessionUtil.getObject(DealerPower.Dealer_power.getKey());
		}else if(nameSpace.equals("/analyseuser")){
			isLogin = HTTPSessionUtil.isAnanlyseUserLogin();
			powerStr = (String) HTTPSessionUtil.getObject(AnalyseUserPower.AnalyseUser_power.getKey());
		}
		if(!isLogin){//登录超时
			if(isEasyuiMethod(arg0.getProxy().getMethod())){
				return returnStr_loginTimeOut_list;
			}
			return returnStr_loginTimeOut;
		}else{
			//判断是否有权限
			if(!isPowerMethod(arg0.getProxy().getMethod(),powerStr,myActionParent.getPower_m().get(nameSpace))){
				if(isEasyuiMethod(arg0.getProxy().getMethod())){
					return returnStr_noPower_list;
				}
				return returnStr_noPower;
			}
		}
		return arg0.invoke();
	}
	
	protected boolean isEasyuiMethod(String method){
		if(method.contains("_easyui_")){
			return true;
		}
		for(String name : easyuiMethodName){
			if(method.equals(name)){
				return true;
			}
		}
		return false;
	}
	
	protected boolean isPowerMethod(String method,String powerStr,Map<String,String> methodPowerMap){
		if(methodPowerMap == null){
			return true;
		}
		String needPower = methodPowerMap.get(method);
		if(needPower == null || needPower.length() == 0){
			return true;
		}
		String needPower_[] = needPower.split(";");
		for(String p : needPower_){
			if(p == null || p.length() == 0){
				return true;
			}else if(powerStr == null || powerStr.contains(p)){
				return true;
			}
		}
		return false;
	}
}
