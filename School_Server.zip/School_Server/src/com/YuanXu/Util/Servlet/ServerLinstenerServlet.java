package com.YuanXu.Util.Servlet;


import javax.servlet.http.HttpServlet;


/*
 * 服务器启动监听
 */

@SuppressWarnings("serial")
public class ServerLinstenerServlet extends HttpServlet {
	
	public void init() {
		System.out.println("。。。服务器启动。。。");
	}
	public void destroy() {
		System.out.println("。。。服务器暂停。。。");
	}
}
