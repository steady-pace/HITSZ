﻿package com.YuanXu.Util.Util;

import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class StringUtil {
	/*
	 *flag : 分割标志 
	 */
	public static List<String> stringToList(String str,String flag){
		String str_[] = str.split(flag);
		List<String> l = new ArrayList<String>();
		for(String s : str_){
			if(!s.equals("")){
				l.add(s);
			}
		}
		return l;
	}
	
	public static String changeUTF8Bytes(String str) throws UnsupportedEncodingException{
		return new String(str.getBytes("ISO8859-1"),"utf-8");
	}
	
	/*
	 * 随机生成数
	 */
	public static String randomStr(int turns){
		String randomStr = "";
		for(int i = 0; i < turns;i++){
			randomStr = randomStr + nextInt(); 
		}
		return randomStr;
	}
	
	//随机数
	public static Integer nextInt(){
		Random rnd = new Random();
		Integer i =  rnd.nextInt(10);
		if(i <= 0){
			i = nextInt();
		}
		return i;
	}
	
	public static String getMidFilePath(String filePath){
		int index = filePath.indexOf(".");
		String mid = filePath.substring(0, index) + "_mid" + filePath.substring(index, filePath.length());
		return mid;
	}
	
	public static String getSmallFilePath(String filePath){
		int index = filePath.indexOf(".");
		String small = filePath.substring(0, index) + "_small" + filePath.substring(index, filePath.length());
		return small;
	}
}
