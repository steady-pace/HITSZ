package com.YuanXu.Util.Util;

import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;

import com.YuanXu.Util.SendSMS.SendSMS;

public class SendSMSUtil {
	public static boolean sendSMSOne(String msg,String mobile){
		SendSMS ss = new SendSMS();
		ss.setUsername("");
		ss.setPassword(""); //MD5加密后的密文
		ss.setMessage(msg);
		ss.setMobiles(mobile);
		ss.setServicesRequestAddRess("http://sms.c8686.com/Api/BayouSmsApiEx.aspx");
		ss.setSmstype(0);
		ss.setTimerid("0");
		ss.setTimertype(0);
		Map<String, String> map = ss.sendSMS();
		Iterator<Entry<String, String>> it = map.entrySet().iterator();
		while(it.hasNext()){
			System.out.println(it.next());
		}
		if(map.get("errorcode").equals("0")){
			return true;
		}else{
			return false;
		}
	}
}