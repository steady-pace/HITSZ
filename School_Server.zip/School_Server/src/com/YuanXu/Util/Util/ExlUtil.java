package com.YuanXu.Util.Util;

public class ExlUtil {
	private String result;
	private String exlpath;

	public String getResult() {
		return result;
	}

	public void setResult(String result) {
		this.result = result;
	}

	public String getExlpath() {
		return exlpath;
	}

	public void setExlpath(String exlpath) {
		this.exlpath = exlpath;
	}
	
	
}	
