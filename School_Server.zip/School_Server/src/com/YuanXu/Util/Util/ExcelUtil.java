package com.YuanXu.Util.Util;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;



import jxl.Sheet;
import jxl.Workbook;
import jxl.read.biff.BiffException;
import jxl.write.Label;
import jxl.write.WritableSheet;
import jxl.write.WritableWorkbook;
import jxl.write.WriteException;
import jxl.write.biff.RowsExceededException;

public class ExcelUtil {
	
	/**
	 * 读取Excel
	 * @param filePath
	 * @return
	 * @throws BiffException
	 * @throws IOException
	 */
	public static ExcelResult readExcel(String filePath) throws BiffException, IOException {
		Workbook book = Workbook.getWorkbook(new File(filePath));
		Sheet rs = book.getSheet(0);
		ExcelResult result = new ExcelResult();
		int columns = rs.getColumns();
		int rows = rs.getRows();
		result.setColumns(columns);
		result.setRows(rows-1);
		
		List<String> columnsName = new ArrayList<String>();
		for (int i=0; i<columns; i++) {
			columnsName.add(rs.getCell(i, 0).getContents());
		}
		result.setColumnsName(columnsName);
		
		ExcelCell data[][] = new ExcelCell[rows][columns];
		
		for (int i=1; i<rows; i++) {
			for (int j=0; j<columns; j++) {
				ExcelCell cell = new ExcelCell(result);
				cell.setRow(i);
				cell.setColumn(j);
				cell.setDate(rs.getCell(j, i).getContents());
				data[i][j] = cell;
			}
		}
		result.setData(data);
		
		return result;
	}
	
	public static ExcelResult readExcelForFile(File file) throws BiffException, IOException {
		Workbook book = Workbook.getWorkbook(file);
		Sheet rs = book.getSheet(0);
		ExcelResult result = new ExcelResult();
		int columns = rs.getColumns();
		int rows = rs.getRows();
		result.setColumns(columns);
		result.setRows(rows-1);
		
		List<String> columnsName = new ArrayList<String>();
		for (int i=0; i<columns; i++) {
			columnsName.add(rs.getCell(i, 0).getContents());
		}
		result.setColumnsName(columnsName);
		
		ExcelCell data[][] = new ExcelCell[rows][columns];
		
		for (int i=1; i<rows; i++) {
			for (int j=0; j<columns; j++) {
				ExcelCell cell = new ExcelCell(result);
				cell.setRow(i);
				cell.setColumn(j);
				cell.setDate(rs.getCell(j, i).getContents());
				data[i][j] = cell;
			}
		}
		result.setData(data);
		
		return result;
	}
	
	
	public static void writeExcel(String filePath, List<String> columnsName, List<List<String>> data) throws IOException, RowsExceededException, WriteException {
		WritableWorkbook book = Workbook.createWorkbook(new File(filePath));
		WritableSheet ws = book.createSheet("产品信息", 0);
		for (int i=0; i<columnsName.size(); i++) {
			Label label = new Label(i, 0, columnsName.get(i));
			ws.addCell(label);
		}
		for (int i=0; i<data.size(); i++) {
			List<String> row = data.get(i);
			for (int j=0; j<row.size(); j++) {
				Label label = new Label(j, i+1, row.get(j));
				ws.addCell(label);
			}
		}
		book.write();
		book.close();
		
	}
	

}
