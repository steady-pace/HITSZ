package com.YuanXu.Util.Util;

import javax.activation.CommandMap;
import javax.activation.MailcapCommandMap;

import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSenderImpl;

public class JavaEmailSender {
	private Thread thread;
	private SimpleMailMessage smm;
	private JavaMailSenderImpl javaMailSender;
	//发送简单邮件
	public void sendSimpleMailMessage(JavaMailSenderImpl javaMailSender,String toEmail,String title,String context,boolean isThread){
		addMailcap();
		this.javaMailSender = javaMailSender;
		//邮件发送
		smm = new SimpleMailMessage();
		// 设定邮件参数
		smm.setFrom(javaMailSender.getUsername());
		smm.setTo(toEmail);
		smm.setSubject(title);
		smm.setText(context);
		if(isThread){
			sendFromThread();
		}else{
			// 发送邮件
			javaMailSender.send(smm);
			System.out.println("成功发送邮件");
		}
	}
	/*
	 * 
	 * 解决问题：
	 * javax.mail.MessagingException: IOException while sending message;
  	   nested exception is:
			javax.activation.UnsupportedDataTypeException: no object DCH for MIME type multipart/mixed; 
			boundary="----=_Part_6_1156777720.1317260489652"
	 * 
	 */
	public void addMailcap(){
		// add handlers for main mail MIME types MailcapCommandMap mc =
		MailcapCommandMap mc = (MailcapCommandMap)CommandMap.getDefaultCommandMap();
		mc.addMailcap("text/html;; x-java-content-handler=com.sun.mail.handlers.text_html");
		mc.addMailcap("text/xml;; x-java-content-handler=com.sun.mail.handlers.text_xml");
		mc.addMailcap("text/plain;; x-java-content-handler=com.sun.mail.handlers.text_plain");
		mc.addMailcap("multipart/*;; x-java-content-handler=com.sun.mail.handlers.multipart_mixed");
		mc.addMailcap("multipart/mixed;; x-java-content-handler=com.sun.mail.handlers.multipart_mixed");
		CommandMap.setDefaultCommandMap(mc);
	}
	
	public void sendFromThread(){
		thread = new Thread(){
			public void run(){
				// 发送邮件
				javaMailSender.send(smm);
				System.out.println("成功发送邮件");
			}
		};
		thread.start();
	}
}
