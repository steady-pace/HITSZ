package com.YuanXu.Util.Util;

import java.util.ArrayList;
import java.util.Enumeration;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

@SuppressWarnings("unchecked")
public class FengYePage {
	private Integer page;   //当前页数
	private Integer hasPages;  //可分页数
	private Long has; //一共拥有数量
	private Integer pageSize;  //分页大小
	private List<Integer> page_l;   //下拉列表
	private String firtPageUrl;  //第一页超链接
	private String forwardPageUrl;   //上一页超链接
	private String nextPageUrl;  //下一页超链接
	private String endPageUrl;  //最后一页超链接
	private String turnPageUrl;  //跳转超链接，没有page值
	
	public FengYePage(HttpServletRequest request,Integer pageSize,Long has,Integer page)throws Exception{
		this.has = has;
		this.pageSize = pageSize;
		this.page = page;
		//获取页数
		this.hasPages = this.findAllPages();
		//获取列表
		this.page_l = this.getPageList();
		if(page == null || page == 0){
			page = 1;
		}
		if(hasPages == 0){
			this.page = 0;
		}else{
			if(this.page <= 0){
				this.page = 1;
			}else if(this.page > hasPages){
				this.page = hasPages;
			}	
		}
		
		//获取请求Url
		String requestUrl = request.getRequestURI();
		firtPageUrl = requestUrl;
		forwardPageUrl = requestUrl;
		nextPageUrl = requestUrl;
		endPageUrl = requestUrl;
		turnPageUrl = requestUrl;
		//获取请求条件
		Enumeration enumes = request.getParameterNames();
		String sign = "?";
		while(enumes.hasMoreElements()){
			String enmeTjian = (String) enumes.nextElement();
			if(!enmeTjian.equals("page")){  //去除page条件
				String enmeTjiaoValue = new String(request.getParameter(enmeTjian).getBytes("ISO8859-1"),"utf-8");
				this.makeUrl(sign, enmeTjian + "=" + enmeTjiaoValue);
				sign = "&";
			}
		}
		//最后加上page条件
		this.firtPageUrl = this.firtPageUrl + sign + "page=1";
		this.forwardPageUrl = this.forwardPageUrl + sign + "page=" + (page-1);
		this.nextPageUrl = this.nextPageUrl + sign + "page=" + (page+1);
		this.endPageUrl = this.endPageUrl + sign + "page=" + hasPages;
		this.turnPageUrl = this.turnPageUrl + sign + "page=";
		
	}
	
	public void makeUrl(String sign,String enmeTjiao){
		this.firtPageUrl = this.firtPageUrl + sign + enmeTjiao;
		this.forwardPageUrl = this.forwardPageUrl + sign + enmeTjiao;
		this.nextPageUrl = this.nextPageUrl + sign + enmeTjiao;
		this.endPageUrl = this.endPageUrl + sign + enmeTjiao;
		this.turnPageUrl = this.turnPageUrl + sign + enmeTjiao;
	}
	
	public List<Integer> getPageList(){
		List<Integer> page_l = new ArrayList<Integer>();
		if(hasPages != null && hasPages >0){
			for(int i= 1;i <= hasPages;i++){
				page_l.add(i);
			}
		}
		return page_l;
	}
	public Integer findAllPages(){
		int num = has.intValue();
		Integer hasPages = num/pageSize;
		num = num%pageSize;
		if(num>0){
			hasPages++;
		}
		return hasPages;
	}
	
	public Integer getPage() {
		return page;
	}
	public void setPage(Integer page) {
		this.page = page;
	}
	public Integer getHasPages() {
		return hasPages;
	}
	public void setHasPages(Integer hasPages) {
		this.hasPages = hasPages;
	}
	public Long getHas() {
		return has;
	}
	public void setHas(Long has) {
		this.has = has;
	}
	public Integer getPageSize() {
		return pageSize;
	}
	public void setPageSize(Integer pageSize) {
		this.pageSize = pageSize;
	}

	public List<Integer> getPage_l() {
		return page_l;
	}

	public void setPage_l(List<Integer> pageL) {
		page_l = pageL;
	}


	public String getFirtPageUrl() {
		return firtPageUrl;
	}


	public void setFirtPageUrl(String firtPageUrl) {
		this.firtPageUrl = firtPageUrl;
	}


	public String getForwardPageUrl() {
		return forwardPageUrl;
	}


	public void setForwardPageUrl(String forwardPageUrl) {
		this.forwardPageUrl = forwardPageUrl;
	}


	public String getNextPageUrl() {
		return nextPageUrl;
	}


	public void setNextPageUrl(String nextPageUrl) {
		this.nextPageUrl = nextPageUrl;
	}


	public String getEndPageUrl() {
		return endPageUrl;
	}


	public void setEndPageUrl(String endPageUrl) {
		this.endPageUrl = endPageUrl;
	}

	public String getTurnPageUrl() {
		return turnPageUrl;
	}

	public void setTurnPageUrl(String turnPageUrl) {
		this.turnPageUrl = turnPageUrl;
	}
	
}
