package com.YuanXu.Util.Util;


/*
 * 配置信息
 * 
 */
public class MyHibernateConfigs {
	//配置文件xml中获取
	private static void initString(){
		XmlRead.readPropertyXml("WEB-INF/classes/hibernate.cfg.xml");
	}
	
	public static String getValue(String key){
		if(XmlRead.xmlValue_map == null || XmlRead.xmlValue_map.size() == 0){
			initString();
		}
		return XmlRead.xmlValue_map.get(key);
	}
}
