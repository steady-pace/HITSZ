package com.YuanXu.Util.Util;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import com.aliyun.openservices.ClientException;
import com.aliyun.openservices.oss.OSSClient;
import com.aliyun.openservices.oss.OSSException;
import com.aliyun.openservices.oss.model.CannedAccessControlList;
import com.aliyun.openservices.oss.model.CompleteMultipartUploadRequest;
import com.aliyun.openservices.oss.model.CompleteMultipartUploadResult;
import com.aliyun.openservices.oss.model.CopyObjectResult;
import com.aliyun.openservices.oss.model.GetObjectRequest;
import com.aliyun.openservices.oss.model.InitiateMultipartUploadRequest;
import com.aliyun.openservices.oss.model.InitiateMultipartUploadResult;
import com.aliyun.openservices.oss.model.OSSObject;
import com.aliyun.openservices.oss.model.ObjectMetadata;
import com.aliyun.openservices.oss.model.PartETag;
import com.aliyun.openservices.oss.model.PutObjectResult;
import com.aliyun.openservices.oss.model.UploadPartRequest;
import com.aliyun.openservices.oss.model.UploadPartResult;
@SuppressWarnings("unused")
public class OssUtil {
	private String accessKeyId = "xxx";
	private String accessKeySecret = "xxx";
	private String endpoint = "http://oss-cn-shenzhen.aliyuncs.com";
	OSSClient client = new OSSClient(endpoint, accessKeyId, accessKeySecret);
	public static void main(String[] args) throws Exception {
		OssUtil util = new OssUtil();
		//util.upLoad("superyi", "dd.txt", "e://33.txt");
		//util.Down("superyi", "66.txt", "e://dd.txt");
		//util.deleteFile("superyi", "22.txt");
		//util.copyFile("superyi", "66.txt", "superyi", "99.txt");
		//util.fenLoad("superyi", "22.txt", "e://33.txt");
		String [] st = new String[]{"superyi","superyi"};
		String [] st1 = new String[]{"123.txt","456.txt"};
		//String [] st2 = new String[]{"e://44.txt","e://55.txt"};
		util.pLDeleteFile(st, st1);
	}
	
	/**
	 * �����ϴ�
	 * @param bucketName
	 * @param key
	 * @param fileName
	 */
	public void pLUpLoad(String[] bucketName,String[] key,String[] fileName){
		if(fileName.length>0){
			for(int i=0;i<fileName.length;i++){
				boolean flag = client.doesBucketExist(bucketName[i]);
				if(!flag){
					client.createBucket(bucketName[i]);
					//Ĭ�������з���
					client.setBucketAcl(bucketName[i], CannedAccessControlList.PublicReadWrite);
				}
				File file =new File(fileName[i]);
				InputStream content = null;
				try {
					content = new FileInputStream(file);
				} catch (FileNotFoundException e) {
					e.printStackTrace();
				}
				ObjectMetadata meta = new ObjectMetadata();
				meta.setContentLength(file.length());
				//�ϴ�
				PutObjectResult result = client.putObject(bucketName[i], key[i], content, meta);
			}
		}
	}
	
	/**
	 * �ϴ��ļ�
	 * @param bucketName
	 * @param key
	 */
	public void upLoad(String bucketName,String key,String fileName){
		//�ж�bucket�Ƿ����
		boolean flag = client.doesBucketExist(bucketName);
		if(!flag){
			client.createBucket(bucketName);
			//Ĭ�������з���
			client.setBucketAcl(bucketName, CannedAccessControlList.PublicReadWrite);
		}
		File file =new File(fileName);
		InputStream content = null;
		try {
			content = new FileInputStream(file);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		ObjectMetadata meta = new ObjectMetadata();
		meta.setContentLength(file.length());
		//�ϴ�
		PutObjectResult result = client.putObject(bucketName, key, content, meta);
		System.out.println(result.getETag());
	}
	
	/**
	 * ��Ƭ�ϴ��ļ�
	 * @throws Exception 
	 */
	public void fenLoad(String bucketName,String key,String filePath) throws Exception{
		InitiateMultipartUploadRequest initUpload = new InitiateMultipartUploadRequest(bucketName, key);
		InitiateMultipartUploadResult result = client.initiateMultipartUpload(initUpload);
		System.out.println(result.getUploadId());
		//�ֿ��ļ��ϴ�������
		final int size = 20; //��λΪ�ֽ�
		File file = new File(filePath);
		int count = (int)(file.length()/size);
		if(file.length()%size!=0){
			count++;
		}
		List<PartETag> parts = new ArrayList<PartETag>();
		for(int i = 0; i < count; i++){
		    // ��ȡ�ļ���
		    FileInputStream fis = new FileInputStream(file);

		    // ��ÿ���ֿ�Ŀ�ͷ
		    long skipBytes = size * i;
		    fis.skip(skipBytes);

		    // ����ÿ���ֿ�Ĵ�С
		    long size1 = size < file.length() - skipBytes ?
		            size : file.length() - skipBytes;

		    // ����UploadPartRequest���ϴ��ֿ�
		    UploadPartRequest uploadPartRequest = new UploadPartRequest();
		    uploadPartRequest.setBucketName(bucketName);
		    uploadPartRequest.setKey(key);
		    uploadPartRequest.setUploadId(result.getUploadId());
		    uploadPartRequest.setInputStream(fis);
		    uploadPartRequest.setPartSize(size1);
		    uploadPartRequest.setPartNumber(i + 1);
		    UploadPartResult uploadPartResult = client.uploadPart(uploadPartRequest);

		    // �����ص�PartETag���浽List�С�
		    parts.add(uploadPartResult.getPartETag());

		    // �ر��ļ�
		    fis.close();
		}
		//��ɷֿ��ϴ�
		CompleteMultipartUploadRequest request = new CompleteMultipartUploadRequest(bucketName, key, result.getUploadId(), parts);
		CompleteMultipartUploadResult rl = client.completeMultipartUpload(request);
		System.out.println(rl.getETag());
	}
	
	/**
	 * ��������
	 * @param bucketName
	 * @param key
	 * @param fileName
	 */
	public void pLDown(String[] bucketName,String[] key,String[] fileName){
		if(fileName.length>0){
			for(int i=0;i<fileName.length;i++){
				GetObjectRequest request = new GetObjectRequest(bucketName[i],key[i]);
				try {
					OSSObject object = client.getObject(request);
				} catch (OSSException e) {
					System.out.print("�ļ�������,����ʧ��");
					return;
				} catch (ClientException e) {
					System.out.println(e);
				}
				ObjectMetadata meta = client.getObject(request, new File(fileName[i]) );
			}
		}
	}
	
	
	/**
	 * ���ص�����
	 * @param bucketName
	 * @param key
	 * @param flieName
	 */
	public void Down(String bucketName,String key,String flieName){
		GetObjectRequest request = new GetObjectRequest(bucketName, key);
		//��ȡ�ļ���0-3֮����ֽ�
		request.setRange(0, 3);
		ObjectMetadata meta = client.getObject(request,new File(flieName));
		meta.getLastModified();
		OSSObject object = client.getObject(request);
		System.out.println(object.getKey());
	}
	
	/**
	 * ����ɾ��
	 * @param bucketName
	 * @param key
	 */
	public void pLDeleteFile(String[] bucketName,String[] key){
		if(key.length>0){
			for(int i=0;i<key.length;i++){
				GetObjectRequest request = new GetObjectRequest(bucketName[i],key[i]);
				try {
					OSSObject object = client.getObject(request);
					client.deleteObject(bucketName[i], key[i]);
				} catch (OSSException e) {
					System.out.print("�ļ�������,ɾ��ʧ��");
				} catch (ClientException e) {
					System.out.println(e);
				}
			}
		}
	}
	
	/**
	 * ɾ���ļ�
	 */
	public void deleteFile(String bucketName,String key){
		GetObjectRequest request = new GetObjectRequest(bucketName,key);
		try {
			OSSObject object = client.getObject(request);
			client.deleteObject(bucketName, key);
		} catch (OSSException e) {
			System.out.print("�ļ�������,ɾ��ʧ��");
		} catch (ClientException e) {
			System.out.println(e);
		}
			
		
	}
	
	/**
	 * ���������ļ�
	 * @param srcBucket
	 * @param srcKey
	 * @param destBucket
	 * @param destKey
	 */
	public void pLCopyFile(String[] srcBucket,String[] srcKey,String[] destBucket,String[] destKey){
		if(srcKey.length>0){
			for(int i=0;i<srcKey.length;i++){
				GetObjectRequest request = new GetObjectRequest(srcBucket[i],srcKey[i]);
				try {
				
					OSSObject object = client.getObject(request);
				} catch (OSSException e) {
					System.out.print("�ļ�������,����ʧ��");
					return;
				} catch (ClientException e) {
					System.out.println(e);
					return;
				}
				CopyObjectResult result = client.copyObject(srcBucket[i], srcKey[i], destBucket[i], destKey[i]);
			}
		
		}
	}
	
	/**
	 * �����ļ�
	 */
	public void copyFile(String srcBucket,String srcKey,String destBucket,String destKey){
		CopyObjectResult result = client.copyObject(srcBucket, srcKey, destBucket, destKey);
		SimpleDateFormat sf = new SimpleDateFormat("yyyy-MM-dd");
		String st=sf.format(result.getLastModified());
		System.out.println(result.getETag()+"-->"+st);
	}
}
