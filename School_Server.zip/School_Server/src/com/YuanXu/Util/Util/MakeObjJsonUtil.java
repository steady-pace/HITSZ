package com.YuanXu.Util.Util;

import java.util.List;
import java.util.Map;

import com.YuanXu.Util.Parent.MyVoParent;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

public class MakeObjJsonUtil {
	public static String makeResultJsonToString(MyVoParent voJsonResult){
		JSONObject jsonObject = JSONObject.fromObject(voJsonResult);
		return jsonObject.toString();
	}
	
	
	public static String makListJsonToString(List<?> voObj){
		JSONArray  jsonObject = JSONArray.fromObject(voObj); 
		return jsonObject.toString();
	}
	
	
	/** 
	 *  使用方法
     *  Map<String, Class<?>> m = new HashMap<String,  Class<?>>();
		m.put("log", VoJsonStoreDolog.class);
		voMsgStoreDoLog = (VoMsgStoreDoLog) MakeObjJsonUtil.jsonStrToObject(json, VoMsgStoreDoLog.class,m);
     * @param jsonStr 
     * @param c 
     * @return 
     * @throws Exception 
     */  
    public static Object jsonStrToObject(String jsonStr,Class<?> c,Map<String, Class<?>> m) throws Exception{  
        Object obj = null;  
        try{
        	obj = JSONObject.toBean(JSONObject.fromObject(jsonStr), c,m);
        }catch(Exception e){  
            e.printStackTrace();  
        }  
        return obj;   
    }  
}
