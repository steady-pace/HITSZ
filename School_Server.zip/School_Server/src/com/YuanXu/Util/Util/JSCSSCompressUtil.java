package com.YuanXu.Util.Util;

import java.io.File;  
import java.io.FileInputStream;  
import java.io.FileOutputStream;  
import java.io.InputStreamReader;  
import java.io.OutputStreamWriter;  
import java.io.Reader;  
import java.io.Writer;  
import java.util.ArrayList;
import java.util.List;
  
import org.mozilla.javascript.ErrorReporter;  
import org.mozilla.javascript.EvaluatorException;  
  
import com.yahoo.platform.yui.compressor.CssCompressor;  
import com.yahoo.platform.yui.compressor.JavaScriptCompressor;  
  
/**
 * JS与CSS压缩工具类
 * @author Administrator
 *
 */
public class JSCSSCompressUtil {

        static int linebreakpos = -1;  
        static boolean munge=true;  
        static boolean verbose=false;  
        static boolean preserveAllSemiColons=false;  
        static boolean disableOptimizations=false;
        public static boolean error = true;// 是否打印错误信息
        public static int fail = 0;// 记录失败的数量
        public static int success = 0;// 记录成功的数量
        public static List<String> failFileName = new ArrayList<String>();// 记录失败的文件集合
        // 传入一个目录路径，然后开始对目录下的JS与CSS进行压缩
        public static void startCompress(File file) throws Exception{  
            File[] files=file.listFiles();  
            if(files==null||files.length==0)  
                return;
              
            for(File f:files){  
                if(f.getName().endsWith(".svn")){
                    continue;  
                }  
                if(f.isFile()){  
                    jsCSSZip(f);  
                    continue;  
                }else{  
                    System.out.println("开始压缩"+f.getName()+"目录下的JS和CSS!");  
                    startCompress(f);
                }  
            }
        }
        // 对传入的js进行压缩，输出到原来的目录
        public static void jsCSSZip(File file) throws Exception{  
            String fileName=file.getName();  
            if(!fileName.endsWith(".js")&&!fileName.endsWith(".css")){  
                return;
            }  
            Reader in = new InputStreamReader(new FileInputStream(file),"utf-8");  
            String filePath=file.getAbsolutePath();  
            File tempFile=new File(filePath+".tempFile");  
            Writer out = new OutputStreamWriter(new FileOutputStream(tempFile),"utf-8");  
            if(fileName.endsWith(".js")){
            	
            	try{
            		JavaScriptCompressor jscompressor = null;
            		if(error){
            			jscompressor=new JavaScriptCompressor(in, new ErrorReporter() {  
    	                	
    	                    public void warning(String message, String sourceName,  
    	                            int line, String lineSource, int lineOffset) {  
    	                        if (line < 0) {  
    	                            System.err.println("\n[WARNING] " + message);  
    	                        } else {  
    	                            System.err.println("\n[WARNING] " + line + ':' + lineOffset + ':' + message);  
    	                        }  
    	                    }  
    	  
    	                    public void error(String message, String sourceName,  
    	                            int line, String lineSource, int lineOffset) {  
    	                        if (line < 0) {  
    	                            System.err.println("\n[ERROR] " + message);  
    	                        } else {  
    	                            System.err.println("\n[ERROR] " + line + ':' + lineOffset + ':' + message);  
    	                        }  
    	                    }  
    	  
    	                    public EvaluatorException runtimeError(String message, String sourceName,  
    	                            int line, String lineSource, int lineOffset) {  
    	                        error(message, sourceName, line, lineSource, lineOffset);  
    	                        return new EvaluatorException(message);  
    	                    }
    	                    
    	                });
            		}else{
            			jscompressor=new JavaScriptCompressor(in, new ErrorReporter() {  
    	                	
    	                    public void warning(String message, String sourceName,  
    	                            int line, String lineSource, int lineOffset) {  
    	                    }  
    	  
    	                    public void error(String message, String sourceName,  
    	                            int line, String lineSource, int lineOffset) {  
    	                    }  
    	  
    	                    public EvaluatorException runtimeError(String message, String sourceName,  
    	                            int line, String lineSource, int lineOffset) {  
    	                        error(message, sourceName, line, lineSource, lineOffset);  
    	                        return new EvaluatorException(message);  
    	                    }
    	                    
    	                });
            		}
	                
            		
	                jscompressor.compress(out, linebreakpos, munge, verbose, preserveAllSemiColons, disableOptimizations);
	                success++;
	                out.close();  
                    in.close();  
                    file.delete();  
                    tempFile.renameTo(file);  
                    tempFile.delete();// 如果成功删除原文件与临时文件
                    System.out.println("成功压缩文件--"+fileName); 
            	}catch (Exception e) {
					// TODO: handle exception
            		fail++;
            		failFileName.add(fileName);
            		out.close();  
                    in.close();
					tempFile.renameTo(file);  
                    tempFile.delete();// 失败删除创建的临时文件，压缩失败不做任何操作
				}
            }else if(fileName.endsWith(".css")){
            	try {
            		CssCompressor csscompressor = new CssCompressor(in);  
                    csscompressor.compress(out, linebreakpos);
                    success++;
                    out.close();  
                    in.close();  
                    file.delete();  
                    tempFile.renameTo(file);  
                    tempFile.delete();// 如果成功删除原文件与临时文件
                    System.out.println("成功压缩文件--"+fileName); 
				} catch (Exception e) {
					// TODO: handle exception
					fail++;
					failFileName.add(fileName);
					out.close();  
                    in.close();
					tempFile.renameTo(file);  
                    tempFile.delete();// 失败删除创建的临时文件，压缩失败不做任何操作
				}
            }  
        }  
}
