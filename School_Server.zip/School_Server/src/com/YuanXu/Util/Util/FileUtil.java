﻿package com.YuanXu.Util.Util;

import java.awt.image.BufferedImage;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.imageio.ImageIO;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.io.FileUtils;
import org.apache.struts2.ServletActionContext;

import com.YuanXu.Util.CompressPic.CompressPicDemo;
@SuppressWarnings({ "unchecked", "deprecation" })
public class FileUtil {
	private static String root = null;
	private static String showroot = null;
	public static String serverRoot = null;
	/*
	 * 存储File的相对路径
	 */
	public static String getRoot() {
		if(root == null){
			root = "../" + MyAppConfigs.getValue("fileRoot");
		}
		return root;
	}
	/*
	 * 网站的绝对路径
	 */
	public static String getServerRoot() {
		if(serverRoot == null){
			serverRoot = ServletActionContext.getServletContext().getRealPath("/");
		}
		return serverRoot;
	}
	/**
	 * 获取服务器路径
	 * @return
	 */
	public static String getWebServerRoot() {
		HttpServletRequest request = ServletActionContext.getRequest();
		String path = request.getContextPath();
		String basePath = request.getScheme() + "://" + request.getServerName()
				+ ":" + request.getServerPort() + path + "/";
		return basePath;
	}
	
	public static String getAndriodUrl(){
		HttpServletRequest request = ServletActionContext.getRequest();
		String path = request.getContextPath() + "/" + FileUtil.getRoot()+"/uploadImg/image/";
		return path;
	}
	
	public static String getShowroot() {
		return showroot;
	}
	public static String getRootPath(String path){
		return ServletActionContext.getRequest().getRealPath(path);
	}
	public static String getRootPath(){
		return ServletActionContext.getRequest().getRealPath("");
	}
	
	public static String getShowRootPath(){
		if(showroot == null){
			String path = ServletActionContext.getRequest().getContextPath();
			if(path.length() == 0){
				showroot = MyAppConfigs.getValue("fileRoot");
			}else{
				showroot = root;
			}
		}
		return showroot;
	}
	
	//获取加密文本
	public static String getKeyPairFilePath(){
		return ServletActionContext.getRequest().getRealPath("WEB-INF/classes/RSAKey");
	}
	
	//获取上传图片缓冲位置
	public static String getUploadFilePath(){
		return ServletActionContext.getRequest().getRealPath("/uploads");
	}
	
	/**
	 * @file:文件域列表
	 * @fileName:上传文件的文件名
	 * @path:文件上传的目录，相对目录。
	 * 说明：文件上传所存放目录的规则：网站根目录下 files/会员ID/网站类型名称/上传文件分类名称/
	 * @返回结果：一个存放上传文件所在位置相对路径的ArrayList
	 * */
	public static void uploadPhotos(List file, String path,
			String Rname,String type) {
		File dir = new File(path);
		if (dir.exists() == false) {
			dir.mkdirs();
		}
		Map<String,File> file_l = new HashMap<String,File>();
		Map<String,InputStream> is_l = new HashMap<String,InputStream>();
		InputStream is;
		try {
			for (int i = 0,j = file.size(); i < j; ++i) {
				is = new FileInputStream(file.get(i).toString());
				String name = "";
				if(j == 1){
					name = Rname + type;// 重命名文件名称
				}else{
					name = Rname + j + type;// 重命名文件名称
				}
				File destFile = new File(path, name);
				file_l.put(name, destFile);
				is_l.put(name, is);
			}
			Set<String> names = file_l.keySet();
			for(String name : names){
				is = is_l.get(name);
				OutputStream os = new FileOutputStream(file_l.get(name));
				byte[] buffer = new byte[400];
				int length = 0;
				while ((length = is.read(buffer)) > 0) {
					os.write(buffer, 0, length);
				}
				is.close();
				os.close();
			}
		}catch(Exception e){
			System.out.println("上传图片失败");
			e.printStackTrace();
		}
	}
	
	public static void uploadPhotos(List file, String path,
			String Rname) {
		File dir = new File(path);
		if (dir.exists() == false) {
			dir.mkdirs();
		}
		Map<String,File> file_l = new HashMap<String,File>();
		Map<String,InputStream> is_l = new HashMap<String,InputStream>();
		InputStream is;
		try {
			for (int i = 0,j = file.size(); i < j; ++i) {
				is = new FileInputStream(file.get(i).toString());
				String name = Rname;
				File destFile = new File(path, name);
				file_l.put(name, destFile);
				is_l.put(name, is);
			}
			Set<String> names = file_l.keySet();
			for(String name : names){
				is = is_l.get(name);
				OutputStream os = new FileOutputStream(file_l.get(name));
				byte[] buffer = new byte[400];
				int length = 0;
				while ((length = is.read(buffer)) > 0) {
					os.write(buffer, 0, length);
				}
				is.close();
				os.close();
			}
		}catch(Exception e){
			System.out.println("上传图片失败");
			e.printStackTrace();
		}
	}
	
	public static boolean uploadPhotos(File file, String path,
			String Rname) {
		File dir = new File(path);
		if (dir.exists() == false) {
			dir.mkdirs();
		}
		InputStream is;
		try {
			is = new FileInputStream(file.toString());
			String name = Rname;
			File destFile = new File(path, name);
			OutputStream os = new FileOutputStream(destFile);
			byte[] buffer = new byte[400];
			int length = 0;
			while ((length = is.read(buffer)) > 0) {
				os.write(buffer, 0, length);
			}
			is.close();
			os.close();
			return true;
		}catch(Exception e){
			System.out.println("上传图片失败");
			e.printStackTrace();
			return false;
		}
	}
	/*
	 * @param 
	 * 文件路径path 需要 绝对路径，例如："E:\\javapro\\files\\"
	 */
	public static Integer[] makeSmallImg(File file,String savePath,String saveFileName, int nowWidth, int nowHeight,int newWidth){
		int newHeight = newWidth * nowHeight / nowWidth;  //压缩后的图片高度
		CompressPicDemo cPicDemo = new CompressPicDemo();
		if(cPicDemo.compressPic(file, savePath, saveFileName, newWidth, newHeight, true,false)){
			return null;
		}
		return new Integer[]{newWidth,newHeight};
	}
	
	public static boolean deleKindeditorFile(String filePath){
		try{
			File file = new File(getRootPath(".." + filePath));
			if(file.isFile()){
				file.delete();
			}
		}catch (Exception e) {
			// TODO: handle exception
			return false;
		}
		return true;
	}
	
	/*
     * 替换
     * infoB :全文
     * beforeStr：需要替换的位置
     * afterStr：代替的字符
     */
    public static StringBuilder changeInfo(StringBuilder infoB,String beforeStr,String afterStr){
    	int index = infoB.indexOf(beforeStr);
    	if(index != -1){
    		infoB.replace(index, index + beforeStr.length(), afterStr);
    		infoB = changeInfo(infoB,beforeStr,afterStr);
    	}
    	return infoB;
    }
    
    public static StringBuilder readFile(String filePath) {
		File f = new File(filePath); // create file object
		BufferedReader br = null; // create buffer reader that has a method
									// named readLine()
		String content = "";
		String line = "";
		try {
			br = new BufferedReader(new FileReader(f));
			while ((line = br.readLine()) != null) {
				content += (line + "\n");
			}
			br.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return new StringBuilder(content);
	}
    
    public static boolean writeFile(String content, String filePath,String filename) {
		File file = new File(filePath);
		try {
			if (file.exists() == false) {
				file.mkdirs();
			}
			file = new File(filePath + "\\" + filename);
			FileOutputStream fos=new FileOutputStream(file); 
			OutputStreamWriter osw=new OutputStreamWriter(fos,"utf-8");   //一定要转码
			BufferedWriter bw=new BufferedWriter(osw); 
			bw.write(content); 
			bw.close(); 
			return true;
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return false;
		}
	}
	
    public static void writeFile(StringBuilder content, String filePath,String filename) {
		File file = new File(filePath);
		String con = content.toString();
		con = con.substring(2, con.length());  //去掉头部开始的乱码
		con = "<" + con;
		try {
			if (file.exists() == false) {
				file.mkdirs();
			}
			file = new File(filePath + "\\" + filename);
			FileOutputStream fos=new FileOutputStream(file); 
			OutputStreamWriter osw=new OutputStreamWriter(fos,"utf-8");   //一定要转码
			BufferedWriter bw=new BufferedWriter(osw); 
			bw.write(con); 
			bw.close(); 
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
    
    public static List<String> cuttingString(String content,String cutStr,String startStr,String endStr){
    	List<String> str_l = new ArrayList<String>();
    	String[] str01 = content.split(cutStr);
    	for(String str : str01){
    		int i = str.indexOf(startStr);
    		int j = str.indexOf(endStr);
    		if(i !=-1 && j != -1){
    			String s = str.subSequence(i, j).toString();
        		str_l.add(s);
    		}
    	}
    	return str_l;
    }
    
    public static boolean dele(String path, String filename) {
		String root = path + filename;
		File dir = new File(root);
		if (dir.exists() == false) {
			return true;
		} else {
			dir.delete();
			return true;
		}
	}
    
    public static boolean isExists(String path, String filename) {
		String root = path + filename;
		File dir = new File(root);
		if (dir.exists() == false) {
			return true;
		} else {
			return true;
		}
	}
    
    // 递归
    public static long getFileSize(File f)//取得文件夹大小
    {
        long size = 0;
        FileInputStream fis = null;
        try{
	        if(f.isDirectory()){
		        File flist[] = f.listFiles();
		        for (int i = 0; i < flist.length; i++)
		        {
		            if (flist[i].isDirectory())
		            {
		                size = size + getFileSize(flist[i]);
		            } else
		            {
		            	fis = new FileInputStream(flist[i]); 
		                size = size + fis.available(); 
		            }
		        }
	        }else{
	        	fis = new FileInputStream(f); 
	        	size = size + fis.available(); 
	        }
        }catch (Exception e) {
			// TODO: handle exception
        	e.printStackTrace();
		}
        return size;
    }
    
    
    /*
	 * 文件大小
	 * 输出大小 
	 * 单位 "KB"
	 *  
	 */
	public static float getFileInfoSize_float(long fileSize)
	{
		java.text.DecimalFormat df = new   java.text.DecimalFormat("#0");  

		float result = (float) (fileSize / (1024 * 1.0));
		System.out.println(df.format(result));
		result = Float.parseFloat(df.format(result));
		return result;
	}
	
	/*
	 * 单位“KB”
	 */
	public static boolean isAllowSizeKB(File file,int min,int max){
		int size = (int) getFileInfoSize_float(getFileSize(file));
		if(size < min || size > max){
			return false;
		}
		return true;
	}
	
	/*
	 * 判断像素大小
	 */
	public static boolean isAllowWHSize(File file,double widht,double height){
		try{
			BufferedImage   image   =   ImageIO.read(new FileInputStream(file)); 
			double   imageWidth   =   image.getWidth(); 
			double   imageHeight   =   image.getHeight(); 
			if(imageWidth != widht){
				return false;
			}
			if(imageHeight != height){
				return false;
			}
		}catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			return false;
		}
		return true;
	}
	
	/*
	 * 判断类型
	 */
	public static boolean isAllowType(String fileName,String type){
		try{
			if(fileName.contains("."+type)){
				return true;
			}else{
				return false;
			}
		}catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			return false;
		}
	}
	
	public static Integer[] getImgSize(File file){
		BufferedImage image;
		try {
			image = ImageIO.read(file);
			Integer imageWidth   =   image.getWidth(); 
			Integer imageHeight   =   image.getHeight();
			return new Integer[]{imageWidth,imageHeight};
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		} 
	}
	
	
	
	/*
	 * 替换字符串
	 */
	public static String replaceStr(String old_str,String replaceStr,String replaceNewStr){
		int index = old_str.indexOf(replaceStr);
		if(index >= 0){
			int r_length = replaceStr.length();
			int old_length = old_str.length();
			old_str = old_str.substring(0, index) + replaceNewStr + old_str.substring(index + r_length, old_length);
		}
		return old_str;
	}
	
	/**
	 * 删除文件夹里面的所有文件
	 * @param path String 文件夹路径 如 c:/fqf
	 */
	public static void delAllFile(String path) {
		File file = new File(path);
		if (!file.exists()) {
			return;
		}
		if (!file.isDirectory()) {
			return;
		}
		String[] tempList = file.list();
		File temp = null;
		for (int i = 0; i < tempList.length; i++) {
			if (path.endsWith(File.separator)) {
				temp = new File(path + tempList[i]);
			} else {
				temp = new File(path + File.separator + tempList[i]);
			}
			if (temp.isFile()) {
				temp.delete();
			}
			if (temp.isDirectory()) {
				delAllFile(path + "/" + tempList[i]);// 先删除文件夹里面的文件
				delFolder(path + "/" + tempList[i]);// 再删除空文件夹
			}
		}
	}
	/**
	 * 删除文件夹
	 * 
	 * @param filePathAndName
	 *            String 文件夹路径及名称 如c:/fqf
	 * @param fileContent
	 *            String
	 * @return boolean
	 */
	
	public static boolean delFolder(String folderPath) {
		try {
			delAllFile(folderPath); // 删除完里面所有内容
			String filePath = folderPath;
			filePath = filePath.toString();
			java.io.File myFilePath = new java.io.File(filePath);
			myFilePath.delete(); // 删除空文件夹
			return true;
		} catch (Exception e) {
			System.out.println("删除文件夹操作出错");
			e.printStackTrace();
			return false;
		}
	}
	/*
	 * 获取压缩版上传图片的中等大小图片
	 */
	public static String getMidName(String filePath){
		String mid_name = "";
		//检查扩展名
		String fileExt = filePath.substring(filePath.lastIndexOf(".") + 1).toLowerCase();
		String name = filePath.substring(0,filePath.lastIndexOf(".")).toLowerCase();
		mid_name = name + "_mid." + fileExt;
		return mid_name;
	}
	/*
	 * 获取压缩版上传图片的最小大小图片
	 */
	public static String getSmallName(String filePath){
		String small_name = "";
		//检查扩展名
		String fileExt = filePath.substring(filePath.lastIndexOf(".") + 1).toLowerCase();
		String name = filePath.substring(0,filePath.lastIndexOf(".")).toLowerCase();
		small_name = name + "_small." + fileExt;
		return small_name;
	}
	
	
	//复制单个图片的方法
	public static String copyFile(String oldPath, String newPath, String oldNameStr)
			throws IOException {
		File folder = new File(newPath);
		if (!folder.exists()) {
			folder.mkdirs();
		}
		String newName = oldNameStr;
		File oldfile = new File(oldPath + oldNameStr);
		if(FileUtil.isExists(newPath , oldNameStr)){
			//存在该文件名的文件了，加（时间）
			int index_ = oldNameStr.indexOf(".");
			newName = oldNameStr.substring(0, index_-1) + "("+new Date().getTime()+")" + oldNameStr.substring(index_,oldNameStr.length());
		}
		File newfile = new File(newPath + newName);
		FileUtils.copyFile(oldfile, newfile);
		return newName;
	}
	
	public static String copyFileByNewName(String oldPath, String newPath, String oldNameStr,String newFileName)
			throws IOException {
		File folder = new File(newPath);
		if (!folder.exists()) {
			folder.mkdirs();
		}
		String newName = oldNameStr;
		File oldfile = new File(oldPath + oldNameStr);
		if(FileUtil.isExists(newPath , oldNameStr)){
			newName = newFileName;
		}
		File newfile = new File(newPath + newName);
		FileUtils.copyFile(oldfile, newfile);
		return newName;
	}
	
	//复制单个图片的方法
	public static boolean copyFile(String oldPath, String newPath, String oldNameStr, String newNameStr){
		File folder = new File(newPath);
		if (!folder.exists()) {
			folder.mkdirs();
		}
		File oldfile = new File(oldPath + oldNameStr);
		File newfile = new File(newPath + newNameStr);
		try {
			FileUtils.copyFile(oldfile, newfile);
			return true;
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return false;
		}
	}
	
	//复制多个文件的方法
	public static void copyFiles(String oldPath, String newPath,
			String[] oldName) throws IOException {
		// try {
		String newPathFolder = newPath.substring(0, newPath.lastIndexOf("/"));
		File folder = new File(newPathFolder);
		if (!folder.exists()) {
			folder.mkdirs();
		}
		for (String oldNameStr : oldName) {
			File oldfile = new File(oldPath + oldNameStr);
			File newfile = new File(newPath + oldNameStr);
			FileUtils.copyFile(oldfile, newfile);
		}
	}
}
