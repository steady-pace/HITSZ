package com.YuanXu.Util.Util;

import java.text.DecimalFormat;

public class MyFloatUtil {
	public static float roundedFloatToInt(float value){
		return Float.parseFloat(new DecimalFormat("#").format(value));
	}
	public static double roundedDoubleToInt(double test2){
		return Double.parseDouble(new DecimalFormat("###").format(test2));
	}
	//保留一位小数
	public static double roundedDoubleToOne(double test2){
		return Double.parseDouble(new DecimalFormat("#.##").format(test2));
	}
}
