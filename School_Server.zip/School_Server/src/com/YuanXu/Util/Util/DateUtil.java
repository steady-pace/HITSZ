﻿package com.YuanXu.Util.Util;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class DateUtil {
	/*
	 * 下几个月
	 */
	public static Date nextNumMonthToday(Integer months){
    	Calendar c=Calendar.getInstance();
    	Date date=new Date();
    	c.setTime(date);
    	c.add(Calendar.MONTH,months); 
    	return c.getTime();
	}
	
	public static Date nextNumMonthFromDate(Date date ,Integer months){
    	Calendar c=Calendar.getInstance();
    	c.setTime(date);
    	c.add(Calendar.MONTH,months); 
    	return c.getTime();
	}
	
	//下几天
	public static Date nextNumDayToday(Integer days){
		Calendar c=Calendar.getInstance();
    	Date date=new Date();
    	c.setTime(date);
    	c.add(Calendar.DAY_OF_MONTH,days);
    	return c.getTime();
	}
	
	public static Date nextNumDayFromDate(Date date , Integer days){
		Calendar c=Calendar.getInstance();
    	c.setTime(date);
    	c.add(Calendar.DAY_OF_MONTH,days);
    	return c.getTime();
	}
	
	//将时间转换成20140718143500
	public static String makeTodayTimeToString(Date time){
		int y,m,d,h,mi,s;    
		Calendar cal = Calendar.getInstance();
		cal.setTime(time);
		y = cal.get(Calendar.YEAR);
		m = cal.get(Calendar.MONTH);
		d = cal.get(Calendar.DATE);
		h = cal.get(Calendar.HOUR_OF_DAY); 
		mi = cal.get(Calendar.MINUTE);
		s = cal.get(Calendar.SECOND);
		String month = (m + "").length() > 1 ? (m + "") : ("0" + m);
		String day = (d + "").length() > 1 ? (d + "") : ("0" + d);
		String hour = (h + "").length() > 1 ? (h + "") : ("0" + h);
		String min = (mi + "").length() > 1 ? (mi + "") : ("0" + mi);
		String se = (s + "").length() > 1 ? (s + "") : ("0" + s);
		return y + month + day + hour + min + se;
	}
	
	//是否同一天
	public static boolean isSameDay(Date   date1,Date   date2)   { 
		String DATE_FORMAT = "yyyy-MM-dd"; 
		java.text.SimpleDateFormat sdf = new java.text.SimpleDateFormat(DATE_FORMAT); 
		String date1Str = sdf.format(date1); 
		String date2Str = sdf.format(date2);
		return  date1Str.equals(date2Str); 
	}
	
	public static String FORMAT_ymdhms = "yyyy-MM-dd HH:mm:ss";
	public static String FORMAT_ymd = "yyyy-MM-dd";
	//转规定时间 ：
	@SuppressWarnings("deprecation")
	public static String toMyForm(String date,String sdf_str){
		final SimpleDateFormat sdf = new SimpleDateFormat(sdf_str);
		try {
			return sdf.parse(date).toLocaleString();
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		}
	}
	@SuppressWarnings("deprecation")
	public static String toMyForm(Date date,String sdf_str){
		final SimpleDateFormat sdf = new SimpleDateFormat(sdf_str);
		try {
			return sdf.parse(date.toLocaleString()).toLocaleString();
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		}
	}
	public static Date stringToDate(String time){
		final SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		try {
			return sdf.parse(time);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		}
	}
	
	public static Date stringToDate_noMin(String time){
		final SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		try {
			return sdf.parse(time);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		}
	}
	
	public static Date stringToDateDMY(String time){
		final SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
		try {
			return sdf.parse(time);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		}
	}
	
	//某个月最后一天
	public static int getLastDayOfMonth(int year, int month) {  
        Calendar cal = Calendar.getInstance();  
        cal.set(Calendar.YEAR, year);  
        cal.set(Calendar.MONTH, month);  
        // 某年某月的最后一天  
        return cal.getActualMaximum(Calendar.DATE);  
    } 
	//某个月最后一天
	public static int getLastDay(Date date) {
        Calendar cal = Calendar.getInstance();  
        cal.setTime(date); 
        // 某年某月的最后一天  
        return cal.getActualMaximum(Calendar.DATE);  
    } 
	
	/*
	 * 判断大小
	 */
	public static boolean justMaxMin(Date min,Date max){
		Long time1 = min.getTime();
		Long time2 = max.getTime();
		if(time1 > time2){
			return false;
		}else{
			return true;
		}
	}
	
	// 将date类型转换成字符串类型
	public static String dateToString(Date date){
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		String str = sdf.format(date);
		return str;
	}
}	
