package com.YuanXu.Util.Util;

import java.util.List;

import net.sf.json.JSONArray;

public class JsonDele {
	private List<Object> ids;

	public JsonDele(){
		
	}
	
	@SuppressWarnings({ "unchecked", "deprecation" })
	public JsonDele(String deleJson) {
		JSONArray jsonObject = JSONArray.fromObject(deleJson);
		ids = JSONArray.toList(jsonObject);
	}

	public List<Object> getIds() {
		return ids;
	}

	public void setIds(List<Object> ids) {
		this.ids = ids;
	}


	
}
