﻿package com.YuanXu.Util.Util;


/*
 * 配置信息
 * 
 */
public class MyAppConfigs {
	//配置文件xml中获取
	private static void initString(){
		XmlRead.readXml("WEB-INF/classes/conf/MyConfiguration.xml");
	}
	
	public static String getValue(String key){
		if(XmlRead.xmlAppValue_map == null || XmlRead.xmlAppValue_map.size() == 0){
			initString();
		}
		return XmlRead.xmlAppValue_map.get(key);
	}

}
