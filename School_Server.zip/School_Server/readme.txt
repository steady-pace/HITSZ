﻿YuanXuSSH 版本更新
2014-06之前版本 。。。。。。
2014-07-17追加 业务层、JSP缓存
2014-07-25优化底层框架、追加rcadmin模块、action方法权限定制
2014-07-28优化规划化与追加伪静态框架
2014-07-30追加优化静态化模块
2014-08-04追加阿里云OSS模块

注意：
1.ehcache.xml配置的缓存路径（E:/ehcache），必须保证E盘存在，不存在就换
2.静态化后，需要取消伪静态（web.xml中配置的UrlRewrite）

2014-08-12追加表单左键修改删除操作，优化静态化类库，优化JS库：
表单JS使用方法，返回a标签代码：
doOther(url,text)
doOtherMsg(msg,url,text)
doOtherEdit(rowIndex)
doOtherDele(rowIndex)  
addTabFromTab(subtitle,url,menuId,text)
doOtherSuccessMsg(msg,url,text,successMsg)

JS直接调用执行方法：
doOther_(url,text)
doOtherMsg_(msg,url,text)
doOtherEdit_(rowIndex)
doOtherDele_(rowIndex)
addTabFromTab_(subtitle,url,menuId,text)
doOtherSuccessMsg_(msg,url,text,successMsg)

2014-08-13封装业务层yxeasyui模块增删改查方法，使用配置实现，若增删改查有特殊需求，可以重写接口方法来实现替换默认方法。

2014-09-17追加flotr2统计报表图表前台框架。



ehcache.xml 必须acs格式保存，不能utf-8
 <!--   
        diskStore ：指定数据存储位置，可指定磁盘中的文件夹位置  
        defaultCache ： 默认的管理策略  
          
        以下属性是必须的：  
            name： Cache的名称，必须是唯一的(ehcache会把这个cache放到HashMap里)。maxElementsInMemory：在内存中缓存的element的最大数目。   
            maxElementsOnDisk：在磁盘上缓存的element的最大数目，默认值为0，表示不限制。   
            eternal：设定缓存的elements是否永远不过期。如果为true，则缓存的数据始终有效，如果为false那么还要根据timeToIdleSeconds，timeToLiveSeconds判断。   
            overflowToDisk： 如果内存中数据超过内存限制，是否要缓存到磁盘上。   
              
        以下属性是可选的：  
            timeToIdleSeconds： 对象空闲时间，指对象在多长时间没有被访问就会失效。只对eternal为false的有效。默认值0，表示一直可以访问。  
            timeToLiveSeconds： 对象存活时间，指对象从创建到失效所需要的时间。只对eternal为false的有效。默认值0，表示一直可以访问。  
            diskPersistent： 是否在磁盘上持久化。指重启jvm后，数据是否有效。默认为false。   
            diskExpiryThreadIntervalSeconds： 对象检测线程运行时间间隔。标识对象状态的线程多长时间运行一次。   
            diskSpoolBufferSizeMB： DiskStore使用的磁盘大小，默认值30MB。每个cache使用各自的DiskStore。   
            memoryStoreEvictionPolicy： 如果内存中数据超过内存限制，向磁盘缓存时的策略。默认值LRU，可选FIFO、LFU。   
          
            缓存的3 种清空策略 ：  
            FIFO ，first in first out (先进先出).  
            LFU ， Less Frequently Used (最少使用).意思是一直以来最少被使用的。缓存的元素有一个hit 属性，hit 值最小的将会被清出缓存。  
            LRU ，Least Recently Used(最近最少使用). (ehcache 默认值).缓存的元素有一个时间戳，当缓存容量满了，而又需要腾出地方来缓存新的元素的时候，那么现有缓存元素中时间戳离当前时间最远的元素将被清出缓存。  
-->  



<bean id="methodCachePointCut" class="org.springframework.aop.support.RegexpMethodPointcutAdvisor">  
        <property name="advice">  
            <ref local="methodCacheInterceptor"/>  
        </property>  
        <!-- 下面的配置就使得在数据访问时，cache将拦截从数据库获取的数据，与cache数据比较，如有就不放入cache，没有就放入，更新到数据库去，也是先存入cache，再更新到数据库中去 -->  
        <property name="patterns">  
            <list>  
                <value>.web*(..)</value>  
            </list>  
        </property>
    </bean>
    

业务层需要二次重写接口：
	public MyVoParent add(FormBeanParent dataParentForm) throws FileNotFoundException, IOException;
	
	/**
	 * 更新
	 * @param dataForm
	 * @return
	 */
	public MyVoParent update(FormBeanParent dataParentForm) throws FileNotFoundException, IOException;
	
	/**
	 * 删除
	 * @param dataForm
	 * @return
	 */
	public MyVoParent delete(FormBeanParent dataParentForm);
	
	/**
	 * 获取列表数据
	 * @param dataForm
	 * @return
	 */
	public MyVoParent getData(FormBeanParent dataParentForm);
	
	/**
	 * 操作
	 * @param dataForm
	 * @return
	 */
	public MyVoParent doOpreate(FormBeanParent dataParentForm);