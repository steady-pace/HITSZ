package com.Lyra.System;

import android.content.SharedPreferences;

public class SystemInfo {
	
	
	
	/**
	 * 保存系统设置数据
	 * @param sPreferences
	 */
	public SystemInfo(SharedPreferences sPreferences) {
		super();
	}
}
