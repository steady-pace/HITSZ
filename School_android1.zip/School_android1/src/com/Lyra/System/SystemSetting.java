package com.Lyra.System;


import android.app.Activity;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;

import com.Lyra.Util.GsonUtil;
import com.Lyra.Util.ValueUtil;
import com.Lyra.Vo.VoMember;


public class SystemSetting {
	
	/** 版本号 **/
	private String versionNo;
	private String versionCode;
	
	private final String systemPreferenceName = "IntelCampus";
	private final String userPreferenceName = "storeCampus";
	/** 系统数据 **/
	private SharedPreferences systemSharedPreferences;
	private Editor systemEditor;
	/** 用户数据 **/
	private SharedPreferences userSharedPreferences;
	private Editor userEditor;
	/**  **/
	private SystemInfo systemInfo;
	private UserInfo userInfo;
	
	public SystemSetting(){
		initSystemShared();
		versionAndCodeName();
		initDate();
	}
	
	/**
	 * 用户安全退出
	 */
	public void exitUser(){
		userInfo.exitUser(userEditor);
	}
	
	/**
	 * 用户安全退出
	 */
	public void LoginUser(VoMember obj ,String strPwd){
		userInfo.LoginUser(obj, obj.getF_mName(), strPwd);
	}
	/**
	 * 初始化存储信息
	 */
	public void initSystemShared(){
		systemSharedPreferences = ValueUtil.activityIndex.getSharedPreferences(this.systemPreferenceName,
				Activity.MODE_PRIVATE);
		systemEditor = systemSharedPreferences.edit();
		userSharedPreferences = ValueUtil.activityIndex.getSharedPreferences(this.userPreferenceName,
				Activity.MODE_PRIVATE);
		userEditor = userSharedPreferences.edit();
	}
	
	/**
	 * 初始化数据
	 */
	public void initDate(){
		systemInfo = new SystemInfo(systemSharedPreferences);
		userInfo = new UserInfo(userSharedPreferences);
		
	}
	
	
	public void versionAndCodeName(){
		String versionAndCodeName[] = this.getVersionNameAndCode();
		versionNo = versionAndCodeName[0];
		versionCode = versionAndCodeName[1];
	}
	/**
	 * 提取APP的版本信息
	 * @return
	 */
	private String[] getVersionNameAndCode(){
		String versionAndCodeName[] = new String[]{"",""};
		try {
			PackageManager pm = ValueUtil.activityIndex.getPackageManager();
			PackageInfo pi = pm.getPackageInfo("com.lyra.View", 0);
			versionAndCodeName[0] = pi.versionName;
			versionAndCodeName[1] = pi.versionCode+"";
		} catch (PackageManager.NameNotFoundException e) {
			e.printStackTrace();
			
		}
		return versionAndCodeName;
	}
	
	/**
	 * 曾经是否登录过
	 * 用于自动登录
	 * @return false:从来没有登陆过 
	 * true:已经登陆过 且保存过用户的数据
	 */
	public boolean justIsHadLogin(){
		if(userInfo.getF_uId().length() == 0 || userInfo.getF_uappKey().length() == 0 || userInfo.getF_uName().length() == 0 || userInfo.getF_uPw().length() == 0){
			return false;
		}else{
			return true;
		}
	}
	
	
	
	/*
	 * 保存登录状态
	 */
	public void loginSuccess(VoMember obj,String loginName,String loginPw ){
		userInfo.LoginUser(obj, loginName, loginPw);
		userEditor.putString(userInfo.getF_uappKeyStr(), obj.getAppKey());
		userEditor.putString(userInfo.getF_uNameStr(), loginName);
		userEditor.putString(userInfo.getF_uPwStr(), loginPw);
		userEditor.putString(userInfo.getF_uIdStr(), obj.getF_mId());
		String jsonStr = GsonUtil.toJson(obj);
		userEditor.putString(userInfo.getVoJsonStr(), jsonStr);
		userEditor.commit();
	}
	
	
	public String getVersionNo() {
		return versionNo;
	}
	public void setVersionNo(String versionNo) {
		this.versionNo = versionNo;
	}
	public String getVersionCode() {
		return versionCode;
	}
	public void setVersionCode(String versionCode) {
		this.versionCode = versionCode;
	}
	public SharedPreferences getSystemSharedPreferences() {
		return systemSharedPreferences;
	}
	public void setSystemSharedPreferences(SharedPreferences systemSharedPreferences) {
		this.systemSharedPreferences = systemSharedPreferences;
	}
	public Editor getSystemEditor() {
		return systemEditor;
	}
	public void setSystemEditor(Editor systemEditor) {
		this.systemEditor = systemEditor;
	}
	public SharedPreferences getUserSharedPreferences() {
		return userSharedPreferences;
	}
	public void setUserSharedPreferences(SharedPreferences userSharedPreferences) {
		this.userSharedPreferences = userSharedPreferences;
	}

	public Editor getUserEditor() {
		return userEditor;
	}

	public void setUserEditor(Editor userEditor) {
		this.userEditor = userEditor;
	}

	public String getSystemPreferenceName() {
		return systemPreferenceName;
	}

	public String getUserPreferenceName() {
		return userPreferenceName;
	}

	public SystemInfo getSystemInfo() {
		return systemInfo;
	}
	public void setSystemInfo(SystemInfo systemInfo) {
		this.systemInfo = systemInfo;
	}
	public UserInfo getUserInfo() {
		return userInfo;
	}
	public void setUserInfo(UserInfo userInfo) {
		this.userInfo = userInfo;
	}
	
	
	
}
