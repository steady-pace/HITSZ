package com.Lyra.System;

import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;

import com.Lyra.Util.GsonUtil;
import com.Lyra.Vo.VoMember;

public class UserInfo {

	private String f_uId;//ID
	private final String f_uIdStr = "f_uId";
	private String f_uappKey;//APPKEY
	private final String f_uappKeyStr = "f_uappKey";
	private String f_uName; // 用户名称
	private final String f_uNameStr = "f_uName";
	private String f_uPw; // 用户密码
	private final String f_uPwStr = "f_uPw";
	private VoMember vo; // 用户数据
	private String voJsonStr = "voStoreExternalJson";
	
	
	public UserInfo(SharedPreferences sPreferences) {
		super();
		this.f_uId = sPreferences.getString(f_uIdStr, "");
		this.f_uappKey = sPreferences.getString(f_uappKeyStr, "");
		this.f_uName = sPreferences.getString(f_uNameStr, "");
		this.f_uPw = sPreferences.getString(f_uPwStr, "");
		String voStoreExternalJson = sPreferences.getString(voJsonStr, "");
		vo = (VoMember) GsonUtil.getObj(voStoreExternalJson, VoMember.class);
	}
	
	public void LoginUser(VoMember obj,String loginName,String loginPw){
		this.f_uId = obj.getF_mId();
		this.f_uappKey = obj.getAppKey();
		this.f_uName = loginName;
		this.f_uPw = loginPw;
		this.vo = obj;
	}
	
	public void exitUser(Editor editor) {
		this.f_uId = "";
		this.f_uappKey = "";
		this.f_uName = "";
		this.f_uPw = "";
		editor.putString(f_uIdStr, f_uId);
		editor.putString(f_uappKeyStr, f_uappKey);
		editor.putString(f_uNameStr, f_uName);
		editor.putString(f_uPwStr, f_uPw);
		editor.commit();
	}
	
	
	
	public String getF_uId() {
		return f_uId;
	}
	public void setF_uId(String f_uId) {
		this.f_uId = f_uId;
	}
	public String getF_uappKey() {
		return f_uappKey;
	}
	public void setF_uappKey(String f_uappKey) {
		this.f_uappKey = f_uappKey;
	}
	public String getF_uName() {
		return f_uName;
	}
	public void setF_uName(String f_uName) {
		this.f_uName = f_uName;
	}
	public String getF_uPw() {
		return f_uPw;
	}
	public void setF_uPw(String f_uPw) {
		this.f_uPw = f_uPw;
	}
	
	public VoMember getVo() {
		return vo;
	}

	public void setVo(VoMember vo) {
		this.vo = vo;
	}

	public String getVoJsonStr() {
		return voJsonStr;
	}

	public void setVoJsonStr(String voJsonStr) {
		this.voJsonStr = voJsonStr;
	}

	public String getF_uIdStr() {
		return f_uIdStr;
	}
	public String getF_uappKeyStr() {
		return f_uappKeyStr;
	}
	public String getF_uNameStr() {
		return f_uNameStr;
	}
	public String getF_uPwStr() {
		return f_uPwStr;
	}
	
}
