package com.Lyra.Util;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.content.res.AssetManager;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;

import com.Lyra.Course.R;
import com.Lyra.System.SystemSetting;
import com.Lyra.View.WelcomeActivity;
import com.Yuanxu.BitmapCache.ImageLoader;



public class ValueUtil {
	
	/*
	 * 
	 *  ValueUtil.imageLoader.DisplayImage(url, imgView,null);
	 * */
	private static ImageLoader imageLoader;
	public static WelcomeActivity xActivity;
	public static Activity activityIndex;
	public static boolean isNeedJiaZaiImg; //是否需要加载图片
    private static AssetManager asset;
	private static SystemSetting systemSetting;
	
	private static int screenWidth;//屏幕宽
	private static int screenHeight;//屏幕高
    /**
     * 获取资源
     * @return
     */
    public static final AssetManager getAsset(){
    	if(asset == null){
    		initAsset();
    	}
    	return asset;
    }
    public static void initAsset(){
		 asset = activityIndex.getAssets();
	}
    
    /**
    * 初始化
    * @param context
    */
	public static void initSystemData(Activity context) {
		// 判断是否存在SD卡
		if (FileUtil.checkSDCard()) {
			// SD卡里创建该应用的文件夹
			FileUtil.creatXyoubite();
		}
		activityIndex = context;
		ValueUtil.activityIndex = context;
		imageLoader = new ImageLoader(context,FileUtil.getImgCacheDirectory(context));
		imageLoader.getMemoryCache().setLimit(10*1024*1024);
		//systemSetting = new SystemSetting();
		//getwidthPixels();
		//getheightPixels();
	}
	/**
	 * 初始化系统设置数据方法
	 * @return
	 */
	public static SystemSetting getSystemSetting() {
		if(systemSetting == null){
			systemSetting = new SystemSetting();
		}
		return systemSetting;
	}
	
	public static void eixtUser(Activity activity){
		getSystemSetting().exitUser();
	}

	/**
	 * 是否已经联网
	 * @param context
	 * @return
	 */
	public static boolean isHaveInternet(final Context context) {
		try {
			ConnectivityManager manger = (ConnectivityManager) context
					.getSystemService(Context.CONNECTIVITY_SERVICE);
			NetworkInfo info = manger.getActiveNetworkInfo();
			return (info != null && info.isConnected());
		} catch (Exception e) {
			return false;
		}
	}
	
	
	public static int getHeight(int yWidth,int width,int height){
		int h = (yWidth*height)/width;
		return h;
	}
	/**
	 * 获取屏幕宽
	 * @return
	 */
	@SuppressWarnings("deprecation")
	public static int getScreenWidth() {
		if(screenWidth == 0){
			screenWidth = xActivity.getWindow().getWindowManager().getDefaultDisplay().getWidth();
		}
		return screenWidth;
	}
	/**
	 * 获取屏幕高
	 * @return
	 */
	@SuppressWarnings("deprecation")
	public static int getScreenHeight() {
		if(screenHeight == 0){
			screenHeight = xActivity.getWindow().getWindowManager().getDefaultDisplay().getHeight();
		}
		return screenHeight;
	}
	
	
	public static void eixt(Activity activity){
		new AlertDialog.Builder(activity).setTitle(R.string.message_exit).setPositiveButton(R.string.sure, new OnClickListener() {
				
			@Override
			public void onClick(DialogInterface dialog, int which) {
				//ValueUtil.getSystemSetting().exitUser();
				android.os.Process.killProcess(android.os.Process.myPid());
				System.exit(0);
			}
		}).setNegativeButton(R.string.quxiao, new OnClickListener() {
			@Override
			public void onClick(DialogInterface dialog, int which) {
			}
		}).show();
	}
}
