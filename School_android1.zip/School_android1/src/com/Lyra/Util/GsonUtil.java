package com.Lyra.Util;

import com.google.gson.Gson;

public class GsonUtil {
	public static Object getObj(String jsonStr,Class<?> c){
		Gson gson = new Gson();
		return gson.fromJson(jsonStr, c);
	}
	
	public static String toJson(Object object){
		Gson gson = new Gson();
		return gson.toJson(object);
	}
}
