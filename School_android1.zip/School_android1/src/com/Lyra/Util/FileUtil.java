package com.Lyra.Util;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import android.app.Activity;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Environment;

public class FileUtil {
	public static String Xyoubite = "Xyoubite";
	public static String DLVersionFile = "apps";
	public static String ImgFile = "img";
	/*
	 * 获取SDcart路径
	 */
	public static String getSDPATH() {
		return Environment.getExternalStorageDirectory()
				.getAbsolutePath() + File.separator;
	}
	
	/*
	 * 获取android 下载APPS缓冲路径
	 */
	public static String getDownloadCacheDirectory(Activity activity){
		return activity.getCacheDir() + File.separator + DLVersionFile + File.separator;
	}
	
	/*
	 * 获取 下载img缓冲路径
	 */
	public static String getImgCacheDirectory(Context context){
		if (android.os.Environment.getExternalStorageState().equals(
				android.os.Environment.MEDIA_MOUNTED)){
			return FileUtil.getSDPATH() + FileUtil.Xyoubite + File.separator + FileUtil.ImgFile;
		}else{
			return context.getCacheDir().getAbsolutePath();
		}
	}
	
	
	/**
	 * 检验SDcard状态
	 * 
	 * @return boolean
	 */
	public static boolean checkSDCard() {
		if (android.os.Environment.getExternalStorageState().equals(
				android.os.Environment.MEDIA_MOUNTED)) {
			return true;
		} else {
			return false;
		}
	}

	/**
	 * 在SDCard 上创建文件
	 * 
	 * @param fileName
	 *            文件名
	 * @param dir
	 *            目录
	 * @return
	 * @throws IOException
	 */

	public static File createFolderInSDCard(String folderName, String dir)
			throws IOException {
		File file = new File(getSDPATH() + dir + File.separator + folderName);
		if (!file.exists()) {
			file.mkdir();
		}
		return file;
	}
	
	public static File createFileInSDCard(String fileName, String dir)
			throws IOException {
		File file = new File(dir + fileName);
		if (!file.exists()) {
			file.createNewFile();
		}
		return file;
	}
	
	public static void deleFile(String fileName, String dir)
			throws IOException {
		File file = new File(dir + fileName);
		if (file.exists()) {
			file.delete();
		}
	}
	
	/**
	 * 删除文件夹
	 * 
	 * @param filePathAndName
	 *            String 文件夹路径及名称 如c:/fqf
	 * @param fileContent
	 *            String
	 * @return boolean
	 */
	
	public static boolean delFolder(String folderPath) {
		try {
			delAllFile(folderPath); // 删除完里面所有内容
			String filePath = folderPath;
			filePath = filePath.toString();
			java.io.File myFilePath = new java.io.File(filePath);
			myFilePath.delete(); // 删除空文件夹
			return true;
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
	}

	
	/**
	 * 删除文件夹里面的所有文件
	 * @param path String 文件夹路径 如 c:/fqf
	 */
	public static void delAllFile(String path) {
		File file = new File(path);
		if (!file.exists()) {
			return;
		}
		if (!file.isDirectory()) {
			return;
		}
		String[] tempList = file.list();
		File temp = null;
		for (int i = 0; i < tempList.length; i++) {
			if (path.endsWith(File.separator)) {
				temp = new File(path + tempList[i]);
			} else {
				temp = new File(path + File.separator + tempList[i]);
			}
			if (temp.isFile()) {
				temp.delete();
			}
			if (temp.isDirectory()) {
				delAllFile(path + "/" + tempList[i]);// 先删除文件夹里面的文件
				delFolder(path + "/" + tempList[i]);// 再删除空文件夹
			}
		}
	}

	public static File createFolder(String path) {
		File dirFile = new File(path);
		if (!dirFile.exists()) {
			dirFile.mkdir();
		}
		return dirFile;
	}
	
	/**
	 * 在SDCard上创建目录
	 * 
	 * @param dir
	 *            目录名
	 * @return
	 */

	public static File createSDDir(String dir) {
		File dirFile = new File(getSDPATH() + dir + File.separator);
		if (!dirFile.exists()) {
			dirFile.mkdir();
		}
		return dirFile;
	}

	/**
	 * 判断该文件存不存在 ,并不新建
	 * 
	 * @param fileName
	 * @param path
	 * @return
	 */

	public static boolean isFileExist(String fileName, String path) {
		File file = new File( path  + fileName);
		return file.exists();
	}
	
	
	/**
	 * 创建本工程用到的一些目录
	 * 
	 * @return
	 */
	public static boolean creatXyoubite() {
		try {
			createSDDir(FileUtil.Xyoubite);
			createFolderInSDCard(FileUtil.DLVersionFile, FileUtil.Xyoubite);
			createFolderInSDCard(FileUtil.ImgFile, FileUtil.Xyoubite);
			return true;
		} catch (IOException e) {
			e.printStackTrace();
			return false;
		}
	}
	
	/**
	 * 获取本工程存放下载版本的路径
	 * @return
	 */
	public static String getDLVersionFile(){
		return getSDPATH() + FileUtil.Xyoubite + File.separator + DLVersionFile +File.separator;
	}
	
	
	/**
	 * 从SDCard中取出图片
	 * 
	 * @param path
	 *            相对于sdcard根目录的路径
	 * @param fileName
	 *            文件名
	 * @return
	 */
	public static Bitmap getImageFromSDcard(String path, String fileName) {
		Bitmap image = null;
		if (isFileExist(fileName, path)) {
			try {
				File imageFile = new File(path,fileName);
				FileInputStream fis = new FileInputStream(imageFile);		
				BitmapFactory.Options opt = new BitmapFactory.Options();
				opt.inPreferredConfig = Bitmap.Config.RGB_565;
				opt.inPurgeable = true;
				opt.inInputShareable = true;
				image = BitmapFactory.decodeStream(fis,null,opt);
				return image;
			} catch (FileNotFoundException e) {
				e.printStackTrace();
				return null;
			}
		} else {
			return null;
		}
	}
}
