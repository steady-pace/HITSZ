package com.Lyra.Util;
/*
 * ��ȴ�ӿ�
 */
public interface ProgressParent {
	public void startProgress();
	public void stopProgress();
	public void isNoWeb();
}
