package com.Lyra.Util;

import android.app.Activity;
import android.content.Context;
import android.widget.Toast;

import com.Lyra.Course.R;

public class Util {
	public static long exitTime = 0;
	/**********************************************
	 * �˳�����
	 */
	public static void eixt(Activity activity){
		// �ж�2�ε���¼�ʱ��  
		if ((System.currentTimeMillis() - exitTime) > 2000) {  
			Toast.makeText(activity, activity.getResources().getString(R.string.msg_back), Toast.LENGTH_SHORT).show();
			exitTime = System.currentTimeMillis();  
		} else {  
			// �˳�����
			android.os.Process.killProcess(android.os.Process.myPid());
			System.exit(0);  
		} 
	}
	
	/**
	 * �õ��豸��Ļ�Ŀ���
	 */
	public static int getScreenWidth(Context context) {
		return context.getResources().getDisplayMetrics().widthPixels;
	}

	/**
	 * �õ��豸��Ļ�ĸ߶�
	 */
	public static int getScreenHeight(Context context) {
		return context.getResources().getDisplayMetrics().heightPixels;
	}

	/**
	 * �õ��豸���ܶ�
	 */
	public static float getScreenDensity(Context context) {
		return context.getResources().getDisplayMetrics().density;
	}

	/**
	 * ���ܶ�ת��Ϊ����
	 */
	public static int dip2px(Context context, float px) {
		final float scale = getScreenDensity(context);
		return (int) (px * scale + 0.5);
	}
}
