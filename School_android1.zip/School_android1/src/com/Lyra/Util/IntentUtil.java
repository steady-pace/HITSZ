/**
 * 
 */
package com.Lyra.Util;

/**
 * 这个类的作用是页面跳转时传参的Id
 *@author Lyra
 *
 */
public class IntentUtil {
	/** 新生指南跳转时的传值 **/
	public static String name = "name" ;
	/** 新生指南具体内容跳转是的传值  **/
	public static String titlename = "titlename" ;
	/** 新生指南具体内容跳转是的传值 --用于读取txt文档 **/
	public static String txtname = "txtname" ;
	/** 文件夹的name **/
	public static String folderName = "folderName";
	/** 传新闻id **/
	public static String newsId ="newsId";
	/** 传新闻Url **/
	public static String newsUrl ="newsUrl";
	/** 传新闻Title **/
	public static String newsTitle ="newsTitle";
	/** 传社团活动id **/
	public static String groupActionId ="groupActionId";
	/** 传社团活动名称 **/
	public static String groupActionTitle ="groupActionTitle";
	
}
