package com.Lyra.Util;

import android.app.Activity;
import android.app.Dialog;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup.LayoutParams;
import android.view.Window;
import android.view.WindowManager;
import android.widget.TextView;

import com.Lyra.Course.R;


public class WaitPopupUtil implements ProgressParent{
	private Dialog reNameDialog;
	private Activity context;
	private TextView txt_wait;
	private String txtWait;
	
	public WaitPopupUtil(Activity context,String txtWait) {
		super();
		this.context = context;
		this.txtWait = txtWait;
	}
	
	/**
	 * 閿熼摪鏂ゆ嫹涓�閿熸枻鎷穚opupWindow閿熸枻鎷烽敓鏂ゆ嫹閿熸枻鎷� popupWindow閿熸枻鎷蜂竴閿熸枻鎷烽敓鏂ゆ嫹閿熸枻鎷峰紡閿熶茎纰夋嫹閿熸枻鎷烽敓鏂ゆ嫹閿熸枻鎷烽敓鏂ゆ嫹閿熻娇璁规嫹閿熸枻鎷烽敓鏂ゆ嫹閿熸枻鎷烽敓鏂ゆ嫹椤洪敓鏂ゆ嫹閿熸枻鎷烽敓鏂ゆ嫹閿熸枻鎷烽敓鏂ゆ嫹涔嬪墠閿熸枻鎷烽敓鏂ゆ嫹閿熸枻鎷烽敓鎻仮鎲嬫嫹鍗撮敓鏂ゆ嫹閿燂拷
	 * 閿熸枻鎷烽敓绱竘ertDialog閿熸枻鎷峰悓鍝﹂敓鏂ゆ嫹AlertDialog閿熻鍑ゆ嫹閿熸枻鎷烽敓鏂ゆ嫹寮忛敓鏂ゆ嫹閿熸枻鎷烽敓鏂ゆ嫹AlertDialog閿熸枻鎷烽敓鏂ゆ嫹閿熸枻鎷锋椂閿熸触锛岀尨鎷峰彴閿熸枻鎷烽敓瑙掍紮鎷烽敓鏂ゆ嫹閿熸枻鎷烽敓鏂ゆ嫹閿熸枻鎷烽敓鏂ゆ嫹閿熸枻鎷烽敓鏂ゆ嫹閿熻剼璁规嫹閿燂拷
	 */
	private void initPopWindow() {
		View contentView = LayoutInflater.from(context).inflate(R.layout.wait_popup, null);
		this.txt_wait = (TextView) contentView.findViewById(R.id.txt_wait);
		if(txt_wait == null){
			this.txt_wait.setText(context.getString(R.string.msg_waitting));
		}else{
			this.txt_wait.setText(txtWait);
		}
		
		
		reNameDialog = new Dialog(context,R.style.dcaiDialog);
		@SuppressWarnings("deprecation")
		android.widget.RelativeLayout.LayoutParams l_params = new android.widget.RelativeLayout.LayoutParams(LayoutParams.FILL_PARENT, LayoutParams.FILL_PARENT);
		reNameDialog.setContentView(contentView,l_params);
		Window win = reNameDialog.getWindow();
		win.setWindowAnimations(R.style.AnimationPreviewWait);
		WindowManager.LayoutParams lp = win.getAttributes();
		lp.x= 0;
		lp.y= 0;
		reNameDialog.setCanceledOnTouchOutside(false);//閿熸枻鎷烽敓鐭鎷烽敓绱籭alog閿熻В閮ㄩ敓鏂ゆ嫹閿熸枻鎷烽敓鏂ゆ嫹閿熸触涓嶅叧鎲嬫嫹Dialog
		reNameDialog.show();
	}

	@Override
	public void startProgress() {
		initPopWindow();
	}

	@Override
	public void stopProgress() {
		if(reNameDialog !=null && reNameDialog.isShowing()){
			reNameDialog.dismiss();
		}
	}

	@Override
	public void isNoWeb() {
		this.stopProgress();
		ToastUtil.makeToastDuttom(context, context.getString(R.string.txt_wait_noweb_true));
	}

}
