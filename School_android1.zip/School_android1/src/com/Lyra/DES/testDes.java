package com.Lyra.DES;

public class testDes {
	public static void main(String[] args) throws Exception {  
        // TODO Auto-generated method stub   
//        String text = "0123ABCD!@#$中文";
        String text = "123456";
        String result1 = Des.encryptDES(text);  
        String result2 = Des.decryptDES(result1);  
        System.out.println(result1);  
        System.out.println(result2);
    }  

}
