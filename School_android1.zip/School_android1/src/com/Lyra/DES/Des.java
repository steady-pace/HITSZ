package com.Lyra.DES;

import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;

public class Des {
	public static String key = "yuanxu88";
	
    public static String getKey() {
    	if(key == null){
    		key = "yuanxu88";
    	}
		return key;
	}
    
	public static String encryptDES(String encryptString) throws Exception {
		SecretKeySpec key = new SecretKeySpec(getKey().getBytes(), "DES"); 
    	Cipher cipher = Cipher.getInstance("DES/ECB/PKCS5Padding");  
     	cipher.init(Cipher.ENCRYPT_MODE, key);
        byte[] encryptedData = cipher.doFinal(encryptString.getBytes());  
        return Base64.encode(encryptedData);  
    }  
    public static String decryptDES(String decryptString) throws Exception {  
        byte[] byteMi = Base64.decode(decryptString);     
        SecretKeySpec key = new SecretKeySpec(getKey().getBytes(), "DES");  
        Cipher cipher = Cipher.getInstance("DES/ECB/PKCS5Padding");  
        cipher.init(Cipher.DECRYPT_MODE, key);  
        byte decryptedData[] = cipher.doFinal(byteMi);
        return new String(decryptedData);  
    }  
}  