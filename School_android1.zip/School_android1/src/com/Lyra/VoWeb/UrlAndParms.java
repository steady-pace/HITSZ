package com.Lyra.VoWeb;
import java.util.ArrayList;
import java.util.List;

import com.Lyra.DES.Des;
import com.Lyra.Util.ValueUtil;

public class UrlAndParms {
	//public static String testServerIp = "42.96.206.111/YuanXuTakeOut";
	public static String testServerIp = "192.168.0.254:8080/School";
	public static String url_root = "http://" + testServerIp;
	public static String api = "/external_user";
	private static String from = "android";
	
	
	public static String getImgPath(String imgUrl){
		return url_root + "/.." + imgUrl;
	}
	
	/** 注册 **/
	public static String url_register = url_root + api + "/registerUser.api";
	public static List<String[]> parms_register(String name,String pw,String stuNo,String sex,String email) throws Exception{
		List<String[]> parms_l = new ArrayList<String[]>();
		String str01[] = new String[]{"f_mName",name};
		String str02[] = new String[]{"f_mPwd",Des.encryptDES(pw)};
		String str03[] = new String[]{"f_sex",sex};
		String str04[] = new String[]{"f_email",email};
		String str05[] = new String[]{"f_mNo",stuNo};
		parms_l.add(str01);
		parms_l.add(str02);
		parms_l.add(str03);
		parms_l.add(str04);
		parms_l.add(str05);
		return parms_l;
	}
	 
	/** 登录 **/
	public static String url_login = url_root + api + "/loginUser.api";
	public static List<String[]> parms_login(String nice,String pw) throws Exception{
		List<String[]> parms_l = new ArrayList<String[]>();
		String str01[] = new String[]{"f_mName",nice};
		String str02[] = new String[]{"f_mPwd",Des.encryptDES(pw)};
		String str03[] = new String[]{"from",from};
		parms_l.add(str01);
		parms_l.add(str02);
		parms_l.add(str03);
		return parms_l;
	}
	
	/** 登录 **/
	public static String url_news = url_root + api + "/doSchoolnews.api";
	public static List<String[]> parms_doSchoolnews() throws Exception{
		List<String[]> parms_l = new ArrayList<String[]>();
		String str01[] = new String[]{"from",from};
		parms_l.add(str01);
		return parms_l;
	}
	
	/** 失物招领 **/
	public static String url_SW = url_root + api + "/doLookforlose.api";
	public static List<String[]> parms_doLookforlose() throws Exception{
		List<String[]> parms_l = new ArrayList<String[]>();
		String str01[] = new String[]{"from",from};
		parms_l.add(str01);
		return parms_l;
	}
	
	public static String url_XZ = url_root + api + "/doGetforlose.api";
	public static List<String[]> parms_doGetforlose() throws Exception{
		List<String[]> parms_l = new ArrayList<String[]>();
		String str01[] = new String[]{"from",from};
		parms_l.add(str01);
		return parms_l;
	}
	
	public static String url_GA = url_root + api + "/doGroupaction.api";
	public static List<String[]> parms_doGroupaction() throws Exception{
		List<String[]> parms_l = new ArrayList<String[]>();
		String str01[] = new String[]{"from",from};
		parms_l.add(str01);
		return parms_l;
	}
	
	public static String url_GAID = url_root + api + "/doGroupactionById.api";
	public static List<String[]> parms_doGroupactionById( String f_gaId) throws Exception{
		List<String[]> parms_l = new ArrayList<String[]>();
		String str01[] = new String[]{"from",from};
		String str02[] = new String[]{"f_gaId",f_gaId};
		parms_l.add(str01);
		parms_l.add(str02);
		return parms_l;
	}
	public static String url_GAZan = url_root + api + "/doGivegood.api";
	public static List<String[]> parms_doGivegood( String f_gaId) throws Exception{
		List<String[]> parms_l = new ArrayList<String[]>();
		String str01[] = new String[]{"from",from};
		String str02[] = new String[]{"f_gaId",f_gaId};
		String str03[] = new String[]{"f_mId",ValueUtil.getSystemSetting().getUserInfo().getF_uId()};
		parms_l.add(str01);
		parms_l.add(str02);
		parms_l.add(str03);
		return parms_l;
	}
	public static String url_GAHit = url_root + api + "/doGivehit.api";
	public static List<String[]> parms_doGivehit( String f_gaId) throws Exception{
		List<String[]> parms_l = new ArrayList<String[]>();
		String str01[] = new String[]{"from",from};
		String str02[] = new String[]{"f_gaId",f_gaId};
		String str03[] = new String[]{"f_mId",ValueUtil.getSystemSetting().getUserInfo().getF_uId()};
		parms_l.add(str01);
		parms_l.add(str02);
		parms_l.add(str03);
		return parms_l;
	}
}