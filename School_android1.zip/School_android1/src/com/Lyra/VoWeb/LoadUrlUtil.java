package com.Lyra.VoWeb;

import java.util.ArrayList;
import java.util.List;

import org.apache.http.HttpResponse;
import org.apache.http.HttpStatus;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.protocol.HTTP;
import org.apache.http.util.EntityUtils;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;

import com.Lyra.Course.R;
import com.Lyra.Util.GsonUtil;
import com.Lyra.Util.ProgressParent;
import com.Lyra.Util.ValueUtil;
import com.Lyra.View.LoginActivity;

@SuppressLint("HandlerLeak") public class LoadUrlUtil {
	private Context context;
	private ProgressParent progressParent;
	private CallbackSuccess callbackSuccess;
	private Callbackfail callbackfail;
	private String url;
	private List<String[]> params_l;
	private Class<?> c;
	
	private final int WAIT_STAR = 1;
	private final int WAIT_STOD = 2;
	
	public LoadUrlUtil() {
		super();
	}
	
	public LoadUrlUtil(Context context,String url,
			List<String[]> params_l) {
		this.context = context;
		this.url = url;
		this.params_l = params_l;
	}
	
	public void initLoadUrlUtil(Context context,String url,
			List<String[]> params_l) {
		this.context = context;
		this.url = url;
		this.params_l = params_l;
	}
	
	public void beginAccessUrl( CallbackSuccess callbackSuccess,Callbackfail callbackfail,Class<?> c,ProgressParent progressParent) {
		this.callbackSuccess = callbackSuccess;
		this.callbackfail = callbackfail;
		this.progressParent = progressParent;
		this.c = c;
		if(!ValueUtil.isHaveInternet(ValueUtil.activityIndex)){
			progressParent.isNoWeb();
			MyVoParent msgCarrier = new MyVoParent("error", context.getString(R.string.txt_wait_noweb_true));
			if (callbackfail != null) {
				callbackfail.doCallback(msgCarrier);
				callbackfail = null;
			} else {
				sendToastMessage(msgCarrier.getData());
			}
			return;
		}
		MyRequestThread myRequestThread = new MyRequestThread();
		myRequestThread.start();
	}
	
	public void beginAccessUrl_ng(Context context, String url,
			List<String[]> params_l, CallbackSuccess callbackSuccess,Callbackfail callbackfail, Class<?> c) {
		this.context = context;
		this.url = url;
		this.params_l = params_l;
		this.callbackSuccess = callbackSuccess;
		this.callbackfail = callbackfail;
		this.c = c;
		MyRequestThread_bg myRequestThread = new MyRequestThread_bg();
		myRequestThread.start();
	}
	
	public void beginAccessUrl_nohandler(Context context, String url,
			List<String[]> params_l, CallbackSuccess callbackSuccess,Callbackfail callbackfail, Class<?> c) {
		this.context = context;
		this.url = url;
		this.params_l = params_l;
		this.callbackSuccess = callbackSuccess;
		this.callbackfail = callbackfail;
		this.c = c;
		MyRequestThread_bg_nohandler myRequestThread = new MyRequestThread_bg_nohandler();
		myRequestThread.start();
	}
	
	
	class MyRequestThread extends Thread {
		public void run() {
			Looper.prepare(); 
			sendWaitMessage(WAIT_STAR);
			MyVoParent msgCarrier = requestUrl(url, params_l);
			sendWaitMessage(WAIT_STOD);
			if(msgCarrier.getResult().contains("loseAppKey")){
				Intent intent = new Intent(ValueUtil.activityIndex,LoginActivity.class);
				ValueUtil.activityIndex.startActivity(intent);
				ValueUtil.activityIndex.finish();
			}else if (msgCarrier.getResult().contains("error") || msgCarrier.getResult().contains("input")) {
				if (callbackfail != null) {
					callbackfail.doCallback(msgCarrier);
					callbackfail = null;
				} else {
					sendToastMessage(msgCarrier.getData());
				}
			} else if (msgCarrier.getResult().contains("success")) {
				sendMessageSuccess(msgCarrier);
			}
			Looper.loop();
		}
	}
	
	class MyRequestThread_bg extends Thread {
		public void run() {
			Looper.prepare(); 
			MyVoParent msgCarrier = requestUrl(url, params_l);
			if (msgCarrier.getResult().contains("error") || msgCarrier.getResult().contains("input")) {
				if (callbackfail != null) {
					callbackfail.doCallback(msgCarrier);
					callbackfail = null;
				} else {
					sendToastMessage(msgCarrier.getData());
				}
			} else if (msgCarrier.getResult().contains("success")) {
				sendMessageSuccess(msgCarrier);
			}
			Looper.loop();
		}
	}
	
	class MyRequestThread_bg_nohandler extends Thread {
		public void run() {
			Looper.prepare(); 
			MyVoParent msgCarrier = requestUrl(url, params_l);
			if (msgCarrier.getResult().contains("error") || msgCarrier.getResult().contains("input")) {
				if (callbackfail != null) {
					callbackfail.doCallback(msgCarrier);
					callbackfail = null;
				}
			} else if (msgCarrier.getResult().contains("success")) {
				sendMessageSuccess(msgCarrier);
			}
			Looper.loop();
		}
	}

	public void sendMessageSuccess(MyVoParent msgCarrier) {
		callbackSuccess.doCallback(msgCarrier);
	}

	public interface CallbackSuccess {
		public void doCallback(MyVoParent msgCarrier);
	}

	public interface Callbackfail {
		public void doCallback(MyVoParent msgCarrier);
	}

	public void setCallbackSuccess(CallbackSuccess callbackSuccess) {
		this.callbackSuccess = callbackSuccess;
	}

	public void setCallbackfail(Callbackfail callbackfail) {
		this.callbackfail = callbackfail;
	}

	public MyVoParent requestUrl(String url, List<String[]> params_l) {
		MyVoParent msgCarrier;
		try {
			HttpPost httpPost = new HttpPost(url);
			List<NameValuePair> params = new ArrayList<NameValuePair>();
			for (String[] params_str : params_l) {
				params.add(new BasicNameValuePair(params_str[0], params_str[1]));
			}
			httpPost.setEntity(new UrlEncodedFormEntity(params, HTTP.UTF_8));

			HttpClient client = new DefaultHttpClient();
//			client.getParams().setParameter(CoreConnectionPNames.CONNECTION_TIMEOUT, 5000);
//			client.getParams().setParameter(CoreConnectionPNames.SO_TIMEOUT,5000);

			HttpResponse httpResponse = client.execute(httpPost);

			int re = httpResponse.getStatusLine().getStatusCode();
			if (re == 200){
				String result = EntityUtils.toString(httpResponse.getEntity());
				msgCarrier = (MyVoParent) GsonUtil.getObj(result, c);
				if(msgCarrier == null){
					msgCarrier = new MyVoParent("input", ValueUtil.activityIndex.getString(R.string.web_error));
				}
			} else if(re == 500){
				msgCarrier = new MyVoParent("input", ValueUtil.activityIndex.getString(R.string.web_error_500));
			}else if (re == HttpStatus.SC_GATEWAY_TIMEOUT
					|| re == HttpStatus.SC_REQUEST_TIMEOUT) {
				msgCarrier = new MyVoParent("input", ValueUtil.activityIndex.getString(R.string.web_error_timeout));
			} else {
				msgCarrier = new MyVoParent("input", ValueUtil.activityIndex.getString(R.string.web_error_other));
			}
		} catch (Exception e) {
			e.printStackTrace();
			msgCarrier = new MyVoParent("input" + "", ValueUtil.activityIndex.getString(R.string.web_error_project));
		}
		return msgCarrier;
	}

	private void sendToastMessage(String msg) {
		Message m = new Message();
		Bundle data = new Bundle();
		data.putString("msg", msg);
		m.setData(data);
		try{
			handlerToast.sendMessage(m);
		}catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
	}
	
	private Handler handlerToast = new Handler() {
		@Override
		public void handleMessage(Message msg) {
			try{
				String message = msg.getData().getString("msg");
				AlertDialog alertDialog = new AlertDialog.Builder(context).setMessage(message).create();
				alertDialog.setCanceledOnTouchOutside(true);
				alertDialog.show();
				super.handleMessage(msg);
			}catch (Exception e) {
				// TODO: handle exception
				e.printStackTrace();
			}
		}
	};
	
	@SuppressLint("HandlerLeak") 
	private void sendWaitMessage(int what) {
		Message m = new Message();
		m.what = what;
		try{ 
			handlerWait.sendMessage(m);
		}catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
	}
	
	private Handler handlerWait = new Handler() {
		@Override
		public void handleMessage(Message msg) {
			switch (msg.what) {
			case WAIT_STAR:
				progressParent.startProgress();
				break;
			case WAIT_STOD:
				progressParent.stopProgress();
				break;
			}
			super.handleMessage(msg);
		}
	};
}
