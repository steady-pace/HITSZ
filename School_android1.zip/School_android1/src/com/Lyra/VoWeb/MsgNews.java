package com.Lyra.VoWeb;

import java.util.ArrayList;
import java.util.List;

import com.Lyra.Vo.VoNews;

public class MsgNews extends MyVoParent implements java.io.Serializable{

	private static final long serialVersionUID = 1L;

	private List<VoNews> voNews = new ArrayList<VoNews>();

	/**
	 * @return the voNews
	 */
	public List<VoNews> getVoNews() {
		return voNews;
	}

	/**
	 * @param voNews the voNews to set
	 */
	public void setVoNews(List<VoNews> voNews) {
		this.voNews = voNews;
	}

	


	


}
