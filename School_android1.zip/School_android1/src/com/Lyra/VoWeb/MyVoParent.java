package com.Lyra.VoWeb;


public class MyVoParent implements java.io.Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public String result;
	public String data;
	
	public MyVoParent(){
		
	}
	
	public MyVoParent(String result,String data){
		this.result = result;
		this.data = data;
	}
	
	public String getResult() {
		if(result == null){
			return "Fail";
		}
		return result;
	}
	public void setResult(String result) {
		
		this.result = result;
	}
	public String getData() {
		if(data == null){
			data = "Serivce-Fail";
		}
		return data;
	}
	public void setData(String data) {
		this.data = data;
	}
	
}	
