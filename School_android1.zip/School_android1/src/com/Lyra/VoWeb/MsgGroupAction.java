package com.Lyra.VoWeb;

import java.util.List;

import com.Lyra.Vo.VoGroupAction;


public class MsgGroupAction extends MyVoParent implements java.io.Serializable{

	private static final long serialVersionUID = 1L;

	private List<VoGroupAction> action ;

	public List<VoGroupAction> getAction() {
		return action;
	}

	public void setAction(List<VoGroupAction> action) {
		this.action = action;
	}
}
