package com.Lyra.VoWeb;

import com.Lyra.Vo.VoGroupAction;


public class MsgGroupActionById extends MyVoParent implements java.io.Serializable{

	private static final long serialVersionUID = 1L;

	private VoGroupAction action ;

	public VoGroupAction getAction() {
		return action;
	}

	public void setAction(VoGroupAction action) {
		this.action = action;
	}

}
