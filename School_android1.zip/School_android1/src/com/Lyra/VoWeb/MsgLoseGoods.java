package com.Lyra.VoWeb;

import java.util.List;

import com.Lyra.Vo.VoLoseGoods;


public class MsgLoseGoods extends MyVoParent implements java.io.Serializable{

	private static final long serialVersionUID = 1L;

	private List<VoLoseGoods> loseGoods ;

	public List<VoLoseGoods> getLoseGoods() {
		return loseGoods;
	}

	public void setLoseGoods(List<VoLoseGoods> loseGoods) {
		this.loseGoods = loseGoods;
	}

}
