package com.Lyra.View;

import java.util.List;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.Lyra.Course.R;
import com.Lyra.Util.ValueUtil;
import com.Lyra.Util.WaitPopupUtil;
import com.Lyra.VoWeb.LoadUrlUtil;
import com.Lyra.VoWeb.LoadUrlUtil.CallbackSuccess;
import com.Lyra.VoWeb.MsgLoginUser;
import com.Lyra.VoWeb.MyVoParent;
import com.Lyra.VoWeb.UrlAndParms;

public class LoginActivity extends Activity{

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		this.requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.login);
		init();
	}
	private void init() {
		initView();
		initData();
	}
	private void initData() {
		txt_title_no.setText(getResources().getString(R.string.txt_title_login));
		btn_enter.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View arg0) {
				login();
			}
		});
		/** 注册 **/
		txt_regier.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View arg0) {
				Intent intent = new Intent(ValueUtil.activityIndex,RegierActivity.class);
				startActivity(intent);
			}
		});
		
	}
	/**
	 * 锟斤拷始锟斤拷UI
	 */
	private void initView() {
		edt_username = (EditText) findViewById(R.id.edt_username);
		edt_password = (EditText) findViewById(R.id.edt_password);
		btn_enter = (Button) findViewById(R.id.btn_enter);
		txt_regier = (TextView) findViewById(R.id.txt_regier);
		txt_title_no = (TextView) findViewById(R.id.txt_title_no);
	}
	
	
	/**
	 * 登录
	 */
	private void login() {
		strName = edt_username.getText().toString().trim();
		strPwd = edt_password.getText().toString().trim();
		

		final CallbackSuccess callbackSuccess = new CallbackSuccess() {
			@Override
			public void doCallback(MyVoParent msg) {
				otherHandlker(LOAD_SUCCESS);
				mLoginSuccess = (MsgLoginUser) msg;
				ValueUtil.getSystemSetting().loginSuccess(mLoginSuccess.getVoUser(), strName, strPwd);
			}
		};
		String url = UrlAndParms.url_login;
		List<String[]> params_l;
		try {
			params_l = UrlAndParms.parms_login(strName, strPwd);
		} catch (Exception e) {
			e.printStackTrace();
			return;
		}
		LoadUrlUtil loadUrlUtil = new LoadUrlUtil(this, url, params_l);
		loadUrlUtil.beginAccessUrl(callbackSuccess, null, MsgLoginUser.class,
				new WaitPopupUtil(this, null));
	
		
		
	}
	public void otherHandlker(int what) {
		Message m = new Message();
		m.what = what;
		handler.sendMessage(m);
	}

	@SuppressLint("HandlerLeak")
	Handler handler = new Handler() {
		@Override
		public void handleMessage(Message msg) {// handler接收到消息后就会执行此方法
			switch (msg.what) {
			case LOAD_SUCCESS:
				Intent intent = new Intent(ValueUtil.activityIndex,MainActivity.class);
				startActivity(intent);
				finish();
				break;
			case LOGIN_FAIL:
				break;
			}
			super.handleMessage(msg);
		}
	}; 
	
	
	
	@Override
	protected void onResume() {
		super.onResume();
		ValueUtil.activityIndex = this ;
	}




	private EditText edt_username ;
	private EditText edt_password;
	private Button btn_enter;
	private TextView txt_regier ;
	private TextView txt_title_no;
	private String strPwd;
	private String strName ;
	private final static int LOAD_SUCCESS = 1;
	private final static int LOGIN_FAIL = 3;
	
	private MsgLoginUser mLoginSuccess;
}
