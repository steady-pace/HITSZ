package com.Lyra.View;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.Window;
import android.view.View.OnClickListener;
import android.view.ViewGroup.LayoutParams;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.Lyra.Course.CourseMainActivity;
import com.Lyra.Course.R;
import com.Lyra.Util.ValueUtil;

/***
 * 主页面 类似于九宫格 但使用的是linearlayout 
 * 一行三个数据
 * 命名有些不规范 多担待 _	Lyra
 * @author Lyra_Phoenix
 *
 */
public class MainActivity extends Activity{
	
	/** 第1行的各个数据 **/
	private LinearLayout linLayout1;
	/** 第2行的各个数据 **/
	private LinearLayout linLayout2;
	/** 第3行的各个数据 **/
	private LinearLayout linLayout3;
	
	private LayoutParams lp ;
	private DisplayMetrics dm ;
	private int screenWidth ;
	
	/** title **/
	private TextView txt_title_no;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		this.requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.main);
		dm = new DisplayMetrics();  
	    getWindowManager().getDefaultDisplay().getMetrics(dm); 
	    screenWidth = dm.widthPixels; 
	    init();
	}
	/**
	 * 初始化
	 */
	private void init() {
		initView();
		initViewData1();
		initViewData2();
		//initViewData3();
	}
	/**
	 *   
	 */
	private void initView() {
		txt_title_no = (TextView) findViewById(R.id.txt_title_no);
		linLayout1 = (LinearLayout) findViewById(R.id.lin_view1);
		linLayout2 = (LinearLayout) findViewById(R.id.lin_view2);
		linLayout3 = (LinearLayout) findViewById(R.id.lin_view3);
		
		txt_title_no.setText("校园行");
	}
	/**
	 * 初始化第一行的三个数据
	 */
	private void initViewData1() {
		lp = linLayout1.getLayoutParams();
		lp.width = screenWidth;
		lp.height = screenWidth/3 ;
		
		linLayout1.addView(initItem(R.drawable.course, "我的课表", new OnClickListener() {
			@Override
			public void onClick(View arg0) {
				startActivity(new Intent(ValueUtil.activityIndex,CourseMainActivity.class));
			}
		}));
		linLayout1.addView(initItem(R.drawable.groupaction, "社团活动", new OnClickListener() {
			@Override
			public void onClick(View arg0) {
				startActivity(new Intent(ValueUtil.activityIndex,GroupActionActivity.class));
				//toast("正在开发");
			}
		}));
		linLayout1.addView(initItem(R.drawable.losegoods, "拾物招领", new OnClickListener() {
			@Override
			public void onClick(View arg0) {
				startActivity(new Intent(ValueUtil.activityIndex,SWZhaoLActivity.class));
				//toast("正在开发");
			}
		}));
		
	}
	/**
	 * 初始化第二行的三个数据
	 */
	private void initViewData2() {
		lp = linLayout2.getLayoutParams();
		lp.width = screenWidth;
		lp.height = screenWidth/3 ;
		
		linLayout2.addView(initItem(R.drawable.news, "校园新闻", new OnClickListener() {
			@Override
			public void onClick(View arg0) {
				startActivity(new Intent(ValueUtil.activityIndex,SchoolNewsListActivity.class));
			}
		}));
		linLayout2.addView(initItem(R.drawable.newstudy, "新生指南", new OnClickListener() {
			@Override
			public void onClick(View arg0) {
				startActivity(new Intent(ValueUtil.activityIndex,NewStudyActivity.class));
			}
		}));
		linLayout2.addView(initItem(R.drawable.news, "寻找失物", new OnClickListener() {
			@Override
			public void onClick(View arg0) {
				startActivity(new Intent(ValueUtil.activityIndex,XZShiWActivity.class));
			}
		}));
		
	}
	/**
	 * 初始化第二行的三个数据
	 */
	private void initViewData3() {
		lp = linLayout2.getLayoutParams();
		lp.width = screenWidth;
		lp.height = screenWidth/3 ;
		
		linLayout3.addView(initItem(R.drawable.group, "社团资料", new OnClickListener() {
			@Override
			public void onClick(View arg0) {
				toast("正在开发");
			}
		}));
		
		
		
	}
	
	
	
	private void toast(String text){
		
		Toast.makeText(getApplicationContext(), text, Toast.LENGTH_SHORT).show();
	}
	
	
	
	/**
	 * item
	 * @param myTask：图标 ：R.drawable.my_task
	 * @param title：item的名字
	 * @param activity ：需要跳转的activity
	 * @return
	 */
	private View initItem(int myTask ,String title,OnClickListener clickListener){
		final View viewOrder = LayoutInflater.from(getApplicationContext())
				.inflate(R.layout.grid_view, null);	

		TextView view_pic = (TextView) viewOrder
				.findViewById(R.id.txt_view_img);
		TextView view_title = (TextView) viewOrder
				.findViewById(R.id.txt_view_title);
		if(myTask != -1){
			view_pic.setBackgroundResource(myTask);
		}
		view_title.setText(title);
		viewOrder.setOnClickListener(clickListener);
		//此处是设置item的大小
		LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(screenWidth/3,screenWidth/3);
		//lp.setMargins(10, 0, 10, 0);
		viewOrder.setLayoutParams(lp);
		return viewOrder;
	}
	
	@Override
	protected void onResume() {
		ValueUtil.activityIndex = this ;
		super.onResume();
	}
	
	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		if (keyCode == KeyEvent.KEYCODE_BACK && event.getRepeatCount() == 0) {
			ValueUtil.eixt(this);
			return true;
		}
		return true;
	}
	
}
