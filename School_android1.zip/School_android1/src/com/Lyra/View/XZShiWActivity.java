package com.Lyra.View;

import java.util.List;

import android.annotation.SuppressLint;
import android.app.ActionBar.LayoutParams;
import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.Lyra.Course.R;
import com.Lyra.Util.ToastUtil;
import com.Lyra.Util.ValueUtil;
import com.Lyra.Util.WaitPopupUtil;
import com.Lyra.Vo.VoLoseGoods;
import com.Lyra.VoWeb.LoadUrlUtil;
import com.Lyra.VoWeb.LoadUrlUtil.CallbackSuccess;
import com.Lyra.VoWeb.MsgLoseGoods;
import com.Lyra.VoWeb.MyVoParent;
import com.Lyra.VoWeb.UrlAndParms;

public class XZShiWActivity extends Activity{

	
	/** 返回按钮 **/
	private LinearLayout lin_back;
	/**  当前页面的title -UI**/
	private TextView txt_name;
	
	private MsgLoseGoods msgLoseGoods ;
	private LinearLayout lin_get;
	
	private final static int LOAD_SUCCESS = 1;
	private final static int LOAD_FAILD = 2;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.getgoods);
		init();
	}

	private void init() {
		initTitle("寻找失物");
		lin_get = (LinearLayout) findViewById(R.id.lin_get);
		SWZhaoL();
	}
	
	private void SWZhaoL() {
		final CallbackSuccess callbackSuccess = new CallbackSuccess() {
			@Override
			public void doCallback(MyVoParent msg) {
				msgLoseGoods = (MsgLoseGoods) msg;
				otherHandlker(LOAD_SUCCESS);
			}
		};
		String url = UrlAndParms.url_XZ;
		List<String[]> params_l;
		try {
			params_l = UrlAndParms.parms_doGetforlose();
		} catch (Exception e) {
			e.printStackTrace();
			return;
		}
		LoadUrlUtil loadUrlUtil = new LoadUrlUtil(this, url, params_l);
		loadUrlUtil.beginAccessUrl(callbackSuccess, null, MsgLoseGoods.class,
				new WaitPopupUtil(this, null));
		
	}
	
	
	
	public void otherHandlker(int what) { 
		Message m = new Message();
		m.what = what;
		handler.sendMessage(m);
	}

	
	
	@SuppressLint("HandlerLeak") 
	Handler handler = new Handler() {
		@Override
		public void handleMessage(Message msg) {// handler接收到消息后就会执行此方法
			switch (msg.what) {
			case LOAD_SUCCESS:
				for(int i = 0 ;i < msgLoseGoods.getLoseGoods().size() ; i++){
					//final int index = i ;
					lin_get.addView(initItem(msgLoseGoods.getLoseGoods().get(i), new OnClickListener() {
						@Override
						public void onClick(View arg0) {
							//Intent intent = new Intent(ValueUtil.activityIndex, SchoolNewsActivity.class);
							//startActivity(intent);
						}
					}));
				}
				break;
			case LOAD_FAILD:
				break;
			}
			super.handleMessage(msg);
		}
	};
	
	
	
	
	@SuppressLint("InlinedApi") @SuppressWarnings("deprecation")
	private View initItem(VoLoseGoods voLoseGoods,OnClickListener clickListener){
		final View viewOrder = LayoutInflater.from(getApplicationContext())
				.inflate(R.layout.losegoods_item, null);	
		TextView view_title = (TextView) viewOrder
				.findViewById(R.id.txt_name);
		TextView view_info = (TextView) viewOrder
				.findViewById(R.id.txt_info);
		TextView view_lianxi = (TextView) viewOrder
				.findViewById(R.id.txt_lianxi);
		view_title.setText(voLoseGoods.getF_lType());
		view_info.setText(voLoseGoods.getF_lDescribe());
		view_lianxi.setText("联系方式："+voLoseGoods.getF_lPhone());
		
		LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(LayoutParams.FILL_PARENT,LayoutParams.WRAP_CONTENT);
		lp.setMargins(10, 10, 10, 10);
		viewOrder.setLayoutParams(lp);
		
		viewOrder.setOnClickListener(clickListener);
		//此处是设置item的大小
		return viewOrder;
	}
	
	private void initTitle(String strName) {
		lin_back = (LinearLayout) findViewById(R.id.lin_back);
		lin_back.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View arg0) {
				finish();
			}
		});
		txt_name = (TextView) findViewById(R.id.txt_name);
		txt_name.setText(strName);
	}
	
	@Override
	protected void onResume() {
		ValueUtil.activityIndex = this ;
		super.onResume();
	}
	
	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		if (keyCode == KeyEvent.KEYCODE_BACK && event.getRepeatCount() == 0) {
			ValueUtil.activityIndex.finish();
			return true;
		}
		return true;
	}

}
