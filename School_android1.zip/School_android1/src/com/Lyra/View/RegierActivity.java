package com.Lyra.View;

import java.util.List;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;

import com.Lyra.Course.R;
import com.Lyra.Util.ToastUtil;
import com.Lyra.Util.ValueUtil;
import com.Lyra.Util.WaitPopupUtil;
import com.Lyra.VoWeb.LoadUrlUtil;
import com.Lyra.VoWeb.LoadUrlUtil.CallbackSuccess;
import com.Lyra.VoWeb.MyVoParent;
import com.Lyra.VoWeb.UrlAndParms;

public class RegierActivity extends Activity{

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.regier);
		init();
	}
	/**
 	*初始化
 	*/
	private void init() {
		initView();
		initData();
	}
	/**
	 * 初始化数据
	 */
	private void initData() {
		
	}
	/**
	 * 初始化UI
	 */
	private void initView() {
		edt_regiername = (EditText) findViewById(R.id.edt_regiername);
		edt_regierno = (EditText) findViewById(R.id.edt_regierno);
		edt_regierpwd = (EditText) findViewById(R.id.edt_regierpwd);
		edt_regierpwd_again = (EditText) findViewById(R.id.edt_regierpwd_again);
		edt_sex = (EditText) findViewById(R.id.edt_sex);
		edt_email = (EditText) findViewById(R.id.edt_email);
		
		btn_regier = (Button) findViewById(R.id.btn_regier);
		btn_regier.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View arg0) {
				register();
			}
		});
		
	}
	/**
	 * 注册
	 */
	private void register() {
		/** 用户名 **/
		String userName = edt_regiername.getText().toString().trim();
		/** 密码 **/
		String userPwd = edt_regierpwd.getText().toString().trim();
		/** 重复密码 **/
		String userPwdAgain = edt_regierpwd_again.getText().toString().trim();
		/** 学号 **/
		String userNo = edt_regierno.getText().toString().trim();
		/** 性别 **/
		String userSex = edt_sex.getText().toString().trim();
		/** 邮箱 **/
		String userEmail = edt_email.getText().toString().trim();
		if(userPwd.length()<6 ||userPwdAgain.length()<6){
			ToastUtil.makeToast(getApplicationContext(), "密码长度要大于6位！！！");
			return;
		}
		
		if(!userPwd.equals(userPwdAgain)){
			ToastUtil.makeToast(getApplicationContext(), "两次输入的密码不一致！！");
			return;
		}
		
		final CallbackSuccess callbackSuccess = new CallbackSuccess() {
			@Override
			public void doCallback(MyVoParent msg) {
				otherHandlker(LOAD_SUCCESS);
			}
		};
		String url = UrlAndParms.url_register;
		List<String[]> params_l;
		try {
			params_l = UrlAndParms.parms_register(userName, userPwd, userNo, userSex, userEmail);
		} catch (Exception e) {
			e.printStackTrace();
			return;
		}
		LoadUrlUtil loadUrlUtil = new LoadUrlUtil(this, url, params_l);
		loadUrlUtil.beginAccessUrl(callbackSuccess, null, MyVoParent.class,
				new WaitPopupUtil(this, null));
		
	}
	
	public void otherHandlker(int what) {
		Message m = new Message();
		m.what = what;
		handler.sendMessage(m);
	}

	@SuppressLint("HandlerLeak")
	Handler handler = new Handler() {
		@Override
		public void handleMessage(Message msg) {// handler接收到消息后就会执行此方法
			switch (msg.what) {
			case LOAD_SUCCESS:
				ToastUtil.makeToast(getApplicationContext(), "您已注册成功，请登录！");
				ValueUtil.activityIndex.finish();
				startActivity(new Intent(ValueUtil.activityIndex,LoginActivity.class));
				break;
			case LOGIN_FAIL:
				break;
			}
			super.handleMessage(msg);
		}
	};
	
	
	@Override
	protected void onResume() {
		ValueUtil.activityIndex = this ;
		super.onResume();
	}

	/** 真实姓名 **/
	private EditText edt_regiername;
	/** 学号 **/
	private EditText edt_regierno;
	/** 密码 **/
	private EditText edt_regierpwd;
	/** 重复密码 **/
	private EditText edt_regierpwd_again;
	/** 性别 **/
	private EditText edt_sex;
	/** 邮箱 **/
	private EditText edt_email;
	/** 提交 **/
	private Button btn_regier;
	
	
	private final static int LOAD_SUCCESS = 1;
	private final static int LOGIN_FAIL = 3;
}
