package com.Lyra.View;

import java.util.List;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.Lyra.Course.R;
import com.Lyra.Util.IntentUtil;
import com.Lyra.Util.ToastUtil;
import com.Lyra.Util.ValueUtil;
import com.Lyra.Util.WaitPopupUtil;
import com.Lyra.Vo.VoGroupAction;
import com.Lyra.VoWeb.LoadUrlUtil;
import com.Lyra.VoWeb.LoadUrlUtil.CallbackSuccess;
import com.Lyra.VoWeb.MsgGroupAction;
import com.Lyra.VoWeb.MyVoParent;
import com.Lyra.VoWeb.UrlAndParms;

public class GroupActionDetailActivity extends Activity{

	/** 返回按钮 **/
	private LinearLayout lin_back;
	/**  当前页面的title -UI**/
	private TextView txt_name;
	
	private MyVoParent myVoParent;
	private MsgGroupAction msgGroupAction ;
	private String title;
	private String groupActionId ;
	
	private TextView view_zan ;// 赞
	private TextView view_hit ;// 批
	private TextView action_detail_info ; // 信息
	private TextView action_detail_group ; // 社团名字
	private TextView action_detail_zanzhu ; // 赞助
	private TextView action_detail_begin ; // 开始
	private TextView action_detail_end ; // 结束
	private TextView action_detail_address ; // 地点
	private TextView action_detail_perple ; // 发布人员
	
	private final static int LOAD_SUCCESS = 1;
	private final static int ZAN_SUCCESS = 3;
	private final static int HIT_SUCCESS = 4;
	private final static int LOAD_FAILD = 2;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.gactiondetail);
		
		Bundle b = getIntent().getExtras();
		title = b.getString(IntentUtil.groupActionTitle);
		groupActionId = b.getString(IntentUtil.groupActionId);
		//ToastUtil.makeToast(getApplicationContext(), groupActionId);
		init();
	}

	private void init() {
		initTitle(title);
		initView();
		groupActionById();
	}
	
	
	private void groupActionById() {
		final CallbackSuccess callbackSuccess = new CallbackSuccess() {
			@Override
			public void doCallback(MyVoParent msg) {
				msgGroupAction = (MsgGroupAction) msg;
				otherHandlker(LOAD_SUCCESS);
			}
		};
		String url = UrlAndParms.url_GAID;
		List<String[]> params_l;
		try {
			params_l = UrlAndParms.parms_doGroupactionById(groupActionId);
		} catch (Exception e) {
			e.printStackTrace();
			return;
		}
		LoadUrlUtil loadUrlUtil = new LoadUrlUtil(this, url, params_l);
		loadUrlUtil.beginAccessUrl(callbackSuccess, null, MsgGroupAction.class,
				new WaitPopupUtil(this, null));
	}

	public void otherHandlker(int what) { 
		Message m = new Message();
		m.what = what;
		handler.sendMessage(m);
	}

	@SuppressLint("HandlerLeak") 
	Handler handler = new Handler() {
		@Override
		public void handleMessage(Message msg) {// handler接收到消息后就会执行此方法
			switch (msg.what) {
			case LOAD_SUCCESS:
				doputInfo(msgGroupAction.getAction().get(0));
				break;
			case ZAN_SUCCESS:
				ToastUtil.makeToast(getApplicationContext(), myVoParent.data);
				break;
			case HIT_SUCCESS:
				ToastUtil.makeToast(getApplicationContext(), myVoParent.data);
				break;
			case LOAD_FAILD:
				break;
			}
			super.handleMessage(msg);
		}
	};
	
	
	private void doputInfo(VoGroupAction voGroupAction){
		view_zan.setText("赞  "+voGroupAction.getF_gaZan()) ;
		view_hit.setText("批  "+voGroupAction.getF_gaHit()) ; 
		action_detail_info.setText(voGroupAction.getF_gaInfo()) ; 
		action_detail_group.setText(voGroupAction.getF_gaName()) ; 
		action_detail_zanzhu.setText(voGroupAction.getF_gaSponsors()) ; 
		action_detail_begin.setText(voGroupAction.getF_gaBegin()) ; 
		action_detail_end.setText(voGroupAction.getF_gaEnd()) ;
		action_detail_address.setText(voGroupAction.getF_gaAddress()) ;
		action_detail_perple.setText(voGroupAction.getF_gaPublic()) ;
		
	}
	
	private void initView() {
		action_detail_info = (TextView) findViewById(R.id.action_detail_info);
		action_detail_group = (TextView) findViewById(R.id.action_detail_group);
		action_detail_zanzhu = (TextView) findViewById(R.id.action_detail_zanzhu);
		action_detail_begin = (TextView) findViewById(R.id.action_detail_begin);
		action_detail_end = (TextView) findViewById(R.id.action_detail_end);
		action_detail_address = (TextView) findViewById(R.id.action_detail_address);
		action_detail_perple = (TextView) findViewById(R.id.action_detail_perple);
		view_zan = (TextView) findViewById(R.id.action_zan);
		view_zan.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View arg0) {
				giveZan();
			}
		});
		view_hit = (TextView) findViewById(R.id.action_hit);
		view_hit.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View arg0) {
				givePi();
			}
		});
	}
	private void givePi() {
		final CallbackSuccess callbackSuccess = new CallbackSuccess() {
			@Override
			public void doCallback(MyVoParent msg) {
				myVoParent = (MyVoParent) msg;
				otherHandlker(HIT_SUCCESS);
			}
		};
		String url = UrlAndParms.url_GAHit;
		List<String[]> params_l;
		try {
			params_l = UrlAndParms.parms_doGivehit(groupActionId);
		} catch (Exception e) {
			e.printStackTrace();
			return;
		}
		LoadUrlUtil loadUrlUtil = new LoadUrlUtil(this, url, params_l);
		loadUrlUtil.beginAccessUrl(callbackSuccess, null, MyVoParent.class,
				new WaitPopupUtil(this, null));
	}
	
	private void giveZan() {
		final CallbackSuccess callbackSuccess = new CallbackSuccess() {
			@Override
			public void doCallback(MyVoParent msg) {
				myVoParent = (MyVoParent) msg;
				otherHandlker(ZAN_SUCCESS);
			}
		};
		String url = UrlAndParms.url_GAZan;
		List<String[]> params_l;
		try {
			params_l = UrlAndParms.parms_doGivegood(groupActionId);
		} catch (Exception e) {
			e.printStackTrace();
			return;
		}
		LoadUrlUtil loadUrlUtil = new LoadUrlUtil(this, url, params_l);
		loadUrlUtil.beginAccessUrl(callbackSuccess, null, MyVoParent.class,
				new WaitPopupUtil(this, null));
	}

	private void initTitle(String strName) {
		lin_back = (LinearLayout) findViewById(R.id.lin_back);
		lin_back.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View arg0) {
				finish();
			}
		});
		txt_name = (TextView) findViewById(R.id.txt_name);
		txt_name.setText(strName);
	}
	
	
	@Override
	protected void onResume() {
		ValueUtil.activityIndex = this ;
		super.onResume();
	}
	
	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		if (keyCode == KeyEvent.KEYCODE_BACK && event.getRepeatCount() == 0) {
			ValueUtil.activityIndex.finish();
			return true;
		}
		return true;
	}
}
