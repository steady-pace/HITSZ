/**
 * 
 */
package com.Lyra.View;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.Lyra.Course.R;
import com.Lyra.Util.IntentUtil;
import com.Lyra.Util.ValueUtil;

/**
 * ~(+>.<+)~
 * 新生指南
 *@author Administrator
 *
 */
public class NewStudyActivity extends Activity{

	private LinearLayout lin_view_newinfo ;
	/** 返回按钮 **/
	private LinearLayout lin_back;
	/**  当前页面的title **/
	private TextView txt_name;
	
	/** 新生指南的全部项目 因为偷懒就用数组方式解决 **/
	private String[] newStuInfo = { "入学须知", "入学教育", "学习攻略" , "校园文化", "生活宝典"};
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.newstudy);
		init();
	}

	/**
	 * 
	 */
	private void init() {
		initTitle();
		initUI();
	}

	/**
	 * 
	 */
	private void initUI() {
		lin_view_newinfo = (LinearLayout) findViewById(R.id.lin_view_newinfo);
		int arrLen = newStuInfo.length ;
		for(int i = 0;i < arrLen ;i ++  ){
			final String itemtitle = newStuInfo[i] ;
			lin_view_newinfo.addView(initItem(itemtitle, new OnClickListener() {
				@Override
				public void onClick(View arg0) {
					Intent intent = new Intent(ValueUtil.activityIndex,NSInfoActivity.class);
					intent.putExtra(IntentUtil.name, itemtitle);
					startActivity(intent);
				}
			}));
		}
	}
	
	
	/**
	 * 
	 */
	private void initTitle() {
		lin_back = (LinearLayout) findViewById(R.id.lin_back);
		lin_back.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View arg0) {
				finish();
			}
		});
		txt_name = (TextView) findViewById(R.id.txt_name);
		txt_name.setText("新生指南");
	}
	
	
	
	/**
	 * item
	 * @param myTask：图标 ：R.drawable.my_task
	 * @param title：item的名字
	 * @param activity ：需要跳转的activity
	 * @return
	 */
	private View initItem(String title,OnClickListener clickListener){
		final View viewOrder = LayoutInflater.from(getApplicationContext())
				.inflate(R.layout.newstudy_view, null);	
		TextView view_title = (TextView) viewOrder
				.findViewById(R.id.txt_title);
		view_title.setText(title);
		viewOrder.setOnClickListener(clickListener);
		//此处是设置item的大小
		return viewOrder;
	}


	@Override
	protected void onResume() {
		super.onResume();
		ValueUtil.activityIndex = this ;
	}
	
	

}
