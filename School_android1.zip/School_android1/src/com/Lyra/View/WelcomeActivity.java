package com.Lyra.View;



import java.util.List;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.graphics.drawable.AnimationDrawable;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.Window;
import android.widget.ImageView;

import com.Lyra.Course.R;
import com.Lyra.Util.ValueUtil;
import com.Lyra.Util.WaitPopupUtil;
import com.Lyra.VoWeb.LoadUrlUtil;
import com.Lyra.VoWeb.LoadUrlUtil.CallbackSuccess;
import com.Lyra.VoWeb.MsgLoginUser;
import com.Lyra.VoWeb.MyVoParent;
import com.Lyra.VoWeb.UrlAndParms;



public class WelcomeActivity extends Activity {
	private AnimationDrawable splashDrawable;
	MediaPlayer mp = new MediaPlayer();

	private String strPwd;
	private String strName ;
	private final static int LOAD_SUCCESS = 1;
	private final static int LOGIN_FAIL = 3;
	
	private MsgLoginUser mLoginSuccess;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		this.requestWindowFeature(Window.FEATURE_NO_TITLE);
		super.onCreate(savedInstanceState);
		setContentView(R.layout.welcome);
		ValueUtil.activityIndex = this;
		ValueUtil.initSystemData(this);
		new Handler().postDelayed(new Runnable() {
			@Override
			public void run() {
				ImageView imageView = (ImageView) findViewById(R.id.img_anim);
				splashDrawable = (AnimationDrawable) imageView.getDrawable();
				splashDrawable.start();
				login() ;
			}
		}, 50);
	}

	protected void Action() { 
		new Handler().postDelayed(new Runnable() {
			@Override
			public void run() {
				Intent mainIntent = new Intent(
						WelcomeActivity.this, LoginActivity.class);
				WelcomeActivity.this.startActivity(mainIntent);
				WelcomeActivity.this.finish();
			}
		}, 2000);
	}
	

	/**
	 * 登录
	 */
	private void login() {
		// 获取用户名
		strName = ValueUtil.getSystemSetting().getUserInfo().getF_uName();
		// 获取密码
		strPwd = ValueUtil.getSystemSetting().getUserInfo().getF_uPw();
		
		if (strName.equals("")
				|| strPwd.equals("")) {
			Action();
		}else{
			final CallbackSuccess callbackSuccess = new CallbackSuccess() {
				@Override
				public void doCallback(MyVoParent msg) {
					otherHandlker(LOAD_SUCCESS);
					mLoginSuccess = (MsgLoginUser) msg;
					ValueUtil.getSystemSetting().loginSuccess(mLoginSuccess.getVoUser(), strName, strPwd);
				}
			};
			String url = UrlAndParms.url_login;
			List<String[]> params_l;
			try {
				params_l = UrlAndParms.parms_login(strName, strPwd);
			} catch (Exception e) {
				e.printStackTrace();
				return;
			}
			LoadUrlUtil loadUrlUtil = new LoadUrlUtil(this, url, params_l);
			loadUrlUtil.beginAccessUrl(callbackSuccess, null, MsgLoginUser.class,
					new WaitPopupUtil(this, null));
		
		}
		
	}
	public void otherHandlker(int what) {
		Message m = new Message();
		m.what = what;
		handler.sendMessage(m);
	}

	@SuppressLint("HandlerLeak")
	Handler handler = new Handler() {
		@Override
		public void handleMessage(Message msg) {// handler接收到消息后就会执行此方法
			switch (msg.what) {
			case LOAD_SUCCESS:
				Intent intent = new Intent(ValueUtil.activityIndex,MainActivity.class);
				startActivity(intent);
				finish();
				break;
			case LOGIN_FAIL:
				break;
			}
			super.handleMessage(msg);
		}
	};
	
	
	
	
	
	
	
	
	@Override
	protected void onResume() {
		super.onResume();
		ValueUtil.activityIndex = this;
	}
}
