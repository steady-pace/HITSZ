/**
 * 
 */
package com.Lyra.View;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.Lyra.Course.R;
import com.Lyra.Util.IntentUtil;
import com.Lyra.Util.ToastUtil;
import com.Lyra.Util.ValueUtil;

/**
 * 新生指南的具体条款 
 * @author Lyra
 *
 */
public class NSInfoActivity extends Activity{

	private LinearLayout lin_view_newinfoma ;
	/** 返回按钮 **/
	private LinearLayout lin_back;
	/**  当前页面的title -UI**/
	private TextView txt_name;
	/**  当前页面的title -string**/
	private String strName;
	
	private String folderName;
	
	/** 创建数据数组 **/
	/** 数组分为中文和英文 中文是用来显示的 英文是用来读取文件时用的 **/
	/** 入学须知 -CN **/
	private String[] newStuknow_cn = { "信息咨询", "各项费用", "报道交通" , "报道流程", "奖助学金", "其他"};
	/** 入学须知-EN **/
	private String[] newStuknow_en = { "askInfo", "allexpenses", "traffic" , "reporting", "grants", "other"};
	/** 入学教育-CN **/
	private String[] education_cn = {"新生军训","入学考试"} ;
	/** 入学教育-EN **/
	private String[] education_en = {"training","exam"} ;
	/** 学习攻略-CN **/
	private String[] learning_cn = {"课务","学业"} ;
	/** 学习攻略-EN **/
	private String[] learning_en = {"course","academic"} ;
	/** 校园文化-CN **/
	private String[] culture_cn = {"文化品牌","精品活动","学生组织","校园社团"} ;
	/** 校园文化-EN **/
	private String[] culture_en = {"culture","action","stuorg","campus"} ;
	/** 生活宝典-CN **/
	private String[] lifeturns_cn = {"通讯","住宿","场馆","餐饮","购物","娱乐","旅游","其他"} ;
	/** 生活宝典-EN **/
	private String[] lifeturns_en = {"message","stay","feild","food","shopping","enjoy","travel","other"} ;
	

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.newstudyinfo);
		Bundle b = getIntent().getExtras();
		strName = b.getString(IntentUtil.name);
		init();
		
	}

	/**
	 * 
	 */
	private void init() {
		initTitle();
		initUI();
		
	}
	
	/**
	 * 
	 */
	private void initUI() {
		lin_view_newinfoma = (LinearLayout) findViewById(R.id.lin_view_newinfoma);
		
		if(strName.equals("入学须知")){
			int arrLen = newStuknow_cn.length ;
			folderName = "information" ;
			for(int i = 0;i < arrLen ;i ++  ){
				final String itemtitle_en  = newStuknow_en[i] ;
				final String itemtitle_cn = newStuknow_cn[i] ;
				
				lin_view_newinfoma.addView(initItem(itemtitle_cn, new OnClickListener() {
					@Override
					public void onClick(View arg0) {
						gotoActivity(itemtitle_en,folderName,itemtitle_cn);
					}
				}));
			}
		}else if(strName.equals("入学教育")){
			int arrLen = education_cn.length ;
			folderName = "education";
			for(int i = 0;i < arrLen ;i ++  ){
				final String itemtitle_en  = education_en[i] ;
				final String itemtitle_cn = education_cn[i] ;
				lin_view_newinfoma.addView(initItem(itemtitle_cn, new OnClickListener() {
					@Override
					public void onClick(View arg0) {
						gotoActivity(itemtitle_en,folderName,itemtitle_cn);
					}
				}));
			}
		}else if(strName.equals("学习攻略")){
			int arrLen = learning_cn.length ;
			folderName = "learning";
			for(int i = 0;i < arrLen ;i ++  ){
				final String itemtitle_en  = learning_en[i] ;
				final String itemtitle_cn = learning_cn[i] ;
				lin_view_newinfoma.addView(initItem(itemtitle_cn, new OnClickListener() {
					@Override
					public void onClick(View arg0) {
						gotoActivity(itemtitle_en,folderName,itemtitle_cn);
					}
				}));
			}
		}else if(strName.equals("校园文化")){
			int arrLen = culture_cn.length ;
			folderName = "culture";
			for(int i = 0;i < arrLen ;i ++  ){
				final String itemtitle_en  = culture_en[i] ;
				final String itemtitle_cn = culture_cn[i] ;
				lin_view_newinfoma.addView(initItem(itemtitle_cn, new OnClickListener() {
					@Override
					public void onClick(View arg0) {
						gotoActivity(itemtitle_en,folderName,itemtitle_cn);
					}
				}));
			}
		}else if(strName.equals("生活宝典")){
			int arrLen = lifeturns_cn.length ;
			folderName = "lifeturns";
			for(int i = 0;i < arrLen ;i ++  ){
				final String itemtitle_en  = lifeturns_en[i] ;
				final String itemtitle_cn = lifeturns_cn[i] ;
				lin_view_newinfoma.addView(initItem(itemtitle_cn, new OnClickListener() {
					@Override
					public void onClick(View arg0) {
						gotoActivity(itemtitle_en,folderName,itemtitle_cn);
					}
				}));
			}
		}
	}

	
	private void gotoActivity(String string,String folderName,String itemtitle_cn){
		ToastUtil.makeToast(getApplicationContext(), string+folderName);
		Intent intent = new Intent(ValueUtil.activityIndex,NSInfoDetail.class);
		intent.putExtra(IntentUtil.txtname, string);
		intent.putExtra(IntentUtil.folderName, folderName);
		intent.putExtra(IntentUtil.titlename, itemtitle_cn);
		startActivity(intent);
	}
	
	
	/**
	 * item
	 * @param myTask：图标 ：R.drawable.my_task
	 * @param title：item的名字
	 * @param activity ：需要跳转的activity
	 * @return
	 */
	private View initItem(String title,OnClickListener clickListener){
		final View viewOrder = LayoutInflater.from(getApplicationContext())
				.inflate(R.layout.newstudyinfo_view, null);	
		TextView view_title = (TextView) viewOrder
				.findViewById(R.id.txtinfo_title);
		view_title.setText(title);
		viewOrder.setOnClickListener(clickListener);
		//此处是设置item的大小
		return viewOrder;
	}

	
	
	
	private void initTitle() {
		lin_back = (LinearLayout) findViewById(R.id.lin_back);
		lin_back.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View arg0) {
				finish();
			}
		});
		txt_name = (TextView) findViewById(R.id.txt_name);
		txt_name.setText(strName);
	}

	@Override
	protected void onResume() {
		ValueUtil.activityIndex = this;
		super.onResume();
	}
	

}
