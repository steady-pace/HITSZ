package com.Lyra.View;

import com.Lyra.Course.R;
import com.Lyra.Util.IntentUtil;
import com.Lyra.Util.ValueUtil;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebSettings.LayoutAlgorithm;
import android.widget.LinearLayout;
import android.widget.TextView;
/***
 * 新闻页
 * @author Lyra_Phoenix
 *
 */
public class SchoolNewsActivity extends Activity{

	private WebView myWeb ;
	private String newsUrl ;
	private String newsTitle ;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.schoolnews);
		Bundle b = getIntent().getExtras();
		newsUrl = b.getString(IntentUtil.newsUrl);
		newsTitle = b.getString(IntentUtil.newsTitle);
		init();
	}

	private void init() {
		initTitle(newsTitle);
		initWeb();
	}
	
	
	private void initWeb() {
		myWeb = (WebView) findViewById(R.id.myweb);
		myWebView();
	}

	/**
	 * 
	 */
	@SuppressLint("SetJavaScriptEnabled") 
	private void myWebView() {
		String strURL ="http://" + newsUrl ;
		myWeb.setWebViewClient(new WebViewClient()
		{
			public boolean shouldOverrideUrlLoading(WebView view, String url)
            { 
				myWeb.loadUrl(url);
                    return false;
            }
		});
		WebSettings webSettings = myWeb.getSettings();
		webSettings.setUseWideViewPort(true); 
		webSettings.setLoadWithOverviewMode(true);
		webSettings.setJavaScriptEnabled(true);
		myWeb.getSettings().setLayoutAlgorithm(LayoutAlgorithm.SINGLE_COLUMN);
		myWeb.loadUrl(strURL); 
		
	}

	private void initTitle(String title) {
		LinearLayout lin_back = (LinearLayout) findViewById(R.id.lin_back);
		lin_back.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View arg0) {
				finish();
			}
		});
		TextView txt_name = (TextView) findViewById(R.id.txt_name);
		txt_name.setText(title);
	}
	
	
	@Override
	protected void onResume() {
		ValueUtil.activityIndex = this ;
		super.onResume();
	}
	
	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		if (keyCode == KeyEvent.KEYCODE_BACK && event.getRepeatCount() == 0) {
			ValueUtil.activityIndex.finish();
			return true;
		}
		return true;
	}
}
