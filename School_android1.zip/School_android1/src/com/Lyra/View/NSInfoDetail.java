/**
 * 
 */
package com.Lyra.View;

import java.io.IOException;
import java.io.InputStream;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.Lyra.Course.R;
import com.Lyra.Util.IntentUtil;
import com.Lyra.Util.TextReader;
import com.Lyra.Util.ToastUtil;

/**
 * 具体的条款信息 使用readTxt的方法实现
 * @author Lyra
 * 
 */
public class NSInfoDetail extends Activity{
	private TextView txt_detail;
	
	/** 返回按钮 **/
	private LinearLayout lin_back;
	/**  当前页面的title **/
	private TextView txt_name;
	/** 当前页面的名字 **/
	private String titleName ; 
	/** 索要读取文件存在的文件夹名字 **/
	private String folderName;
	/** 索要读取文件名字  **/
	private String txtName;
	
	private InputStream inputS1;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.detail);
		Bundle b = getIntent().getExtras();
		titleName = b.getString(IntentUtil.titlename);
		folderName = b.getString(IntentUtil.folderName);
		txtName= b.getString(IntentUtil.txtname);
		init();
	}
	/**
	 * 
	 */
	private void init() {
		initTitle();
		initUI();
	}
	/**
	 * 
	 */
	private void initUI() {
		txt_detail= (TextView) findViewById(R.id.txt_detail);
		try {
			inputS1 = this.getAssets().open("guide/"+folderName+"/"+txtName);
			txt_detail.setText(TextReader.getString(inputS1));
			ToastUtil.makeToast(getApplicationContext(), TextReader.getString(inputS1));
			
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		
		
	}
	
	
	
	/**
	 * 
	 */
	private void initTitle() {
		lin_back = (LinearLayout) findViewById(R.id.lin_back);
		lin_back.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View arg0) {
				finish();
			}
		});
		txt_name = (TextView) findViewById(R.id.txt_name);
		txt_name.setText(titleName);
	}
}
