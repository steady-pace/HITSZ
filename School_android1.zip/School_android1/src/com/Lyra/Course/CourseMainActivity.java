package com.Lyra.Course;

import java.text.SimpleDateFormat;
import java.util.Date;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ArrayAdapter;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

public class CourseMainActivity extends Activity {
	/** 返回按钮 **/
	private LinearLayout lin_back;
	/**  当前页面的title **/
	private TextView txt_name;
	/** 今天的日期 **/
	private TextView tv;
	/**  **/
	private ListView lv ;
    @SuppressLint("SimpleDateFormat") 
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE); //设置无标题
        setContentView(R.layout.maincourse);
        initTitle();
        init();
    }

	/**
	 * 
	 */
	private void initTitle() {
		lin_back = (LinearLayout) findViewById(R.id.lin_back);
		lin_back.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View arg0) {
				finish();
			}
		});
		txt_name = (TextView) findViewById(R.id.txt_name);
		txt_name.setText("我的课表");
	}

	/**
	 * 
	 */
	@SuppressLint("SimpleDateFormat") 
	private void init() {
		tv=(TextView)findViewById(R.id.day);
        Date now=new Date();
        SimpleDateFormat f=new SimpleDateFormat("yyyy年MM月dd日");
        tv.setText(f.format(now).toString());
        
        lv = (ListView)findViewById(R.id.ListView01);
        ArrayAdapter<String> aa = new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1, new String[]{getString(R.string.mon),getString(R.string.tue),getString(R.string.wed),getString(R.string.thu),getString(R.string.fri),getString(R.string.sat),getString(R.string.sun)});
        lv.setAdapter(aa);
        lv.setOnItemClickListener(new OnItemClickListener(){
			@Override
			public void onItemClick(AdapterView<?> arg0, View arg1, int arg2,
					long arg3) {
				Intent i=new Intent(CourseMainActivity.this,Day.class);
				i.putExtra("d", arg2);
				startActivity(i);
			}
        });
		
	}

}