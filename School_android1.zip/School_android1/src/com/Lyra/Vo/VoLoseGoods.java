package com.Lyra.Vo;


@SuppressWarnings("serial")
public class VoLoseGoods implements java.io.Serializable{
	private String f_lId;  //Id
	private String f_lType; //失物类型
	private String f_lDescribe; //失物特征描述
	private String f_lPhone; //失主的联系方式
	

	public String getF_lId() {
		return f_lId;
	}
	public void setF_lId(String fLId) {
		f_lId = fLId;
	}
	public String getF_lType() {
		return f_lType;
	}
	public void setF_lType(String fLType) {
		f_lType = fLType;
	}
	public String getF_lDescribe() {
		return f_lDescribe;
	}
	public void setF_lDescribe(String fLDescribe) {
		f_lDescribe = fLDescribe;
	}
	public String getF_lPhone() {
		return f_lPhone;
	}
	public void setF_lPhone(String fLPhone) {
		f_lPhone = fLPhone;
	}
	
}
