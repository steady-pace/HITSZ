package com.Yuanxu.BitmapCache;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Collections;
import java.util.Map;
import java.util.WeakHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import android.app.Activity;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.util.Log;
import android.widget.ImageView;
import android.widget.LinearLayout;

import com.Lyra.Course.R;
import com.Lyra.Util.ValueUtil;

public class ImageLoader {
	private MemoryCache memoryCache;
	private FileCache fileCache;
	private Map<ImageView, String> imageViews = Collections
			.synchronizedMap(new WeakHashMap<ImageView, String>());
	ExecutorService executorService;
	

	public ImageLoader(Context context,String filePath) {
		memoryCache = new MemoryCache();
		fileCache = new FileCache(context,filePath);
		executorService = Executors.newFixedThreadPool(5);
	}
	
	final int stub_id = R.drawable.defule_img;
	
	public void DisplayImage(String url, ImageView imageView,Integer yw,Context context) {
		Bitmap bitmap = memoryCache.get(url);
		if (bitmap != null){
			imageView.setImageBitmap(bitmap);
			if(yw != null){
				imageView.setLayoutParams(new LinearLayout.LayoutParams(yw, ValueUtil.getHeight(yw,bitmap.getWidth(), bitmap.getHeight())));  
			}
		}else {
			imageViews.put(imageView, url);
			queuePhoto(url, imageView,yw,context);
			imageView.setImageResource(stub_id);
		}
	}
	
	private void queuePhoto(String url, ImageView imageView,Integer yw,Context context) {
		PhotoToLoad p = new PhotoToLoad(url, imageView,yw,context);
		executorService.submit(new PhotosLoader(p));
	}

	private Bitmap getBitmap(String url) {
		File f = fileCache.getFile(url);
		Bitmap b = decodeFile(f);
		if (b != null)
			return b;
		try {
			Bitmap bitmap = null;
			URL imageUrl = new URL(url);
			HttpURLConnection conn = (HttpURLConnection) imageUrl
					.openConnection();
			conn.setConnectTimeout(30000);
			conn.setReadTimeout(30000);
			conn.setInstanceFollowRedirects(true);
			InputStream is = conn.getInputStream();
			OutputStream os = new FileOutputStream(f);
			CopyStream(is, os);
			os.close();
			bitmap = decodeFile(f);
			return bitmap;
		} catch (Exception ex) {
			ex.printStackTrace();
			System.out.println("��ȡͼƬ���?");
			System.out.println(ex.getMessage());
			return null;
		}
	}

	private Bitmap decodeFile(File f) {
		try {
			// decode image size
			BitmapFactory.Options o = new BitmapFactory.Options();
			o.inJustDecodeBounds = true;
			BitmapFactory.decodeStream(new FileInputStream(f), null, o);

			// Find the correct scale value. It should be the power of 2.
			final int REQUIRED_SIZE = ValueUtil.getScreenWidth();
			int width_tmp = o.outWidth, height_tmp = o.outHeight;
			int scale = 1;
			while (true) {
				if (width_tmp / 2 < REQUIRED_SIZE
						|| height_tmp / 2 < REQUIRED_SIZE)
					break;
				width_tmp /= 2;
				height_tmp /= 2;
				scale *= 2;
			}

			// decode with inSampleSize
			BitmapFactory.Options o2 = new BitmapFactory.Options();
			o2.inSampleSize = scale;
			return BitmapFactory.decodeStream(new FileInputStream(f), null, o2);
		} catch (FileNotFoundException e) {
		}
		return null;
	}

	// Task for the queue
	private class PhotoToLoad {
		public String url;
		public ImageView imageView;
		public Integer yw;
		public Context context;

		public PhotoToLoad(String u, ImageView i,Integer yw,Context context) {
			url = u;
			imageView = i;
			this.yw = yw;
			this.context = context;
		}
	}

	class PhotosLoader implements Runnable {
		PhotoToLoad photoToLoad;

		PhotosLoader(PhotoToLoad photoToLoad) {
			this.photoToLoad = photoToLoad;
		}

		@Override
		public void run() {
			if (imageViewReused(photoToLoad))
				return;
			Bitmap bmp = getBitmap(photoToLoad.url);
			memoryCache.put(photoToLoad.url, bmp);
			if (imageViewReused(photoToLoad))
				return;
			BitmapDisplayer bd = new BitmapDisplayer(bmp, photoToLoad);
			try{
			Activity a = null;
			if(photoToLoad.context != null){
				a = ValueUtil.activityIndex;
			}else{
				a = (Activity) photoToLoad.imageView.getContext(); 
			}
			if(photoToLoad.yw != null){
				photoToLoad.imageView.setLayoutParams(new LinearLayout.LayoutParams(photoToLoad.yw, ValueUtil.getHeight(photoToLoad.yw,bmp.getWidth(), bmp.getHeight())));  
			}
			a.runOnUiThread(bd);
			}catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

	/**
	 * 
	 * @param photoToLoad
	 * @return
	 */
	boolean imageViewReused(PhotoToLoad photoToLoad) {
		String tag = imageViews.get(photoToLoad.imageView);
		if (tag == null || !tag.equals(photoToLoad.url))
			return true;
		return false;
	}

	class BitmapDisplayer implements Runnable {
		Bitmap bitmap;
		PhotoToLoad photoToLoad;

		public BitmapDisplayer(Bitmap b, PhotoToLoad p) {
			bitmap = b;
			photoToLoad = p;
		}

		public void run() {
			if (imageViewReused(photoToLoad))
				return;
			if (bitmap != null)
				photoToLoad.imageView.setImageBitmap(bitmap);
			else
				photoToLoad.imageView.setImageResource(stub_id);
			
			if(imageViews.containsKey(photoToLoad.imageView)){
				imageViews.remove(photoToLoad.imageView);
				Log.i("�ɹ����", "photoToLoad.imageView");
			}
		}
	}
    
	public void clearCache() {
		memoryCache.clear();
		
	}
	public void clearFileCache(){
		fileCache.clear();
	}
	

	public Map<ImageView, String> getImageViews() {
		return imageViews;
	}

	public void setImageViews(Map<ImageView, String> imageViews) {
		this.imageViews = imageViews;
	}

	public MemoryCache getMemoryCache() {
		return memoryCache;
	}

	public void setMemoryCache(MemoryCache memoryCache) {
		this.memoryCache = memoryCache;
	}

	public FileCache getFileCache() {
		return fileCache;
	}

	public void setFileCache(FileCache fileCache) {
		this.fileCache = fileCache;
	}

	public static void CopyStream(InputStream is, OutputStream os) {
		final int buffer_size = 1024;
		try {
			byte[] bytes = new byte[buffer_size];
			for (;;) {
				int count = is.read(bytes, 0, buffer_size);
				if (count == -1)
					break;
				os.write(bytes, 0, count);
			}
		} catch (Exception ex) {
		}
	}
}
